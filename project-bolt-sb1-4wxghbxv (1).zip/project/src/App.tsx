import { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/context/auth-context';
import PrivateRoute from '@/components/auth/private-route';
import PublicRoute from '@/components/auth/public-route';
import Loading from '@/components/ui/loading';

// Lazy load pages for better performance
const LoginPage = lazy(() => import('@/pages/login'));
const RegisterPage = lazy(() => import('@/pages/register'));
const FeedPage = lazy(() => import('@/pages/feed'));
const ProfilePage = lazy(() => import('@/pages/profile'));
const EditProfilePage = lazy(() => import('@/pages/edit-profile'));
const SearchPage = lazy(() => import('@/pages/search'));
const SettingsPage = lazy(() => import('@/pages/settings'));

function App() {
  return (
    <AuthProvider>
      <Suspense fallback={<Loading />}>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<PublicRoute />}>
            <Route index element={<LoginPage />} />
            <Route path="login" element={<LoginPage />} />
            <Route path="register" element={<RegisterPage />} />
          </Route>

          {/* Protected Routes */}
          <Route path="/" element={<PrivateRoute />}>
            <Route path="feed" element={<FeedPage />} />
            <Route path="profile/:username" element={<ProfilePage />} />
            <Route path="edit-profile" element={<EditProfilePage />} />
            <Route path="search" element={<SearchPage />} />
            <Route path="settings" element={<SettingsPage />} />
          </Route>

          {/* Redirect any unknown routes */}
          <Route path="*" element={<Navigate to="/feed" replace />} />
        </Routes>
      </Suspense>
    </AuthProvider>
  );
}

export default App;