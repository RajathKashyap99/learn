import axios from 'axios';
import { User } from '@/types/user';
import { Post } from '@/types/post';

// Set base URL for API calls
axios.defaults.baseURL = 'http://localhost:5000/api';

// Authentication
export const loginUser = async (email: string, password: string) => {
  const response = await axios.post('/auth/login', { email, password });
  return response.data;
};

export const registerUser = async (userData: {
  username: string;
  email: string;
  password: string;
  name: string;
}) => {
  const response = await axios.post('/auth/register', userData);
  return response.data;
};

export const getCurrentUser = async () => {
  const response = await axios.get('/auth/me');
  return response.data;
};

// Users
export const getUserByUsername = async (username: string) => {
  const response = await axios.get(`/users/${username}`);
  return response.data;
};

export const updateUserProfile = async (profileData: Partial<User>) => {
  const response = await axios.put('/users/profile', profileData);
  return response.data;
};

export const followUser = async (userId: string) => {
  const response = await axios.put(`/users/follow/${userId}`);
  return response.data;
};

export const unfollowUser = async (userId: string) => {
  const response = await axios.put(`/users/unfollow/${userId}`);
  return response.data;
};

export const searchUsers = async (query: string) => {
  const response = await axios.get(`/users/search/${query}`);
  return response.data;
};

export const deleteAccount = async () => {
  const response = await axios.delete('/users');
  return response.data;
};

// Posts
export const createPost = async (postData: { content: string; image?: string }) => {
  const response = await axios.post('/posts', postData);
  return response.data;
};

export const getFeedPosts = async () => {
  const response = await axios.get('/posts');
  return response.data;
};

export const getUserPosts = async (userId: string) => {
  const response = await axios.get(`/posts/user/${userId}`);
  return response.data;
};

export const getPostById = async (postId: string) => {
  const response = await axios.get(`/posts/${postId}`);
  return response.data;
};

export const deletePost = async (postId: string) => {
  const response = await axios.delete(`/posts/${postId}`);
  return response.data;
};

export const likePost = async (postId: string) => {
  const response = await axios.put(`/posts/like/${postId}`);
  return response.data;
};

export const unlikePost = async (postId: string) => {
  const response = await axios.put(`/posts/unlike/${postId}`);
  return response.data;
};

export const addComment = async (postId: string, text: string) => {
  const response = await axios.post(`/posts/comment/${postId}`, { text });
  return response.data;
};

export const deleteComment = async (postId: string, commentId: string) => {
  const response = await axios.delete(`/posts/comment/${postId}/${commentId}`);
  return response.data;
};

export const sharePost = async (postId: string) => {
  const response = await axios.put(`/posts/share/${postId}`);
  return response.data;
};