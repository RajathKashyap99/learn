import { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { User } from '@/types/user';
import { Loader2, Search as SearchIcon } from 'lucide-react';
import * as api from '@/lib/api';

export default function SearchPage() {
  const location = useLocation();
  const { toast } = useToast();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const queryParam = searchParams.get('q');
    
    if (queryParam) {
      setQuery(queryParam);
      handleSearch(queryParam);
    }
  }, [location.search]);
  
  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    
    setLoading(true);
    setHasSearched(true);
    
    try {
      const data = await api.searchUsers(searchQuery);
      setResults(data);
    } catch (error) {
      console.error('Error searching users:', error);
      toast({
        variant: "destructive",
        title: "Search error",
        description: "Could not complete the search. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };
  
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(query);
  };
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase();
  };

  return (
    <MainLayout>
      <div className="max-w-3xl mx-auto py-6 animate-fade-in">
        <h1 className="text-2xl font-bold mb-6">Search</h1>
        
        <div className="mb-6">
          <form onSubmit={onSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search for users..."
                className="pl-9"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={!query.trim() || loading}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Search'}
            </Button>
          </form>
        </div>
        
        <Tabs defaultValue="users">
          <TabsList className="mb-6">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="posts">Posts</TabsTrigger>
            <TabsTrigger value="topics">Topics</TabsTrigger>
          </TabsList>
          
          <TabsContent value="users">
            {loading ? (
              <div className="flex justify-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : !hasSearched ? (
              <div className="text-center py-10 text-muted-foreground">
                Search for users to see results here
              </div>
            ) : results.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground mb-2">No users found for "{query}"</p>
                <p className="text-sm">Try a different search term</p>
              </div>
            ) : (
              <div className="grid gap-4">
                {results.map((user) => (
                  <Card key={user._id} className="animate-fade-in">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <Link to={`/profile/${user.username}`} className="flex items-center gap-3">
                          <Avatar className="h-12 w-12">
                            {user.profilePicture ? (
                              <AvatarImage src={user.profilePicture} alt={user.name} />
                            ) : (
                              <AvatarFallback className="bg-blue-100 text-primary">
                                {getInitials(user.name)}
                              </AvatarFallback>
                            )}
                          </Avatar>
                          <div>
                            <p className="font-medium">{user.name}</p>
                            <p className="text-sm text-muted-foreground">@{user.username}</p>
                            {user.bio && (
                              <p className="text-sm mt-1 line-clamp-1">{user.bio}</p>
                            )}
                          </div>
                        </Link>
                        <Button variant="outline" size="sm">
                          Follow
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="posts">
            <div className="text-center py-10 text-muted-foreground">
              Post search functionality coming soon
            </div>
          </TabsContent>
          
          <TabsContent value="topics">
            <div className="text-center py-10 text-muted-foreground">
              Topic search functionality coming soon
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}