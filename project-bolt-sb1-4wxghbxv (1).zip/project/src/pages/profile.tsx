import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layout/main-layout';
import { PostCard } from '@/components/posts/post-card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/auth-context';
import { User } from '@/types/user';
import { Post } from '@/types/post';
import { format } from 'date-fns';
import { CalendarDays, Loader2, MapPin, Link as LinkIcon, Edit3 } from 'lucide-react';
import * as api from '@/lib/api';

export default function ProfilePage() {
  const { username } = useParams<{ username: string }>();
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  
  const isOwnProfile = currentUser?._id === user?._id;
  
  useEffect(() => {
    const fetchProfileData = async () => {
      if (!username) return;
      
      setLoading(true);
      try {
        const userData = await api.getUserByUsername(username);
        setUser(userData);
        
        // Check if the current user is following this profile
        if (currentUser && userData.followers) {
          const isAlreadyFollowing = Array.isArray(userData.followers)
            ? userData.followers.some((follower: any) => 
                typeof follower === 'string' 
                  ? follower === currentUser._id 
                  : follower._id === currentUser._id
              )
            : false;
          
          setIsFollowing(isAlreadyFollowing);
        }
        
        setFollowersCount(userData.followers.length);
        setFollowingCount(userData.following.length);
        
        const postsData = await api.getUserPosts(userData._id);
        setPosts(postsData);
      } catch (error) {
        console.error('Error fetching profile:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Could not load profile. Please try again.",
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchProfileData();
  }, [username, currentUser]);
  
  const handleFollow = async () => {
    if (!user) return;
    
    try {
      if (isFollowing) {
        await api.unfollowUser(user._id);
        setFollowersCount(prev => prev - 1);
      } else {
        await api.followUser(user._id);
        setFollowersCount(prev => prev + 1);
      }
      
      setIsFollowing(!isFollowing);
    } catch (error) {
      console.error('Error following/unfollowing user:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not update follow status.",
      });
    }
  };
  
  const handlePostUpdate = async () => {
    if (!user) return;
    
    try {
      const postsData = await api.getUserPosts(user._id);
      setPosts(postsData);
    } catch (error) {
      console.error('Error refreshing posts:', error);
    }
  };
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase();
  };
  
  if (loading) {
    return (
      <MainLayout>
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }
  
  if (!user) {
    return (
      <MainLayout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold mb-2">User not found</h2>
          <p className="text-muted-foreground">The user you're looking for doesn't exist.</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="animate-fade-in">
        {/* Cover image */}
        <div className="h-48 bg-gradient-to-r from-blue-400 to-blue-500 rounded-xl mb-16 relative">
          {user.coverPicture && (
            <img 
              src={user.coverPicture} 
              alt="Cover" 
              className="w-full h-full object-cover rounded-xl"
            />
          )}
          
          {/* Profile picture */}
          <div className="absolute -bottom-12 left-4">
            <Avatar className="h-24 w-24 border-4 border-background">
              {user.profilePicture ? (
                <AvatarImage src={user.profilePicture} alt={user.name} />
              ) : (
                <AvatarFallback className="text-2xl bg-blue-100 text-primary">
                  {getInitials(user.name)}
                </AvatarFallback>
              )}
            </Avatar>
          </div>
          
          {/* Edit profile or Follow button */}
          <div className="absolute bottom-4 right-4">
            {isOwnProfile ? (
              <Button variant="outline" asChild>
                <Link to="/edit-profile">
                  <Edit3 className="h-4 w-4 mr-2" />
                  Edit Profile
                </Link>
              </Button>
            ) : (
              <Button
                variant={isFollowing ? "outline" : "default"}
                onClick={handleFollow}
              >
                {isFollowing ? 'Unfollow' : 'Follow'}
              </Button>
            )}
          </div>
        </div>
        
        {/* Profile info */}
        <div className="pb-4">
          <h1 className="text-2xl font-bold">{user.name}</h1>
          <p className="text-muted-foreground">@{user.username}</p>
          
          {user.bio && <p className="mt-3">{user.bio}</p>}
          
          <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
            <div className="flex items-center">
              <CalendarDays className="h-4 w-4 mr-1" />
              Joined {format(new Date(user.createdAt), 'MMMM yyyy')}
            </div>
          </div>
          
          <div className="flex gap-4 mt-4">
            <p className="text-sm">
              <span className="font-semibold text-foreground">{followingCount}</span>{' '}
              <span className="text-muted-foreground">Following</span>
            </p>
            <p className="text-sm">
              <span className="font-semibold text-foreground">{followersCount}</span>{' '}
              <span className="text-muted-foreground">Followers</span>
            </p>
          </div>
        </div>
        
        <Separator className="my-4" />
        
        {/* Tabs and content */}
        <Tabs defaultValue="posts">
          <TabsList className="w-full bg-transparent mb-6">
            <TabsTrigger value="posts" className="flex-1 data-[state=active]:bg-blue-100 rounded">
              Posts
            </TabsTrigger>
            <TabsTrigger value="likes" className="flex-1 data-[state=active]:bg-blue-100 rounded">
              Likes
            </TabsTrigger>
            <TabsTrigger value="media" className="flex-1 data-[state=active]:bg-blue-100 rounded">
              Media
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="posts">
            {posts.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-2">No posts yet</p>
                {isOwnProfile && (
                  <p className="text-sm">Create your first post to share with the world!</p>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {posts.map((post) => (
                  <PostCard 
                    key={post._id} 
                    post={post} 
                    onPostUpdate={handlePostUpdate}
                  />
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="likes">
            <div className="text-center py-8">
              <p className="text-muted-foreground">No liked posts to show</p>
            </div>
          </TabsContent>
          
          <TabsContent value="media">
            <div className="text-center py-8">
              <p className="text-muted-foreground">No media posts to show</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}