import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { CreatePost } from '@/components/posts/create-post';
import { PostCard } from '@/components/posts/post-card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Post } from '@/types/post';
import { User } from '@/types/user';
import { getFeedPosts } from '@/lib/api';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { RefreshCcw, Loader2 } from 'lucide-react';

export default function FeedPage() {
  const { toast } = useToast();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  
  const fetchPosts = async () => {
    try {
      const data = await getFeedPosts();
      setPosts(data);
    } catch (error) {
      console.error('Error fetching posts:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not load posts. Please try again.",
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  
  useEffect(() => {
    fetchPosts();
  }, []);
  
  const handleRefresh = () => {
    setRefreshing(true);
    fetchPosts();
  };
  
  // Sidebar content for "Who to follow"
  const suggestedUsers = [
    {
      _id: '1',
      name: 'Jane Cooper',
      username: 'janecooper',
      profilePicture: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      _id: '2',
      name: 'Robert Fox',
      username: 'robertfox',
      profilePicture: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      _id: '3',
      name: 'Esther Howard',
      username: 'estherhoward',
      profilePicture: 'https://images.pexels.com/photos/4153618/pexels-photo-4153618.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  ];
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase();
  };
  
  const RightSidebar = () => (
    <div className="space-y-6">
      <div className="bg-card rounded-xl shadow-sm overflow-hidden">
        <div className="p-4">
          <h3 className="font-semibold mb-4">Who to follow</h3>
          <div className="space-y-4">
            {suggestedUsers.map((user) => (
              <div key={user._id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    {user.profilePicture ? (
                      <AvatarImage src={user.profilePicture} alt={user.name} />
                    ) : (
                      <AvatarFallback className="bg-blue-100 text-primary">
                        {getInitials(user.name)}
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-xs text-muted-foreground">@{user.username}</p>
                  </div>
                </div>
                <Button size="sm" variant="outline">
                  Follow
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="bg-card rounded-xl shadow-sm overflow-hidden">
        <div className="p-4">
          <h3 className="font-semibold mb-2">Trending Topics</h3>
          <div className="space-y-3 mt-3">
            {['#Technology', '#Travel', '#Photography', '#Art', '#Music'].map((topic) => (
              <div key={topic} className="text-sm hover:text-primary cursor-pointer transition-colors">
                {topic}
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="text-xs text-muted-foreground">
        <div className="space-x-2">
          <a href="#" className="hover:underline">Terms of Service</a>
          <a href="#" className="hover:underline">Privacy Policy</a>
          <a href="#" className="hover:underline">Cookie Policy</a>
        </div>
        <p className="mt-2">© 2025 Circle, Inc.</p>
      </div>
    </div>
  );

  return (
    <MainLayout rightSidebar={<RightSidebar />}>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Home</h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleRefresh}
          disabled={refreshing}
          className="text-primary"
        >
          {refreshing ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <RefreshCcw className="h-5 w-5" />
          )}
        </Button>
      </div>
      
      <CreatePost onPostCreated={fetchPosts} />
      
      <Separator className="my-6" />
      
      {loading ? (
        <div className="flex justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : posts.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-muted-foreground mb-4">No posts yet</p>
          <p className="text-sm">Follow more users or create a post to see content here.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <PostCard key={post._id} post={post} onPostUpdate={fetchPosts} />
          ))}
        </div>
      )}
    </MainLayout>
  );
}