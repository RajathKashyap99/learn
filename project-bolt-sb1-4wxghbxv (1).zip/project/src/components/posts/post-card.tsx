import { useState } from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { useAuth } from '@/context/auth-context';
import { Post } from '@/types/post';
import { User } from '@/types/user';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Heart, MessageCircle, Share, MoreHorizontal, Trash2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import * as api from '@/lib/api';

interface PostCardProps {
  post: Post;
  onPostUpdate?: () => void;
}

export function PostCard({ post, onPostUpdate }: PostCardProps) {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [isLiked, setIsLiked] = useState<boolean>(
    Array.isArray(post.likes) && currentUser 
      ? post.likes.includes(currentUser._id) 
      : false
  );
  const [likeCount, setLikeCount] = useState<number>(
    Array.isArray(post.likes) ? post.likes.length : 0
  );
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [comments, setComments] = useState(post.comments);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  const postUser = post.user as User;
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase();
  };
  
  const handleLike = async () => {
    try {
      if (isLiked) {
        await api.unlikePost(post._id);
        setLikeCount(prev => prev - 1);
      } else {
        await api.likePost(post._id);
        setLikeCount(prev => prev + 1);
      }
      setIsLiked(!isLiked);
    } catch (error) {
      console.error('Error updating like status:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not update like status",
      });
    }
  };

  const handleComment = async () => {
    if (!commentText.trim()) return;
    
    try {
      const newComments = await api.addComment(post._id, commentText);
      setComments(newComments);
      setCommentText('');
    } catch (error) {
      console.error('Error adding comment:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not add comment",
      });
    }
  };
  
  const handleDeleteComment = async (commentId: string) => {
    try {
      const updatedComments = await api.deleteComment(post._id, commentId);
      setComments(updatedComments);
    } catch (error) {
      console.error('Error deleting comment:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not delete comment",
      });
    }
  };
  
  const handleShare = async () => {
    try {
      await api.sharePost(post._id);
      toast({
        title: "Post Shared",
        description: "The post has been shared to your followers",
      });
    } catch (error) {
      console.error('Error sharing post:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not share the post",
      });
    }
  };
  
  const handleDeletePost = async () => {
    try {
      await api.deletePost(post._id);
      if (onPostUpdate) {
        onPostUpdate();
      }
      toast({
        title: "Post Deleted",
        description: "Your post has been deleted successfully",
      });
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error('Error deleting post:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not delete the post",
      });
    }
  };

  return (
    <>
      <div className="bg-card rounded-xl shadow-sm overflow-hidden mb-4 hover:shadow-md transition-shadow animate-fade-in">
        <div className="p-4">
          <div className="flex justify-between items-start mb-3">
            <Link to={`/profile/${postUser.username}`} className="flex items-center gap-3">
              <Avatar className="h-10 w-10 border border-blue-100">
                {postUser.profilePicture ? (
                  <AvatarImage src={postUser.profilePicture} alt={postUser.name} />
                ) : (
                  <AvatarFallback className="bg-blue-100 text-primary">
                    {getInitials(postUser.name)}
                  </AvatarFallback>
                )}
              </Avatar>
              <div className="flex flex-col">
                <span className="font-medium text-sm hover:underline">{postUser.name}</span>
                <span className="text-muted-foreground text-xs">@{postUser.username}</span>
              </div>
            </Link>
            
            {currentUser && postUser._id === currentUser._id && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-40">
                  <DropdownMenuItem 
                    className="text-destructive focus:text-destructive cursor-pointer"
                    onClick={() => setIsDeleteDialogOpen(true)}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete Post
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
          
          <p className="text-sm mb-3 whitespace-pre-wrap">{post.content}</p>
          
          {post.image && (
            <div className="mt-3 mb-4 rounded-lg overflow-hidden">
              <img 
                src={post.image} 
                alt="Post" 
                className="w-full h-auto object-cover max-h-96"
              />
            </div>
          )}
          
          <div className="text-xs text-muted-foreground mb-4">
            {format(new Date(post.createdAt), 'MMM d, yyyy • h:mm a')}
          </div>
          
          <div className="flex justify-between items-center pt-2 border-t border-border">
            <Button 
              variant="ghost" 
              size="sm" 
              className={cn(
                "gap-2 text-muted-foreground", 
                isLiked && "text-red-500 hover:text-red-600"
              )}
              onClick={handleLike}
            >
              <Heart className={cn("h-4 w-4", isLiked && "fill-current")} />
              <span>{likeCount}</span>
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm"
              className="gap-2 text-muted-foreground"
              onClick={() => setShowComments(!showComments)}
            >
              <MessageCircle className="h-4 w-4" />
              <span>{comments.length}</span>
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm"
              className="gap-2 text-muted-foreground"
              onClick={handleShare}
            >
              <Share className="h-4 w-4" />
              <span>{Array.isArray(post.shares) ? post.shares.length : 0}</span>
            </Button>
          </div>
        </div>
        
        {showComments && (
          <div className="bg-accent/30 p-4 border-t border-border">
            <div className="space-y-4">
              {comments.length > 0 ? (
                comments.map((comment: any) => {
                  const commentUser = comment.user as User;
                  return (
                    <div key={comment._id} className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        {commentUser.profilePicture ? (
                          <AvatarImage src={commentUser.profilePicture} alt={commentUser.name} />
                        ) : (
                          <AvatarFallback className="bg-blue-100 text-primary">
                            {getInitials(commentUser.name)}
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <Link 
                            to={`/profile/${commentUser.username}`} 
                            className="font-medium text-xs hover:underline"
                          >
                            {commentUser.name}
                          </Link>
                          
                          {currentUser && commentUser._id === currentUser._id && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6" 
                              onClick={() => handleDeleteComment(comment._id)}
                            >
                              <Trash2 className="h-3 w-3 text-muted-foreground" />
                            </Button>
                          )}
                        </div>
                        <p className="text-xs mt-1">{comment.text}</p>
                        <span className="text-xs text-muted-foreground mt-1">
                          {format(new Date(comment.createdAt), 'MMM d • h:mm a')}
                        </span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-muted-foreground text-center py-2">No comments yet</p>
              )}
            </div>
            
            <div className="mt-4 flex gap-2">
              <Textarea
                placeholder="Add a comment..."
                className="min-h-10 text-sm resize-none"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
              />
              <Button 
                size="sm" 
                className="self-end"
                onClick={handleComment}
                disabled={!commentText.trim()}
              >
                Post
              </Button>
            </div>
          </div>
        )}
      </div>
      
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Post</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this post? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeletePost}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default PostCard;