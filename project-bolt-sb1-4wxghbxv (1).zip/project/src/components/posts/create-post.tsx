import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/auth-context';
import { Image, X } from 'lucide-react';
import * as api from '@/lib/api';

interface CreatePostProps {
  onPostCreated: () => void;
}

export function CreatePost({ onPostCreated }: CreatePostProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  if (!user) return null;
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase();
  };
  
  const handleSubmit = async () => {
    if (!content.trim()) return;
    
    setIsSubmitting(true);
    try {
      const postData = {
        content: content.trim(),
        image: imageUrl || undefined
      };
      
      await api.createPost(postData);
      setContent('');
      setImageUrl('');
      onPostCreated();
      
      toast({
        title: "Success",
        description: "Your post has been created!",
      });
    } catch (error) {
      console.error('Error creating post:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not create your post",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-card rounded-xl shadow-sm p-4 mb-6 animate-fade-in">
      <div className="flex gap-3">
        <Avatar className="h-10 w-10 border border-blue-100">
          {user.profilePicture ? (
            <AvatarImage src={user.profilePicture} alt={user.name} />
          ) : (
            <AvatarFallback className="bg-blue-100 text-primary">
              {getInitials(user.name)}
            </AvatarFallback>
          )}
        </Avatar>
        
        <div className="flex-1">
          <Textarea
            placeholder="What's happening?"
            className="min-h-20 text-base resize-none border-none shadow-none focus-visible:ring-0 p-0 mb-3"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          
          {imageUrl && (
            <div className="relative mb-3 rounded-lg overflow-hidden">
              <img 
                src={imageUrl} 
                alt="Post preview" 
                className="w-full h-auto max-h-60 object-cover"
              />
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2 h-7 w-7 rounded-full opacity-80"
                onClick={() => setImageUrl('')}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
          
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-border">
            <div className="flex items-center">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="text-primary"
                onClick={() => {
                  const url = prompt('Enter image URL:');
                  if (url) setImageUrl(url);
                }}
              >
                <Image className="h-5 w-5" />
              </Button>
            </div>
            
            <Button
              type="button"
              size="sm"
              className="px-4"
              disabled={!content.trim() || isSubmitting}
              onClick={handleSubmit}
            >
              {isSubmitting ? 'Posting...' : 'Post'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CreatePost;