import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/context/auth-context';
import Loading from '@/components/ui/loading';

const PrivateRoute = () => {
  const { token, loading } = useAuth();

  if (loading) {
    return <Loading />;
  }

  return token ? <Outlet /> : <Navigate to="/login" replace />;
};

export default PrivateRoute;