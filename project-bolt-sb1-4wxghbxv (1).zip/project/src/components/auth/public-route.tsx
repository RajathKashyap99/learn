import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/context/auth-context';
import Loading from '@/components/ui/loading';

const PublicRoute = () => {
  const { token, loading } = useAuth();

  if (loading) {
    return <Loading />;
  }

  return token ? <Navigate to="/feed" replace /> : <Outlet />;
};

export default PublicRoute;