import { ReactNode } from 'react';
import { Header } from './header';
import { Sidebar } from './sidebar';
import { ScrollArea } from '@/components/ui/scroll-area';

interface MainLayoutProps {
  children: ReactNode;
  rightSidebar?: ReactNode;
}

export function MainLayout({ children, rightSidebar }: MainLayoutProps) {
  return (
    <div className="relative min-h-screen flex flex-col">
      <Header />
      <div className="flex-1 container flex">
        <Sidebar className="fixed left-0 top-16 h-[calc(100vh-4rem)]" />
        
        <main className="flex-1 md:ml-64 px-4 py-6">
          <div className="mx-auto max-w-screen-md">
            {children}
          </div>
        </main>
        
        {rightSidebar && (
          <aside className="hidden lg:block w-80 fixed right-0 top-16 h-[calc(100vh-4rem)]">
            <ScrollArea className="h-full px-4 py-6">
              {rightSidebar}
            </ScrollArea>
          </aside>
        )}
      </div>
    </div>
  );
}

export default MainLayout;