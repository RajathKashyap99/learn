import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/auth-context';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Home, 
  Search, 
  Bell, 
  Mail, 
  Bookmark, 
  User, 
  Settings, 
  LogOut, 
  PenSquare 
} from 'lucide-react';

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const { user, logout } = useAuth();
  const location = useLocation();
  
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase();
  };

  const navItems = [
    { icon: Home, label: 'Home', href: '/feed' },
    { icon: Search, label: 'Search', href: '/search' },
    { icon: Bell, label: 'Notifications', href: '/notifications' },
    { icon: Mail, label: 'Messages', href: '/messages' },
    { icon: Bookmark, label: 'Bookmarks', href: '/bookmarks' },
    { icon: User, label: 'Profile', href: user ? `/profile/${user.username}` : '/profile' },
    { icon: Settings, label: 'Settings', href: '/settings' },
  ];

  const handleLogout = () => {
    logout();
  };

  return (
    <div className={cn("pb-12 w-64 hidden md:block", className)}>
      <div className="space-y-4 py-4 h-screen flex flex-col">
        <div className="px-4 py-2">
          <Link to="/feed" className="flex items-center">
            <div className="text-primary flex items-center font-bold text-2xl">
              <span className="text-primary rounded-full bg-blue-100 p-2 mr-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M12 2L2 7l10 5 10-5-10-5z" />
                  <path d="M2 17l10 5 10-5" />
                  <path d="M2 12l10 5 10-5" />
                </svg>
              </span>
              Circle
            </div>
          </Link>
        </div>
        <ScrollArea className="flex-1 px-2">
          <div className="space-y-1">
            {navItems.map((item, i) => {
              const isActive = location.pathname === item.href;
              const Icon = item.icon;
              
              return (
                <Link
                  key={i}
                  to={item.href}
                  className={cn(
                    "flex items-center py-3 px-4 rounded-lg text-sm font-medium transition-colors hover:bg-blue-100",
                    isActive ? "bg-blue-100 text-primary" : "text-muted-foreground"
                  )}
                >
                  <Icon className="h-5 w-5 mr-3" />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </ScrollArea>
        
        <div className="px-4 mt-auto">
          <Button 
            variant="outline" 
            className="w-full justify-start shadow-none border-blue-100 hover:bg-blue-100 hover:text-primary"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5 mr-3" />
            Logout
          </Button>
        </div>
        
        <Button
          className="mx-4 mb-4"
          size="lg"
        >
          <PenSquare className="h-5 w-5 mr-2" />
          Post
        </Button>
        
        {user && (
          <div className="px-4 py-2 mt-auto">
            <div className="flex items-center space-x-3 hover:bg-blue-50 p-3 rounded-lg cursor-pointer transition-colors">
              <Avatar className="h-10 w-10 border-2 border-blue-100">
                {user.profilePicture ? (
                  <AvatarImage src={user.profilePicture} alt={user.name} />
                ) : (
                  <AvatarFallback className="bg-blue-100 text-primary">
                    {getInitials(user.name)}
                  </AvatarFallback>
                )}
              </Avatar>
              <div className="flex flex-col">
                <span className="font-semibold text-sm">{user.name}</span>
                <span className="text-muted-foreground text-xs">@{user.username}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Sidebar;