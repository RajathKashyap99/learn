import { User } from './user';

export interface Comment {
  _id: string;
  user: string | User;
  text: string;
  createdAt: string;
}

export interface Post {
  _id: string;
  content: string;
  image?: string;
  user: string | User;
  likes: string[] | User[];
  comments: Comment[];
  shares: string[] | User[];
  createdAt: string;
  updatedAt: string;
}