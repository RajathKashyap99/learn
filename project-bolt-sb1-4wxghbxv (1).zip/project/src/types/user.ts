export interface User {
  _id: string;
  username: string;
  email: string;
  name: string;
  bio: string;
  profilePicture: string;
  coverPicture: string;
  followers: string[] | User[];
  following: string[] | User[];
  createdAt: string;
  updatedAt: string;
}