"use client"

import { useContext, useEffect, useState } from "react"
import { SocketContext } from "@/context/socket-context"
import { UserContext } from "@/context/user-context"
import type { User } from "@/types/user"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { UserPlus } from "lucide-react"
import Link from "next/link"

export default function RightSidebar() {
  const socket = useContext(SocketContext)
  const { user } = useContext(UserContext)
  const [friendRequests, setFriendRequests] = useState<User[]>([])
  const [suggestions, setSuggestions] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!socket || !user) return

    // Get friend requests from user data
    if (user.requests) {
      setFriendRequests(user.requests)
    }

    // Mock suggestions (in a real app, you'd get these from the backend)
    socket.emit("search-users-request", "")

    socket.on("search-users-response", (data) => {
      // Filter out current user and friends
      const filteredUsers = data.filter((u: User) => {
        return (
          u._id !== user._id &&
          !user.friends?.some((f: any) => f._id === u._id) &&
          !user.requests?.some((r: any) => r._id === u._id)
        )
      })

      setSuggestions(filteredUsers.slice(0, 5))
      setIsLoading(false)
    })

    socket.on("send-friend-request-response", (updatedUser) => {
      if (updatedUser._id === user._id) {
        setFriendRequests(updatedUser.requests || [])
      }
    })

    return () => {
      socket.off("search-users-response")
      socket.off("send-friend-request-response")
    }
  }, [socket, user])

  const handleAcceptRequest = (requesterId: string) => {
    if (!socket || !user) return

    socket.emit("accept-friend-request", {
      sender: requesterId,
      receiver: user._id,
    })

    // Remove from requests list
    setFriendRequests(friendRequests.filter((req) => req._id !== requesterId))
  }

  const handleDeclineRequest = (requesterId: string) => {
    if (!socket || !user) return

    socket.emit("reject-friend-request", {
      sender: requesterId,
      receiver: user._id,
    })

    // Remove from requests list
    setFriendRequests(friendRequests.filter((req) => req._id !== requesterId))
  }

  const handleAddFriend = (userId: string) => {
    if (!socket || !user) return

    socket.emit("send-friend-request", {
      sender: user._id,
      receiver: userId,
    })

    // Remove from suggestions
    setSuggestions(suggestions.filter((s) => s._id !== userId))
  }

  if (isLoading) {
    return (
      <div className="hidden w-80 border-l border-gray-200 bg-white p-4 lg:block">
        <div className="flex h-full items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-blue-500"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="hidden w-80 border-l border-gray-200 bg-white p-4 lg:block">
      {/* Friend Requests */}
      {friendRequests.length > 0 && (
        <div className="mb-8">
          <h3 className="mb-4 text-lg font-semibold">
            Requests{" "}
            <span className="rounded-full bg-blue-100 px-2 py-0.5 text-xs text-blue-600">{friendRequests.length}</span>
          </h3>

          <div className="space-y-4">
            {friendRequests.map((request) => (
              <div key={request._id} className="flex items-start">
                <Link href={`/profile/${request._id}`} className="flex items-center">
                  <div className="relative h-10 w-10 overflow-hidden rounded-full">
                    <Image
                      src={request.photoURL || "/placeholder.svg?height=40&width=40"}
                      alt={request.displayName}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="ml-3">
                    <h4 className="font-medium">{request.displayName}</h4>
                    <p className="text-xs text-gray-500">wants to add you to friends</p>
                  </div>
                </Link>

                <div className="ml-auto flex flex-col space-y-1">
                  <Button size="sm" className="w-full" onClick={() => handleAcceptRequest(request._id)}>
                    Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full"
                    onClick={() => handleDeclineRequest(request._id)}
                  >
                    Decline
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Suggestions */}
      <div>
        <h3 className="mb-4 text-lg font-semibold">Suggestions for you</h3>

        <div className="space-y-4">
          {suggestions.map((suggestion) => (
            <div key={suggestion._id} className="flex items-center justify-between">
              <Link href={`/profile/${suggestion._id}`} className="flex items-center">
                <div className="relative h-10 w-10 overflow-hidden rounded-full">
                  <Image
                    src={suggestion.photoURL || "/placeholder.svg?height=40&width=40"}
                    alt={suggestion.displayName}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="ml-3">
                  <h4 className="font-medium">{suggestion.displayName}</h4>
                  <p className="text-xs text-gray-500">{suggestion.address || "New user"}</p>
                </div>
              </Link>

              <Button
                size="sm"
                variant="ghost"
                className="text-blue-600"
                onClick={() => handleAddFriend(suggestion._id)}
              >
                <UserPlus className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>

        <Button variant="link" className="mt-4 w-full text-blue-600">
          View All
        </Button>
      </div>

      {/* Footer Links */}
      <div className="mt-8 text-xs text-gray-500">
        <div className="flex flex-wrap gap-2">
          <Link href="#" className="hover:underline">
            About
          </Link>
          <Link href="#" className="hover:underline">
            Accessibility
          </Link>
          <Link href="#" className="hover:underline">
            Help Center
          </Link>
          <Link href="#" className="hover:underline">
            Privacy and Terms
          </Link>
          <Link href="#" className="hover:underline">
            Advertising
          </Link>
          <Link href="#" className="hover:underline">
            Business Services
          </Link>
        </div>

        <div className="mt-4 flex items-center">
          <span>© 2023 Echo Mate</span>
        </div>
      </div>
    </div>
  )
}
