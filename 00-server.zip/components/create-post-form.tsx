"use client"

import type React from "react"

import { useState, useContext, useRef } from "react"
import { SocketContext } from "@/context/socket-context"
import { UserContext } from "@/context/user-context"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ImageIcon, X } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

export default function CreatePostForm() {
  const socket = useContext(SocketContext)
  const { user } = useContext(UserContext)
  const [text, setText] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setSelectedFile(file)
    const reader = new FileReader()
    reader.onloadend = () => {
      setPreviewUrl(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!socket || !user || (!text.trim() && !selectedFile)) return

    setIsSubmitting(true)

    try {
      let content = ""
      let type = "text"

      if (selectedFile) {
        // Upload file to S3
        const formData = new FormData()
        formData.append("file", selectedFile)

        const response = await fetch("http://localhost:8000/upload", {
          method: "POST",
          body: formData,
        })

        if (!response.ok) {
          throw new Error("Failed to upload image")
        }

        const data = await response.json()
        content = data.fileUrl
        type = "image"
      }

      // Create post
      socket.emit("create-post", {
        content,
        text,
        type,
        owner: user._id,
      })

      setText("")
      setSelectedFile(null)
      setPreviewUrl(null)

      toast({
        title: "Post created",
        description: "Your post has been published successfully",
      })
    } catch (error) {
      console.error("Error creating post:", error)
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
      <form onSubmit={handleSubmit}>
        <div className="flex items-start space-x-3">
          {user && (
            <Avatar>
              <AvatarImage src={user.photoURL || "/placeholder.svg"} alt={user.displayName} />
              <AvatarFallback>{getInitials(user.displayName)}</AvatarFallback>
            </Avatar>
          )}

          <div className="flex-1">
            <Textarea
              placeholder="What's on your mind?"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="mb-3 min-h-[100px] resize-none border-none p-0 focus-visible:ring-0"
            />

            {previewUrl && (
              <div className="relative mb-3 overflow-hidden rounded-lg">
                <img
                  src={previewUrl || "/placeholder.svg"}
                  alt="Preview"
                  className="max-h-[300px] w-full object-cover"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  className="absolute right-2 top-2"
                  onClick={() => {
                    setSelectedFile(null)
                    setPreviewUrl(null)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleFileChange} />
                <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                  <ImageIcon className="mr-2 h-4 w-4" />
                  Add Photo
                </Button>
              </div>

              <Button type="submit" disabled={isSubmitting || (!text.trim() && !selectedFile)}>
                {isSubmitting ? "Posting..." : "Create new post"}
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}
