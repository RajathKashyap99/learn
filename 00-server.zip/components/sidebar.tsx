"use client"

import { useContext } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { UserContext } from "@/context/user-context"
import { Home, Compass, Bookmark, MessageSquare, BarChart2, Settings, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export default function Sidebar() {
  const { user } = useContext(UserContext)
  const pathname = usePathname()
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const navItems = [
    { name: "Feed", icon: Home, href: "/dashboard" },
    { name: "Explore", icon: Compass, href: "/explore" },
    { name: "My favorites", icon: Bookmark, href: "/favorites" },
    { name: "Direct", icon: MessageSquare, href: "/messages" },
    { name: "Stats", icon: BarChart2, href: "/stats" },
    { name: "Settings", icon: Settings, href: "/settings" },
  ]

  return (
    <div className="flex h-full w-20 flex-col items-center border-r border-gray-200 bg-white p-4 md:w-64 md:items-start">
      {/* User Profile */}
      {user && (
        <Link href={`/profile/${user._id}`} className="mb-8 flex items-center">
          <div className="relative h-10 w-10 overflow-hidden rounded-full">
            <Image
              src={user.photoURL || "/placeholder.svg?height=40&width=40"}
              alt={user.displayName}
              fill
              className="object-cover"
            />
          </div>
          <div className="ml-3 hidden md:block">
            <h3 className="font-medium">{user.displayName}</h3>
            <p className="text-xs text-gray-500">{user.email}</p>
          </div>
        </Link>
      )}

      {/* Navigation */}
      <nav className="flex flex-1 flex-col space-y-2">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.name}
              href={item.href}
              className={`flex items-center rounded-lg p-2 ${
                isActive ? "bg-blue-50 text-blue-600" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <item.icon className="h-6 w-6" />
              <span className="ml-3 hidden md:block">{item.name}</span>
            </Link>
          )
        })}
      </nav>

      {/* Logout */}
      <Button
        variant="ghost"
        className="mt-auto flex w-full items-center justify-center md:justify-start"
        onClick={handleLogout}
      >
        <LogOut className="h-6 w-6" />
        <span className="ml-3 hidden md:block">Logout</span>
      </Button>
    </div>
  )
}
