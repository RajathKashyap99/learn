"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"

// Mock data for stories
const mockStories = [
  { id: 1, name: "Anna", image: "/placeholder.svg?height=60&width=60" },
  { id: 2, name: "David", image: "/placeholder.svg?height=60&width=60" },
  { id: 3, name: "Grace", image: "/placeholder.svg?height=60&width=60" },
  { id: 4, name: "James", image: "/placeholder.svg?height=60&width=60" },
  { id: 5, name: "Olivia", image: "/placeholder.svg?height=60&width=60" },
  { id: 6, name: "Robert", image: "/placeholder.svg?height=60&width=60" },
]

export default function StoriesSection() {
  const [activeStory, setActiveStory] = useState<number | null>(null)

  return (
    <div className="mb-6">
      <div className="mb-2 flex items-center justify-between">
        <h2 className="text-2xl font-bold">Stories</h2>
        <Button variant="link" className="text-blue-600">
          Watch all
        </Button>
      </div>

      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex space-x-4 p-1">
          {/* Add Story Button */}
          <div className="flex flex-col items-center">
            <div className="group relative h-14 w-14 cursor-pointer overflow-hidden rounded-full border-2 border-dashed border-gray-300 bg-gray-50">
              <div className="flex h-full w-full items-center justify-center">
                <Plus className="h-6 w-6 text-gray-500 transition-colors group-hover:text-blue-500" />
              </div>
            </div>
            <span className="mt-1 text-xs">Add story</span>
          </div>

          {/* Stories */}
          {mockStories.map((story) => (
            <div key={story.id} className="flex flex-col items-center">
              <div
                className={`relative h-14 w-14 cursor-pointer overflow-hidden rounded-full border-2 ${
                  activeStory === story.id ? "border-blue-500" : "border-blue-300"
                }`}
                onClick={() => setActiveStory(story.id)}
              >
                <Image src={story.image || "/placeholder.svg"} alt={story.name} fill className="object-cover" />
              </div>
              <span className="mt-1 text-xs">{story.name}</span>
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  )
}
