"use client"

import { useState, useContext } from "react"
import Image from "next/image"
import { formatDistanceToNow } from "date-fns"
import { Heart, MessageCircle, Bookmark, MoreHorizontal, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { SocketContext } from "@/context/socket-context"
import { UserContext } from "@/context/user-context"
import type { Post } from "@/types/post"
import Link from "next/link"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface FeedPostProps {
  post: Post
}

export default function FeedPost({ post }: FeedPostProps) {
  const socket = useContext(SocketContext)
  const { user } = useContext(UserContext)
  const [comment, setComment] = useState("")
  const [showComments, setShowComments] = useState(false)

  const isLiked = user ? post.likes.includes(user._id) : false

  const handleLike = () => {
    if (!socket || !user) return

    if (isLiked) {
      socket.emit("unlike-post", {
        post_id: post._id,
        user_id: user._id,
      })
    } else {
      socket.emit("like-post", {
        post_id: post._id,
        user_id: user._id,
      })
    }
  }

  const handleComment = () => {
    if (!socket || !user || !comment.trim()) return

    socket.emit("comment-post", {
      post_id: post._id,
      user_id: user._id,
      text: comment,
    })

    setComment("")
  }

  const handleDelete = () => {
    if (!socket || !user) return

    if (post.owner._id === user._id) {
      socket.emit("delete-post", post._id)
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
  }

  return (
    <div className="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
      {/* Post Header */}
      <div className="flex items-center justify-between p-4">
        <Link href={`/profile/${post.owner._id}`} className="flex items-center">
          <Avatar className="h-10 w-10">
            <AvatarImage src={post.owner.photoURL || "/placeholder.svg"} alt={post.owner.displayName} />
            <AvatarFallback>{getInitials(post.owner.displayName)}</AvatarFallback>
          </Avatar>
          <div className="ml-3">
            <h3 className="font-medium">{post.owner.displayName}</h3>
            <p className="text-xs text-gray-500">
              {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}
            </p>
          </div>
        </Link>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <MoreHorizontal className="h-5 w-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {user && post.owner._id === user._id && (
              <DropdownMenuItem onClick={handleDelete} className="text-red-500">
                Delete
              </DropdownMenuItem>
            )}
            <DropdownMenuItem>Report</DropdownMenuItem>
            <DropdownMenuItem>Save</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Post Content */}
      <div className="px-4 pb-4">
        {post.text && <p className="mb-4">{post.text}</p>}

        {post.content && post.type === "image" && (
          <div className="relative mb-4 overflow-hidden rounded-lg">
            <Image
              src={post.content || "/placeholder.svg"}
              alt="Post image"
              width={600}
              height={400}
              className="w-full object-cover"
            />
          </div>
        )}

        {post.content && post.type === "gallery" && (
          <div className="mb-4 grid grid-cols-2 gap-2">
            {post.content.split(",").map((url, index) => (
              <div key={index} className="relative aspect-square overflow-hidden rounded-lg">
                <Image
                  src={url.trim() || "/placeholder.svg"}
                  alt={`Gallery image ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Post Actions */}
      <div className="border-t border-gray-100 px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              className={`flex items-center ${isLiked ? "text-red-500" : ""}`}
              onClick={handleLike}
            >
              <Heart className={`mr-1 h-5 w-5 ${isLiked ? "fill-red-500" : ""}`} />
              <span>{post.likes.length}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="flex items-center"
              onClick={() => setShowComments(!showComments)}
            >
              <MessageCircle className="mr-1 h-5 w-5" />
              <span>{post.comments.length}</span>
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="flex items-center">
              <Send className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" className="flex items-center">
              <Bookmark className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Comments */}
      {showComments && (
        <div className="border-t border-gray-100 p-4">
          {post.comments.length > 0 ? (
            <div className="mb-4 space-y-3">
              {post.comments.map((comment, index) => (
                <div key={index} className="flex items-start">
                  <Avatar className="mr-2 h-8 w-8">
                    <AvatarImage src={comment.user.photoURL || "/placeholder.svg"} alt={comment.user.displayName} />
                    <AvatarFallback>{getInitials(comment.user.displayName)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 rounded-lg bg-gray-50 p-2">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-medium">{comment.user.displayName}</h4>
                      <span className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(comment.timestamp), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm">{comment.text}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="mb-4 text-center text-sm text-gray-500">No comments yet</p>
          )}

          {user && (
            <div className="flex items-center">
              <Input
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1"
                onKeyDown={(e) => e.key === "Enter" && handleComment()}
              />
              <Button onClick={handleComment} disabled={!comment.trim()} className="ml-2">
                Post
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
