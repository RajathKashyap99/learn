export interface Chat {
  _id: string
  message: string
  sender: string
  receiver: string
  type: string
  media?: string
  timestamp: Date
}
