import type { User } from "./user"

export interface Comment {
  _id?: string
  user: User
  text: string
  timestamp: Date
}

export interface Post {
  _id: string
  content: string
  likes: string[]
  comments: Comment[]
  type: string
  text?: string
  edited: boolean
  owner: User
  timestamp: Date
}
