export interface User {
  _id: string
  displayName: string
  email: string
  photoURL: string
  cover?: string
  socket_id?: string
  dob?: Date
  address?: string
  phoneNumber?: string
  accessToken: string
  requests?: any[]
  friends?: any[]
}
