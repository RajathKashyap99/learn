"use client"

import { useContext, useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { SocketContext } from "@/context/socket-context"
import { UserContext } from "@/context/user-context"
import type { User } from "@/types/user"
import type { Post } from "@/types/post"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import FeedPost from "@/components/feed-post"
import { Edit, MapPin, Calendar, Phone } from "lucide-react"
import ProfileEditModal from "@/components/profile-edit-modal"

export default function ProfilePage() {
  const { id } = useParams()
  const socket = useContext(SocketContext)
  const { user: currentUser } = useContext(UserContext)
  const [profileUser, setProfileUser] = useState<User & { posts?: Post[] }>()
  const [isLoading, setIsLoading] = useState(true)
  const [showEditModal, setShowEditModal] = useState(false)
  const [friendStatus, setFriendStatus] = useState<"none" | "friends" | "pending" | "requested">("none")

  useEffect(() => {
    if (!socket || !id) return

    socket.emit("get-profile-request", id)

    socket.on("get-profile-response", (data) => {
      if (data._id === id) {
        setProfileUser(data)
        setIsLoading(false)

        // Determine friend status
        if (currentUser) {
          if (currentUser.friends?.some((f: any) => f._id === data._id)) {
            setFriendStatus("friends")
          } else if (currentUser.requests?.some((r: any) => r._id === data._id)) {
            setFriendStatus("requested")
          } else if (data.requests?.some((r: any) => r._id === currentUser._id)) {
            setFriendStatus("pending")
          } else {
            setFriendStatus("none")
          }
        }
      }
    })

    return () => {
      socket.off("get-profile-response")
    }
  }, [socket, id, currentUser])

  const handleFriendAction = () => {
    if (!socket || !currentUser || !profileUser) return

    if (friendStatus === "none") {
      socket.emit("send-friend-request", {
        sender: currentUser._id,
        receiver: profileUser._id,
      })
      setFriendStatus("pending")
    } else if (friendStatus === "friends") {
      socket.emit("unfriend-user", {
        sender: currentUser._id,
        receiver: profileUser._id,
      })
      setFriendStatus("none")
    } else if (friendStatus === "pending") {
      socket.emit("cancel-friend-request", {
        sender: currentUser._id,
        receiver: profileUser._id,
      })
      setFriendStatus("none")
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-blue-500"></div>
      </div>
    )
  }

  if (!profileUser) {
    return (
      <div className="flex h-full items-center justify-center">
        <p>User not found</p>
      </div>
    )
  }

  const isOwnProfile = currentUser?._id === profileUser._id

  return (
    <div className="h-full overflow-auto">
      {/* Cover and Profile Section */}
      <div className="relative h-64 w-full bg-gradient-to-r from-blue-400 to-purple-500">
        {profileUser.cover && (
          <Image src={profileUser.cover || "/placeholder.svg"} alt="Cover" fill className="object-cover" />
        )}
      </div>

      <div className="mx-auto max-w-5xl px-4">
        <div className="relative -mt-20 flex flex-col items-center md:flex-row md:items-end">
          <div className="relative h-40 w-40 overflow-hidden rounded-full border-4 border-white bg-white">
            <Image
              src={profileUser.photoURL || "/placeholder.svg?height=160&width=160"}
              alt={profileUser.displayName}
              fill
              className="object-cover"
            />
          </div>

          <div className="mt-4 flex flex-1 flex-col items-center text-center md:ml-6 md:items-start md:text-left">
            <h1 className="text-3xl font-bold">{profileUser.displayName}</h1>
            <p className="text-gray-600">
              {profileUser.address && (
                <span className="flex items-center justify-center md:justify-start">
                  <MapPin className="mr-1 h-4 w-4" />
                  {profileUser.address}
                </span>
              )}
            </p>
          </div>

          <div className="mt-4 flex space-x-2 md:mt-0">
            {isOwnProfile ? (
              <Button onClick={() => setShowEditModal(true)} className="flex items-center">
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </Button>
            ) : (
              <>
                <Button onClick={handleFriendAction} variant={friendStatus === "friends" ? "outline" : "default"}>
                  {friendStatus === "none" && "Add Friend"}
                  {friendStatus === "pending" && "Cancel Request"}
                  {friendStatus === "requested" && "Accept Request"}
                  {friendStatus === "friends" && "Unfriend"}
                </Button>
                <Button>Message</Button>
              </>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-8 flex justify-center space-x-8 border-b border-gray-200 pb-4">
          <div className="text-center">
            <div className="text-2xl font-bold">{profileUser.posts?.length || 0}</div>
            <div className="text-sm text-gray-600">Posts</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{profileUser.friends?.length || 0}</div>
            <div className="text-sm text-gray-600">Friends</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">0</div>
            <div className="text-sm text-gray-600">Following</div>
          </div>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="posts" className="mt-6">
          <TabsList className="mb-4">
            <TabsTrigger value="posts">Posts</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="friends">Friends</TabsTrigger>
            <TabsTrigger value="photos">Photos</TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-6">
            {profileUser.posts && profileUser.posts.length > 0 ? (
              profileUser.posts.map((post) => <FeedPost key={post._id} post={post} />)
            ) : (
              <div className="rounded-lg border border-gray-200 p-8 text-center">
                <p className="text-gray-500">No posts yet</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="about">
            <div className="rounded-lg border border-gray-200 p-6">
              <h3 className="mb-4 text-xl font-semibold">About</h3>
              <div className="space-y-4">
                {profileUser.phoneNumber && (
                  <div className="flex items-center">
                    <Phone className="mr-2 h-5 w-5 text-gray-500" />
                    <span>{profileUser.phoneNumber}</span>
                  </div>
                )}
                {profileUser.address && (
                  <div className="flex items-center">
                    <MapPin className="mr-2 h-5 w-5 text-gray-500" />
                    <span>{profileUser.address}</span>
                  </div>
                )}
                {profileUser.dob && (
                  <div className="flex items-center">
                    <Calendar className="mr-2 h-5 w-5 text-gray-500" />
                    <span>{new Date(profileUser.dob).toLocaleDateString()}</span>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="friends">
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
              {profileUser.friends && profileUser.friends.length > 0 ? (
                profileUser.friends.map((friend: any) => (
                  <div key={friend._id} className="rounded-lg border border-gray-200 p-4 text-center">
                    <div className="mx-auto h-20 w-20 overflow-hidden rounded-full">
                      <Image
                        src={friend.photoURL || "/placeholder.svg?height=80&width=80"}
                        alt={friend.displayName}
                        width={80}
                        height={80}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <h4 className="mt-2 font-medium">{friend.displayName}</h4>
                  </div>
                ))
              ) : (
                <div className="col-span-full rounded-lg border border-gray-200 p-8 text-center">
                  <p className="text-gray-500">No friends yet</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="photos">
            <div className="rounded-lg border border-gray-200 p-8 text-center">
              <p className="text-gray-500">No photos yet</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {showEditModal && <ProfileEditModal user={profileUser} onClose={() => setShowEditModal(false)} />}
    </div>
  )
}
