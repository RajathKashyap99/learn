"use client"

import { useContext, useEffect, useState } from "react"
import { SocketContext } from "@/context/socket-context"
import { UserContext } from "@/context/user-context"
import FeedPost from "@/components/feed-post"
import CreatePostForm from "@/components/create-post-form"
import type { Post } from "@/types/post"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import StoriesSection from "@/components/stories-section"
import RightSidebar from "@/components/right-sidebar"

export default function Dashboard() {
  const socket = useContext(SocketContext)
  const { user } = useContext(UserContext)
  const [posts, setPosts] = useState<Post[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!socket) return

    // Get all posts
    socket.emit("get-posts-request")

    socket.on("get-posts-response", (data) => {
      setPosts(data)
      setIsLoading(false)
    })

    socket.on("create-post-response", (data) => {
      setPosts(data)
    })

    return () => {
      socket.off("get-posts-response")
      socket.off("create-post-response")
    }
  }, [socket])

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="flex h-full">
      <div className="flex-1 overflow-auto p-4 md:p-6">
        <div className="mx-auto max-w-3xl">
          <StoriesSection />

          <div className="mt-6">
            <h2 className="mb-4 text-2xl font-bold">Feeds</h2>

            <Tabs defaultValue="popular" className="mb-6">
              <TabsList>
                <TabsTrigger value="popular">Popular</TabsTrigger>
                <TabsTrigger value="latest">Latest</TabsTrigger>
              </TabsList>
            </Tabs>

            <CreatePostForm />

            <div className="mt-6 space-y-6">
              {posts.map((post) => (
                <FeedPost key={post._id} post={post} />
              ))}
            </div>
          </div>
        </div>
      </div>

      <RightSidebar />
    </div>
  )
}
