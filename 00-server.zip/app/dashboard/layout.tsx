"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Sidebar from "@/components/sidebar"
import { io, type Socket } from "socket.io-client"
import { SocketContext } from "@/context/socket-context"
import { UserContext } from "@/context/user-context"
import type { User } from "@/types/user"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [socket, setSocket] = useState<Socket | null>(null)
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem("user")
    if (!storedUser) {
      router.push("/")
      return
    }

    const userData = JSON.parse(storedUser) as User
    setUser(userData)

    // Connect to socket server
    const socketInstance = io("http://localhost:3000")
    setSocket(socketInstance)

    // Get user data from backend
    socketInstance.on("connect", () => {
      console.log("Connected to socket server")
      socketInstance.emit("get-user-by-email-request", {
        email: userData.email,
        displayName: userData.displayName,
        photoURL: userData.photoURL,
        accessToken: userData.accessToken,
        socket_id: socketInstance.id,
      })
    })

    socketInstance.on("get-user-by-email-response", (response) => {
      console.log("User data received", response)
      const updatedUser = { ...response, accessToken: userData.accessToken }
      localStorage.setItem("user", JSON.stringify(updatedUser))
      setUser(updatedUser)
      setIsLoading(false)
    })

    socketInstance.on("get-user-by-email-error", (error) => {
      console.error("Error getting user data:", error)
      setIsLoading(false)
    })

    return () => {
      socketInstance.disconnect()
    }
  }, [router])

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <SocketContext.Provider value={socket}>
      <UserContext.Provider value={{ user, setUser }}>
        <div className="flex h-screen bg-gray-50">
          <Sidebar />
          <main className="flex-1 overflow-auto">{children}</main>
        </div>
      </UserContext.Provider>
    </SocketContext.Provider>
  )
}
