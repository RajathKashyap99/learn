"use client"

import type React from "react"

import { useContext, useEffect, useState, useRef } from "react"
import { SocketContext } from "@/context/socket-context"
import { UserContext } from "@/context/user-context"
import type { User } from "@/types/user"
import type { Chat } from "@/types/chat"
import Image from "next/image"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send, ImageIcon, Paperclip } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function MessagesPage() {
  const socket = useContext(SocketContext)
  const { user } = useContext(UserContext)
  const [friends, setFriends] = useState<User[]>([])
  const [selectedFriend, setSelectedFriend] = useState<User | null>(null)
  const [messages, setMessages] = useState<Chat[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!socket || !user) return

    // Get friends
    socket.emit("get-friends-request", user._id)

    socket.on("get-friends-response", (data) => {
      if (data.friends) {
        setFriends(data.friends)
        setIsLoading(false)
      }
    })

    socket.on("send-message-response", (message) => {
      if (
        (message.sender === user._id && message.receiver === selectedFriend?._id) ||
        (message.receiver === user._id && message.sender === selectedFriend?._id)
      ) {
        setMessages((prev) => [...prev, message])
      }
    })

    return () => {
      socket.off("get-friends-response")
      socket.off("send-message-response")
    }
  }, [socket, user, selectedFriend])

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const selectFriend = (friend: User) => {
    setSelectedFriend(friend)
    if (socket && user) {
      socket.emit("get-messages-request", {
        sender: user._id,
        receiver: friend._id,
      })

      socket.on("get-messages-response", (data) => {
        setMessages(data)
      })
    }
  }

  const sendMessage = () => {
    if (!socket || !user || !selectedFriend || !newMessage.trim()) return

    const message = {
      message: newMessage,
      sender: user._id,
      receiver: selectedFriend._id,
      type: "text",
    }

    socket.emit("send-message-request", message)
    setNewMessage("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage()
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-t-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="flex h-full">
      {/* Friends list */}
      <div className="w-80 border-r border-gray-200 bg-white">
        <div className="border-b border-gray-200 p-4">
          <h2 className="text-xl font-bold">Messages</h2>
        </div>
        <ScrollArea className="h-[calc(100vh-10rem)]">
          {friends.length > 0 ? (
            friends.map((friend) => (
              <div
                key={friend._id}
                className={`flex cursor-pointer items-center gap-3 border-b border-gray-100 p-4 hover:bg-gray-50 ${
                  selectedFriend?._id === friend._id ? "bg-blue-50" : ""
                }`}
                onClick={() => selectFriend(friend)}
              >
                <div className="relative h-12 w-12 overflow-hidden rounded-full">
                  <Image
                    src={friend.photoURL || "/placeholder.svg?height=48&width=48"}
                    alt={friend.displayName}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">{friend.displayName}</h3>
                  <p className="text-sm text-gray-500">Click to start chatting</p>
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-gray-500">No friends yet. Add friends to start messaging.</div>
          )}
        </ScrollArea>
      </div>

      {/* Chat area */}
      <div className="flex flex-1 flex-col">
        {selectedFriend ? (
          <>
            {/* Chat header */}
            <div className="flex items-center border-b border-gray-200 bg-white p-4">
              <div className="relative h-10 w-10 overflow-hidden rounded-full">
                <Image
                  src={selectedFriend.photoURL || "/placeholder.svg?height=40&width=40"}
                  alt={selectedFriend.displayName}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="ml-3">
                <h3 className="font-medium">{selectedFriend.displayName}</h3>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 bg-gray-50 p-4">
              <div className="space-y-4">
                {messages.length > 0 ? (
                  messages.map((message) => {
                    const isOwn = message.sender === user?._id
                    return (
                      <div key={message._id} className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[70%] rounded-lg p-3 ${
                            isOwn ? "bg-blue-500 text-white" : "bg-white text-gray-800"
                          }`}
                        >
                          <p>{message.message}</p>
                          <p className={`text-right text-xs ${isOwn ? "text-blue-100" : "text-gray-500"}`}>
                            {formatDistanceToNow(new Date(message.timestamp), { addSuffix: true })}
                          </p>
                        </div>
                      </div>
                    )
                  })
                ) : (
                  <div className="text-center text-gray-500">No messages yet. Start the conversation!</div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Message input */}
            <div className="border-t border-gray-200 bg-white p-4">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon">
                  <ImageIcon className="h-5 w-5" />
                </Button>
                <Button variant="outline" size="icon">
                  <Paperclip className="h-5 w-5" />
                </Button>
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={handleKeyPress}
                  placeholder="Type a message..."
                  className="flex-1"
                />
                <Button onClick={sendMessage} disabled={!newMessage.trim()}>
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex h-full flex-col items-center justify-center bg-gray-50 p-4 text-center text-gray-500">
            <div className="mb-4 rounded-full bg-gray-200 p-6">
              <Send className="h-12 w-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-700">Your Messages</h3>
            <p className="mt-2 max-w-md">Select a friend from the list to start a conversation</p>
          </div>
        )}
      </div>
    </div>
  )
}
