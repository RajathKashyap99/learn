"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"

export default function Home() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [displayName, setDisplayName] = useState("")
  const [photoURL, setPhotoURL] = useState("https://github.com/shadcn.png")
  const [isLogin, setIsLogin] = useState(true)

  useEffect(() => {
    // Check if user is already logged in
    const user = localStorage.getItem("user")
    if (user) {
      router.push("/dashboard")
    }
  }, [router])

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault()

    // Simulate authentication
    if (isLogin) {
      // In a real app, you would validate credentials with your backend
      const mockUser = {
        email,
        displayName: "Cyndy Lillibridge",
        photoURL: "https://github.com/shadcn.png",
        accessToken: "mock-token-" + Math.random(),
        _id: "user-" + Math.random(),
      }

      localStorage.setItem("user", JSON.stringify(mockUser))
      router.push("/dashboard")
    } else {
      // Register new user
      const mockUser = {
        email,
        displayName,
        photoURL,
        accessToken: "mock-token-" + Math.random(),
        _id: "user-" + Math.random(),
      }

      localStorage.setItem("user", JSON.stringify(mockUser))
      router.push("/dashboard")
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-r from-blue-100 to-purple-100 p-4">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-blue-600">Echo Mate</h1>
          <p className="text-gray-600">Connect with friends and share your moments</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{isLogin ? "Login" : "Create Account"}</CardTitle>
            <CardDescription>
              {isLogin ? "Enter your email to sign in to your account" : "Fill in the details to create a new account"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAuth} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="m@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              {!isLogin && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="name">Display Name</Label>
                    <Input
                      id="name"
                      placeholder="Your Name"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="photo">Profile Photo URL</Label>
                    <Input
                      id="photo"
                      placeholder="https://example.com/photo.jpg"
                      value={photoURL}
                      onChange={(e) => setPhotoURL(e.target.value)}
                    />
                  </div>
                </>
              )}

              <Button type="submit" className="w-full">
                {isLogin ? "Sign In" : "Create Account"}
              </Button>
            </form>
          </CardContent>
          <CardFooter>
            <Button variant="link" className="w-full" onClick={() => setIsLogin(!isLogin)}>
              {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
