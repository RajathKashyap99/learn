import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import api, { apiService } from "../lib/api";

// User interface to match our MongoDB model
interface User {
  _id: string;
  username: string;
  email: string;
  fullName: string;
  bio?: string;
  location?: string;
  website?: string;
  avatarUrl?: string;
  coverUrl?: string;
  verified: boolean;
  isFollowing?: boolean;
  followersCount?: number;
  followingCount?: number;
}

// Registration data type
interface RegisterData {
  username: string;
  email: string;
  password: string;
  fullName?: string;
}

// Login data type
interface LoginData {
  username: string;
  password: string;
}

// Auth response containing JWT token
interface AuthResponse {
  token: string;
  _id: string;
  username: string;
  email: string;
  fullName: string;
  avatarUrl?: string;
  verified: boolean;
  [key: string]: any; // For other possible fields
}

// Context type definition
type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<User, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<User, Error, RegisterData>;
};

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [isInitialized, setIsInitialized] = useState(false);
  
  // Check if we have a token on component mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      // Token exists, we'll load the user in the query below
      queryClient.invalidateQueries({ queryKey: ['/auth/user'] });
    } else {
      // No token, set initialized
      setIsInitialized(true);
    }
  }, []);

  // Query to get current user
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<User | null, Error>({
    queryKey: ['/auth/user'],
    queryFn: async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) return null;
        
        const response = await apiService.auth.getCurrentUser();
        setIsInitialized(true);
        return response.data;
      } catch (error) {
        console.error('Error fetching user:', error);
        localStorage.removeItem('token');
        setIsInitialized(true);
        return null;
      }
    },
    enabled: !isInitialized,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      const response = await apiService.auth.login(credentials);
      const { token, ...userData } = response.data;
      localStorage.setItem('token', token);
      return userData as User;
    },
    onSuccess: (userData: User) => {
      queryClient.setQueryData(['/auth/user'], userData);
      toast({
        title: "Welcome back!",
        description: `You are now logged in as ${userData.username}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid username or password",
        variant: "destructive",
      });
    },
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (userData: RegisterData) => {
      const response = await apiService.auth.register(userData);
      const { token, ...user } = response.data;
      localStorage.setItem('token', token);
      return user as User;
    },
    onSuccess: (userData: User) => {
      queryClient.setQueryData(['/auth/user'], userData);
      toast({
        title: "Account created!",
        description: `Welcome to Connecto, ${userData.username}!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Registration failed",
        description: error.message || "Could not create account",
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      try {
        await apiService.auth.logout();
      } catch (error) {
        console.log('Logout from server failed, continuing with client logout');
      } finally {
        // Client-side logout is always needed
        localStorage.removeItem('token');
      }
    },
    onSuccess: () => {
      queryClient.setQueryData(['/auth/user'], null);
      toast({
        title: "Logged out",
        description: "You have been logged out successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Logout issue",
        description: "You were logged out, but there was a server error",
        variant: "default",
      });
      // Still clear the local data
      localStorage.removeItem('token');
      queryClient.setQueryData(['/auth/user'], null);
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading: isLoading && !isInitialized,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
