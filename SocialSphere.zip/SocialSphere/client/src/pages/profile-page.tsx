import { useQuery } from "@tanstack/react-query";
import { Post, User } from "@shared/schema";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import PostCard from "@/components/post/post-card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useParams } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Link as LinkIcon, MapPin, CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import FollowButton from "@/components/user/follow-button";
import { Button } from "@/components/ui/button";

interface PostWithAuthor {
  post: Post;
  author: User;
}

export default function ProfilePage() {
  const { username } = useParams();
  const { user: currentUser } = useAuth();
  
  // If no username provided, use current user's profile
  const profileUsername = username || currentUser?.username;
  
  const {
    data: profileUser,
    isLoading: isLoadingProfile,
  } = useQuery<User>({
    queryKey: ["/api/users/by-username", profileUsername],
    enabled: !!profileUsername,
  });
  
  const {
    data: userPosts,
    isLoading: isLoadingPosts,
  } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/users", profileUser?.id, "posts"],
    enabled: !!profileUser?.id,
  });
  
  const {
    data: likedPosts,
    isLoading: isLoadingLiked,
  } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/users", profileUser?.id, "liked"],
    enabled: !!profileUser?.id,
  });
  
  const isLoading = isLoadingProfile || (isLoadingPosts && isLoadingLiked);
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-10">
        <LoadingSpinner size="lg" />
      </div>
    );
  }
  
  if (!profileUser) {
    return (
      <div className="text-center p-10 bg-card rounded-lg mx-4 mt-4">
        <h3 className="text-xl font-medium mb-2">User not found</h3>
        <p className="text-muted-foreground">
          The user you're looking for doesn't exist or has been deleted.
        </p>
      </div>
    );
  }
  
  const isOwnProfile = currentUser?.id === profileUser.id;
  const joinedDate = profileUser.createdAt 
    ? new Date(profileUser.createdAt) 
    : new Date();

  return (
    <div className="space-y-4">
      {/* Cover Photo */}
      <div className="h-48 bg-gradient-to-r from-primary/20 to-primary/40 relative">
        {profileUser.coverUrl && (
          <img 
            src={profileUser.coverUrl} 
            alt="Cover" 
            className="w-full h-full object-cover"
          />
        )}
      </div>
      
      {/* Profile Header */}
      <div className="px-4 relative">
        <div className="flex justify-between">
          <Avatar className="h-24 w-24 border-4 border-background -mt-12 relative z-10">
            <AvatarImage src={profileUser.avatarUrl || ""} alt={profileUser.username} />
            <AvatarFallback>{profileUser.username.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>
          
          <div className="mt-4">
            {isOwnProfile ? (
              <Button variant="outline">Edit Profile</Button>
            ) : (
              <FollowButton 
                userId={profileUser.id} 
                isFollowing={profileUser.isFollowing || false} 
              />
            )}
          </div>
        </div>
        
        <div className="mt-4">
          <div className="flex items-center mb-1">
            <h1 className="text-2xl font-bold">{profileUser.fullName || profileUser.username}</h1>
            {profileUser.verified && (
              <Badge variant="outline" className="ml-2 p-1 h-6 w-6 rounded-full flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-primary" />
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground">@{profileUser.username}</p>
          
          {profileUser.bio && (
            <p className="mt-3">{profileUser.bio}</p>
          )}
          
          <div className="flex flex-wrap gap-x-4 gap-y-2 mt-3 text-sm text-muted-foreground">
            {profileUser.location && (
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{profileUser.location}</span>
              </div>
            )}
            
            {profileUser.website && (
              <div className="flex items-center">
                <LinkIcon className="h-4 w-4 mr-1" />
                <a 
                  href={profileUser.website.startsWith('http') ? profileUser.website : `https://${profileUser.website}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  {profileUser.website.replace(/^https?:\/\//, '')}
                </a>
              </div>
            )}
            
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              <span>Joined {formatDistanceToNow(joinedDate, { addSuffix: true })}</span>
            </div>
          </div>
          
          <div className="flex gap-4 mt-4">
            <div>
              <span className="font-bold">{profileUser.followingCount || 0}</span>{" "}
              <span className="text-muted-foreground">Following</span>
            </div>
            <div>
              <span className="font-bold">{profileUser.followersCount || 0}</span>{" "}
              <span className="text-muted-foreground">Followers</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Posts & Likes Tabs */}
      <div className="border-b border-border">
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="posts">Posts</TabsTrigger>
            <TabsTrigger value="likes">Likes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="posts" className="p-4 space-y-4">
            {isLoadingPosts ? (
              <div className="flex justify-center py-10">
                <LoadingSpinner size="md" />
              </div>
            ) : userPosts && userPosts.length > 0 ? (
              userPosts.map((item) => (
                <PostCard key={item.post.id} post={item.post} author={item.author} />
              ))
            ) : (
              <div className="text-center p-10 bg-card rounded-lg">
                <h3 className="text-lg font-medium mb-2">No posts yet</h3>
                <p className="text-muted-foreground">
                  {isOwnProfile ? "You haven't posted anything yet." : `${profileUser.username} hasn't posted anything yet.`}
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="likes" className="p-4 space-y-4">
            {isLoadingLiked ? (
              <div className="flex justify-center py-10">
                <LoadingSpinner size="md" />
              </div>
            ) : likedPosts && likedPosts.length > 0 ? (
              likedPosts.map((item) => (
                <PostCard key={item.post.id} post={item.post} author={item.author} />
              ))
            ) : (
              <div className="text-center p-10 bg-card rounded-lg">
                <h3 className="text-lg font-medium mb-2">No liked posts</h3>
                <p className="text-muted-foreground">
                  {isOwnProfile ? "You haven't liked any posts yet." : `${profileUser.username} hasn't liked any posts yet.`}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
