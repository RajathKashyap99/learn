export async function uploadToS3(files: File[]): Promise<string[]> {
  try {
    const formData = new FormData();
    files.forEach((file, index) => {
      formData.append(`file${index}`, file);
    });

    const response = await fetch('/api/upload', {
      method: 'POST',
      body: formData,
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error('Failed to upload images');
    }

    const result = await response.json();
    return result.urls;
  } catch (error) {
    console.error('Error uploading to S3:', error);
    throw error;
  }
}
