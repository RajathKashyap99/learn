import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { LoadingSpinner } from "../ui/loading-spinner";

interface FollowButtonProps {
  userId: number;
  isFollowing: boolean;
}

export default function FollowButton({ userId, isFollowing: initialIsFollowing }: FollowButtonProps) {
  const [isFollowing, setIsFollowing] = useState(initialIsFollowing);
  const { toast } = useToast();
  
  const followMutation = useMutation({
    mutationFn: async () => {
      const newFollowState = !isFollowing;
      // Optimistically update UI
      setIsFollowing(newFollowState);
      
      await apiRequest("POST", `/api/users/${userId}/follow`, { follow: newFollowState });
    },
    onError: (error) => {
      // Revert on error
      setIsFollowing(!isFollowing);
      toast({
        title: "Error",
        description: `Failed to ${isFollowing ? 'unfollow' : 'follow'} user: ${error.message}`,
        variant: "destructive",
      });
    },
    onSettled: () => {
      // Refresh related data
      queryClient.invalidateQueries({ queryKey: ["/api/users/suggested"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/following"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/followers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
    },
  });

  return (
    <Button
      variant={isFollowing ? "outline" : "default"}
      size="sm"
      className={`text-xs px-3 py-1 rounded-full`}
      onClick={() => followMutation.mutate()}
      disabled={followMutation.isPending}
    >
      {followMutation.isPending ? (
        <LoadingSpinner size="sm" />
      ) : (
        isFollowing ? "Unfollow" : "Follow"
      )}
    </Button>
  );
}
