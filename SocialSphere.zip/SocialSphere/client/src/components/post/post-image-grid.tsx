import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface PostImageGridProps {
  images: string[];
}

export default function PostImageGrid({ images }: PostImageGridProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  if (!images || images.length === 0) return null;
  
  let gridClass = "";
  
  if (images.length === 1) {
    gridClass = "grid-cols-1";
  } else if (images.length === 2) {
    gridClass = "grid-cols-2 gap-2";
  } else if (images.length === 3) {
    gridClass = "grid-cols-2 gap-2";
  } else if (images.length === 4) {
    gridClass = "grid-cols-2 gap-2";
  }
  
  const openLightbox = (image: string) => {
    setSelectedImage(image);
  };
  
  const closeLightbox = () => {
    setSelectedImage(null);
  };
  
  return (
    <>
      <div className={`grid ${gridClass}`}>
        {images.length === 1 && (
          <img 
            src={images[0]} 
            alt="Post media" 
            className="w-full h-auto max-h-96 object-cover rounded-lg cursor-pointer" 
            onClick={() => openLightbox(images[0])}
          />
        )}
        
        {images.length === 2 && images.map((image, index) => (
          <img 
            key={index} 
            src={image} 
            alt={`Post media ${index + 1}`} 
            className="w-full h-48 object-cover rounded-lg cursor-pointer" 
            onClick={() => openLightbox(image)}
          />
        ))}
        
        {images.length === 3 && (
          <>
            <img 
              src={images[0]} 
              alt="Post media 1" 
              className="w-full h-64 object-cover rounded-lg cursor-pointer row-span-2" 
              onClick={() => openLightbox(images[0])}
            />
            <div className="space-y-2">
              <img 
                src={images[1]} 
                alt="Post media 2" 
                className="w-full h-[calc(50%-4px)] object-cover rounded-lg cursor-pointer" 
                onClick={() => openLightbox(images[1])}
              />
              <img 
                src={images[2]} 
                alt="Post media 3" 
                className="w-full h-[calc(50%-4px)] object-cover rounded-lg cursor-pointer" 
                onClick={() => openLightbox(images[2])}
              />
            </div>
          </>
        )}
        
        {images.length === 4 && images.map((image, index) => (
          <img 
            key={index} 
            src={image} 
            alt={`Post media ${index + 1}`} 
            className="w-full h-40 object-cover rounded-lg cursor-pointer" 
            onClick={() => openLightbox(image)}
          />
        ))}
      </div>
      
      <Dialog open={!!selectedImage} onOpenChange={closeLightbox}>
        <DialogContent className="max-w-screen-lg p-0 bg-transparent border-none">
          <img 
            src={selectedImage || ""} 
            alt="Enlarged post media" 
            className="w-full h-auto max-h-[80vh] object-contain"
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
