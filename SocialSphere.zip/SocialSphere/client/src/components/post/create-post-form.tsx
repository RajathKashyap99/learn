import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Image, X, MapPin, Video } from "lucide-react";
import { useState, useRef } from "react";
import { uploadToS3 } from "@/lib/aws-s3";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { LoadingSpinner } from "../ui/loading-spinner";

const createPostSchema = z.object({
  content: z.string().min(1, "Post cannot be empty").max(500, "Post is too long"),
});

type CreatePostFormValues = z.infer<typeof createPostSchema>;

interface CreatePostFormProps {
  onSuccess?: () => void;
}

export default function CreatePostForm({ onSuccess }: CreatePostFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const form = useForm<CreatePostFormValues>({
    resolver: zodResolver(createPostSchema),
    defaultValues: {
      content: "",
    },
  });
  
  const createPostMutation = useMutation({
    mutationFn: async (data: CreatePostFormValues) => {
      let mediaUrls: string[] = [];
      
      if (selectedFiles.length > 0) {
        setIsUploading(true);
        try {
          mediaUrls = await uploadToS3(selectedFiles);
        } catch (error) {
          throw new Error("Failed to upload media");
        } finally {
          setIsUploading(false);
        }
      }
      
      const postData = {
        content: data.content,
        mediaUrls,
      };
      
      const res = await apiRequest("POST", "/api/posts", postData);
      return await res.json();
    },
    onSuccess: () => {
      form.reset();
      setSelectedFiles([]);
      setPreviews([]);
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
      toast({
        title: "Success",
        description: "Your post has been created!",
      });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create post: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleImageSelect = () => {
    fileInputRef.current?.click();
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      if (files.length + selectedFiles.length > 4) {
        toast({
          title: "Error",
          description: "You can only upload up to 4 images per post",
          variant: "destructive",
        });
        return;
      }
      
      // Create preview URLs
      const newPreviews = files.map(file => URL.createObjectURL(file));
      setPreviews([...previews, ...newPreviews]);
      setSelectedFiles([...selectedFiles, ...files]);
    }
  };
  
  const removeFile = (index: number) => {
    const newFiles = [...selectedFiles];
    const newPreviews = [...previews];
    
    // Release object URL to prevent memory leaks
    URL.revokeObjectURL(newPreviews[index]);
    
    newFiles.splice(index, 1);
    newPreviews.splice(index, 1);
    
    setSelectedFiles(newFiles);
    setPreviews(newPreviews);
  };
  
  const onSubmit = (data: CreatePostFormValues) => {
    createPostMutation.mutate(data);
  };
  
  const isSubmitting = createPostMutation.isPending || isUploading;

  return (
    <div className="bg-card p-4 mb-4 rounded-lg shadow-sm">
      <div className="flex items-start space-x-4">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user?.avatarUrl || ""} alt={user?.username || ""} />
          <AvatarFallback>{user?.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
        </Avatar>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex-1 min-w-0">
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Textarea
                      placeholder="What's happening?"
                      className="w-full px-3 py-2 bg-background rounded-lg border border-input focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                      rows={2}
                      disabled={isSubmitting}
                      {...field}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            {/* Preview Images */}
            {previews.length > 0 && (
              <div className={`grid gap-2 mt-3 ${previews.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                {previews.map((preview, index) => (
                  <div key={index} className="relative">
                    <img 
                      src={preview} 
                      alt="Preview" 
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6 rounded-full"
                      onClick={() => removeFile(index)}
                      disabled={isSubmitting}
                      type="button"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
            
            <div className="flex justify-between items-center mt-3">
              <div className="flex space-x-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="text-primary hover:text-primary/80 p-2 rounded-full hover:bg-primary/10"
                  onClick={handleImageSelect}
                  disabled={isSubmitting || selectedFiles.length >= 4}
                >
                  <Image className="h-5 w-5" />
                </Button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  multiple
                  className="hidden"
                  disabled={isSubmitting}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="text-primary hover:text-primary/80 p-2 rounded-full hover:bg-primary/10"
                  disabled={isSubmitting}
                >
                  <Video className="h-5 w-5" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="text-primary hover:text-primary/80 p-2 rounded-full hover:bg-primary/10"
                  disabled={isSubmitting}
                >
                  <MapPin className="h-5 w-5" />
                </Button>
              </div>
              <Button
                type="submit"
                className="bg-primary hover:bg-primary/90 text-white px-4 py-1.5 rounded-full font-medium text-sm"
                disabled={isSubmitting}
              >
                {isSubmitting ? <LoadingSpinner size="sm" /> : "Post"}
              </Button>
            </div>
          </form>
        </Form>
      </div>
    </div>
  );
}
