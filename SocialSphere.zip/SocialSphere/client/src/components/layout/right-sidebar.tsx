import { useQuery } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { Link } from "wouter";
import UserCard from "../user/user-card";
import { Button } from "@/components/ui/button";
import { LoadingSpinner } from "../ui/loading-spinner";
import { Separator } from "@/components/ui/separator";

export default function RightSidebar() {
  const {
    data: suggestedUsers,
    isLoading: suggestedUsersLoading,
  } = useQuery<User[]>({
    queryKey: ["/api/users/suggested"],
  });

  const {
    data: trendingTopics,
    isLoading: trendingTopicsLoading,
  } = useQuery<{ category: string; topic: string; count: number }[]>({
    queryKey: ["/api/trending"],
  });

  return (
    <aside className="hidden lg:block w-80 p-4 border-l border-border md:sticky md:top-16 md:h-[calc(100vh-4rem)] overflow-y-auto scrollbar-hide">
      {/* Who to follow */}
      <div className="bg-card rounded-lg p-4 mb-4">
        <h3 className="text-lg font-medium mb-4">Who to follow</h3>
        
        {suggestedUsersLoading ? (
          <div className="flex justify-center my-4">
            <LoadingSpinner size="sm" />
          </div>
        ) : (
          <>
            {suggestedUsers?.slice(0, 3).map((user) => (
              <div key={user.id} className="mb-4">
                <UserCard user={user} showFollowButton />
              </div>
            ))}
            <Link href="/explore" className="text-primary hover:text-primary/80 text-sm block mt-4">
              Show more
            </Link>
          </>
        )}
      </div>
      
      {/* Trending Topics */}
      <div className="bg-card rounded-lg p-4">
        <h3 className="text-lg font-medium mb-4">Trending</h3>
        
        {trendingTopicsLoading ? (
          <div className="flex justify-center my-4">
            <LoadingSpinner size="sm" />
          </div>
        ) : (
          <>
            {trendingTopics?.slice(0, 4).map((topic, index) => (
              <div key={index} className="mb-4">
                <p className="text-xs text-muted-foreground">Trending in {topic.category}</p>
                <h4 className="text-base font-medium text-foreground">#{topic.topic}</h4>
                <p className="text-xs text-muted-foreground">{topic.count.toLocaleString()} posts</p>
              </div>
            ))}
            <Link href="/explore" className="text-primary hover:text-primary/80 text-sm block mt-4">
              Show more
            </Link>
          </>
        )}
      </div>
      
      {/* Footer Links */}
      <div className="mt-6 text-xs text-muted-foreground">
        <div className="flex flex-wrap gap-2">
          <Link href="/terms" className="hover:text-primary">Terms of Service</Link>
          <Link href="/privacy" className="hover:text-primary">Privacy Policy</Link>
          <Link href="/cookie" className="hover:text-primary">Cookie Policy</Link>
          <Link href="/accessibility" className="hover:text-primary">Accessibility</Link>
          <Link href="/ads" className="hover:text-primary">Ads Info</Link>
          <Link href="/more" className="hover:text-primary">More</Link>
        </div>
        <p className="mt-2">© {new Date().getFullYear()} Connecto, Inc.</p>
      </div>
    </aside>
  );
}
