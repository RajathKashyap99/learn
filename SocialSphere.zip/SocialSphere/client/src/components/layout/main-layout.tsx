import { ReactNode } from "react";
import Header from "./header";
import Sidebar from "./sidebar";
import RightSidebar from "./right-sidebar";

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <Sidebar />
        <main className="flex-1 min-w-0 pb-16 md:pb-0">
          {children}
        </main>
        <RightSidebar />
      </div>
    </div>
  );
}
