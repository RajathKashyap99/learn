import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  Home, 
  Compass, 
  Bell, 
  MessageSquare, 
  Bookmark, 
  User, 
  Settings, 
  PlusCircle
} from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CreatePostForm from "../post/create-post-form";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [createPostOpen, setCreatePostOpen] = useState(false);
  
  // Navigation items for both mobile and desktop
  const navItems = [
    { href: "/", label: "Home", icon: Home, active: location === "/" },
    { href: "/explore", label: "Explore", icon: Compass, active: location === "/explore" },
    { href: "/notifications", label: "Notifications", icon: Bell, active: location === "/notifications" },
    { href: "/messages", label: "Messages", icon: MessageSquare, active: location === "/messages" },
    { href: "/bookmarks", label: "Bookmarks", icon: Bookmark, active: location === "/bookmarks" },
    { href: "/profile", label: "Profile", icon: User, active: location.startsWith("/profile") },
    { href: "/settings", label: "Settings", icon: Settings, active: location === "/settings" },
  ];

  return (
    <>
      {/* Mobile Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border flex justify-around py-2 z-40">
        {navItems.slice(0, 5).map((item) => (
          <Link key={item.href} href={item.href} className={`p-2 ${item.active ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`}>
            <item.icon className="h-5 w-5" />
          </Link>
        ))}
      </div>
      
      {/* Mobile create post button */}
      <div className="fixed right-6 bottom-20 md:hidden z-40">
        <Button 
          onClick={() => setCreatePostOpen(true)}
          size="icon" 
          className="rounded-full w-14 h-14 bg-primary hover:bg-primary/90"
        >
          <PlusCircle className="h-6 w-6" />
        </Button>
      </div>
      
      {/* Desktop Sidebar */}
      <aside className="md:w-64 md:flex-shrink-0 border-r border-border bg-card md:h-[calc(100vh-4rem)] md:sticky md:top-16 z-30 hidden md:block">
        <nav className="p-4 space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`group flex items-center px-2 py-2 text-base font-medium rounded-md ${
                item.active
                  ? 'bg-background text-primary'
                  : 'text-foreground hover:bg-background hover:text-primary'
              }`}
            >
              <item.icon className={`mr-4 h-5 w-5 ${
                item.active 
                  ? 'text-primary' 
                  : 'text-muted-foreground group-hover:text-primary'
              }`} />
              {item.label}
            </Link>
          ))}
          
          <Button 
            onClick={() => setCreatePostOpen(true)}
            className="w-full bg-primary hover:bg-primary/90 text-white mt-6 py-3 px-4 rounded-full font-medium transition duration-200"
          >
            Create Post
          </Button>
        </nav>
        
        {/* User Info (Desktop Only) */}
        <div className="hidden md:block border-t border-border mt-6 pt-4 mx-4">
          <Link href="/profile" className="flex items-center">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user?.avatarUrl || ""} alt={user?.username || ""} />
              <AvatarFallback>{user?.username?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.fullName || user?.username}</p>
              <p className="text-xs text-muted-foreground">@{user?.username}</p>
            </div>
          </Link>
        </div>
      </aside>
      
      {/* Create Post Dialog */}
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create a Post</DialogTitle>
          </DialogHeader>
          <CreatePostForm onSuccess={() => setCreatePostOpen(false)} />
        </DialogContent>
      </Dialog>
    </>
  );
}
