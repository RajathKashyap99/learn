import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { uploadToS3, generateSignedUrl } from "./s3-handler";
import multer from "multer";
import { insertPostSchema } from "@shared/schema";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Middleware to check if user is authenticated
  const isAuthenticated = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    return res.status(401).json({ message: "Unauthorized" });
  };

  // Upload images to S3
  app.post("/api/upload", isAuthenticated, upload.array("files", 4), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }
      
      const uploadPromises = files.map(file => uploadToS3(file));
      const urls = await Promise.all(uploadPromises);
      
      res.json({ urls });
    } catch (error) {
      console.error("Error uploading to S3:", error);
      res.status(500).json({ message: "Failed to upload files" });
    }
  });

  // Upload avatar
  app.post("/api/upload/avatar", isAuthenticated, upload.single("avatar"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const url = await uploadToS3(req.file, "avatars");
      res.json({ url });
    } catch (error) {
      console.error("Error uploading avatar:", error);
      res.status(500).json({ message: "Failed to upload avatar" });
    }
  });

  // Posts
  app.get("/api/posts/feed", isAuthenticated, async (req, res) => {
    try {
      const posts = await storage.getFeedPosts(req.user!.id);
      res.json(posts);
    } catch (error) {
      console.error("Error getting feed posts:", error);
      res.status(500).json({ message: "Failed to get feed posts" });
    }
  });

  app.get("/api/posts/following", isAuthenticated, async (req, res) => {
    try {
      const posts = await storage.getFollowingPosts(req.user!.id);
      res.json(posts);
    } catch (error) {
      console.error("Error getting following posts:", error);
      res.status(500).json({ message: "Failed to get following posts" });
    }
  });

  app.get("/api/posts/trending", isAuthenticated, async (req, res) => {
    try {
      const cursor = req.query.cursor as string;
      const limit = parseInt(req.query.limit as string || "10");
      const posts = await storage.getTrendingPosts(limit, cursor);
      res.json(posts);
    } catch (error) {
      console.error("Error getting trending posts:", error);
      res.status(500).json({ message: "Failed to get trending posts" });
    }
  });

  app.post("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const postData = insertPostSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid post data", errors: error.errors });
      }
      console.error("Error creating post:", error);
      res.status(500).json({ message: "Failed to create post" });
    }
  });

  app.delete("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getPost(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      if (post.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized to delete this post" });
      }
      
      await storage.deletePost(postId);
      res.status(200).json({ message: "Post deleted" });
    } catch (error) {
      console.error("Error deleting post:", error);
      res.status(500).json({ message: "Failed to delete post" });
    }
  });

  app.post("/api/posts/:id/like", isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const { liked } = req.body;
      
      if (liked) {
        await storage.likePost(req.user!.id, postId);
      } else {
        await storage.unlikePost(req.user!.id, postId);
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error liking/unliking post:", error);
      res.status(500).json({ message: "Failed to like/unlike post" });
    }
  });

  app.post("/api/posts/:id/bookmark", isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const { bookmarked } = req.body;
      
      if (bookmarked) {
        await storage.bookmarkPost(req.user!.id, postId);
      } else {
        await storage.unbookmarkPost(req.user!.id, postId);
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error bookmarking/unbookmarking post:", error);
      res.status(500).json({ message: "Failed to bookmark/unbookmark post" });
    }
  });

  app.get("/api/bookmarks", isAuthenticated, async (req, res) => {
    try {
      const bookmarks = await storage.getUserBookmarks(req.user!.id);
      res.json(bookmarks);
    } catch (error) {
      console.error("Error getting bookmarks:", error);
      res.status(500).json({ message: "Failed to get bookmarks" });
    }
  });

  // Users
  app.get("/api/users/by-username/:username", isAuthenticated, async (req, res) => {
    try {
      const { username } = req.params;
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if current user is following this user
      const isFollowing = await storage.isFollowing(req.user!.id, user.id);
      const followersCount = await storage.getFollowersCount(user.id);
      const followingCount = await storage.getFollowingCount(user.id);
      
      res.json({
        ...user,
        isFollowing,
        followersCount,
        followingCount
      });
    } catch (error) {
      console.error("Error getting user:", error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.get("/api/users/:id/posts", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const posts = await storage.getUserPosts(userId, req.user!.id);
      res.json(posts);
    } catch (error) {
      console.error("Error getting user posts:", error);
      res.status(500).json({ message: "Failed to get user posts" });
    }
  });

  app.get("/api/users/:id/liked", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const posts = await storage.getUserLikedPosts(userId, req.user!.id);
      res.json(posts);
    } catch (error) {
      console.error("Error getting user liked posts:", error);
      res.status(500).json({ message: "Failed to get user liked posts" });
    }
  });

  app.post("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const followingId = parseInt(req.params.id);
      const followerId = req.user!.id;
      const { follow } = req.body;
      
      if (followerId === followingId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }
      
      if (follow) {
        await storage.followUser(followerId, followingId);
      } else {
        await storage.unfollowUser(followerId, followingId);
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error following/unfollowing user:", error);
      res.status(500).json({ message: "Failed to follow/unfollow user" });
    }
  });

  app.get("/api/users/suggested", isAuthenticated, async (req, res) => {
    try {
      const users = await storage.getSuggestedUsers(req.user!.id);
      res.json(users);
    } catch (error) {
      console.error("Error getting suggested users:", error);
      res.status(500).json({ message: "Failed to get suggested users" });
    }
  });

  app.get("/api/users/popular", isAuthenticated, async (req, res) => {
    try {
      const users = await storage.getPopularUsers(req.user!.id);
      res.json(users);
    } catch (error) {
      console.error("Error getting popular users:", error);
      res.status(500).json({ message: "Failed to get popular users" });
    }
  });

  app.patch("/api/user/profile", isAuthenticated, async (req, res) => {
    try {
      const { fullName, bio, location, website, avatarUrl } = req.body;
      const updatedUser = await storage.updateUserProfile(req.user!.id, {
        fullName,
        bio,
        location,
        website,
        avatarUrl
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.patch("/api/user/account", isAuthenticated, async (req, res) => {
    try {
      const { email, currentPassword, newPassword } = req.body;
      
      // Verify current password
      const user = await storage.getUser(req.user!.id);
      const { comparePasswords } = await import("./auth");
      const passwordMatch = await comparePasswords(currentPassword, user!.password);
      
      if (!passwordMatch) {
        return res.status(401).json({ message: "Current password is incorrect" });
      }
      
      // Check if updating to new email that already exists
      if (email !== user!.email) {
        const existingEmail = await storage.getUserByEmail(email);
        if (existingEmail) {
          return res.status(400).json({ message: "Email already in use" });
        }
      }
      
      // Update account info
      const { hashPassword } = await import("./auth");
      const updatedUser = await storage.updateUserAccount(
        req.user!.id,
        email,
        newPassword ? await hashPassword(newPassword) : undefined
      );
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating account:", error);
      res.status(500).json({ message: "Failed to update account" });
    }
  });

  // Search
  app.get("/api/search/users", isAuthenticated, async (req, res) => {
    try {
      const query = req.query.q as string;
      
      if (!query || query.trim().length < 1) {
        return res.json([]);
      }
      
      const users = await storage.searchUsers(query, req.user!.id);
      res.json(users);
    } catch (error) {
      console.error("Error searching users:", error);
      res.status(500).json({ message: "Failed to search users" });
    }
  });

  app.get("/api/search/posts", isAuthenticated, async (req, res) => {
    try {
      const query = req.query.q as string;
      
      if (!query || query.trim().length < 1) {
        return res.json([]);
      }
      
      const posts = await storage.searchPosts(query, req.user!.id);
      res.json(posts);
    } catch (error) {
      console.error("Error searching posts:", error);
      res.status(500).json({ message: "Failed to search posts" });
    }
  });

  // Trending topics
  app.get("/api/trending", isAuthenticated, async (req, res) => {
    try {
      const topics = await storage.getTrendingTopics();
      res.json(topics);
    } catch (error) {
      console.error("Error getting trending topics:", error);
      res.status(500).json({ message: "Failed to get trending topics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
