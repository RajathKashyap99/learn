/**
 * Middleware to protect routes by verifying JWT token
 */
const jwt = require('jsonwebtoken');
const User = require('../models/User');

/**
 * Authentication middleware to protect routes
 * Verifies the token from Authorization header or cookies
 * and attaches the user to the request object
 */
const auth = async (req, res, next) => {
  try {
    let token;
    
    // Get token from Authorization header (Bearer token)
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    } 
    // Get token from cookie
    else if (req.cookies && req.cookies.token) {
      token = req.cookies.token;
    }
    
    // Check if token exists
    if (!token) {
      return res.status(401).json({ message: 'Not authorized, no token provided' });
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Add user to request object (without password)
    const user = await User.findById(decoded.id).select('-password');
    
    // If user not found
    if (!user) {
      return res.status(401).json({ message: 'User not found or token invalid' });
    }
    
    // Set user on request object
    req.user = user;
    
    // Proceed to the next middleware or route handler
    next();
  } catch (error) {
    // Handle jwt verification errors
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    
    // Handle expired jwt tokens
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Token expired, please login again' });
    }
    
    // Handle other errors
    console.error('Auth middleware error:', error);
    return res.status(500).json({ message: 'Server error during authentication' });
  }
};

/**
 * Admin middleware to restrict access to admin users only
 * Must be used after the auth middleware
 */
const admin = (req, res, next) => {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ message: 'Not authorized as an admin' });
  }
  next();
};

module.exports = { auth, admin };