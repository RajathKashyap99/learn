const Notification = require('../models/Notification');
const User = require('../models/User');

// @desc    Get user's notifications
// @route   GET /api/notifications
// @access  Private
const getNotifications = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const startIndex = (page - 1) * limit;
    
    const notifications = await Notification.find({ recipient: req.user._id })
      .sort({ createdAt: -1 })
      .skip(startIndex)
      .limit(limit)
      .populate('sender', 'username fullName avatarUrl')
      .populate('post', 'content mediaUrls');
    
    // Get total count for pagination
    const totalNotifications = await Notification.countDocuments({ recipient: req.user._id });
    
    // Get unread count
    const unreadCount = await Notification.countDocuments({ 
      recipient: req.user._id,
      read: false
    });
    
    res.json({
      notifications,
      currentPage: page,
      totalPages: Math.ceil(totalNotifications / limit),
      hasMore: startIndex + limit < totalNotifications,
      unreadCount
    });
  } catch (error) {
    console.error('Error in getNotifications:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Mark notifications as read
// @route   PUT /api/notifications/read
// @access  Private
const markAsRead = async (req, res) => {
  try {
    const { notificationIds } = req.body;
    
    if (!notificationIds || !Array.isArray(notificationIds) || notificationIds.length === 0) {
      // If no specific IDs provided, mark all as read
      await Notification.updateMany(
        { recipient: req.user._id, read: false },
        { read: true }
      );
    } else {
      // Mark specific notifications as read
      await Notification.updateMany(
        { 
          _id: { $in: notificationIds }, 
          recipient: req.user._id 
        },
        { read: true }
      );
    }
    
    // Get updated unread count
    const unreadCount = await Notification.countDocuments({ 
      recipient: req.user._id,
      read: false
    });
    
    res.json({ 
      success: true,
      unreadCount
    });
  } catch (error) {
    console.error('Error in markAsRead:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Create notification (internal use)
// @access  Private
const createNotification = async (type, recipientId, senderId, postId = null, commentData = null) => {
  try {
    // Don't notify yourself
    if (recipientId.toString() === senderId.toString()) {
      return null;
    }
    
    const notification = new Notification({
      type,
      recipient: recipientId,
      sender: senderId,
      post: postId,
      comment: commentData,
      read: false
    });
    
    await notification.save();
    return notification;
  } catch (error) {
    console.error('Error creating notification:', error);
    return null;
  }
};

// @desc    Delete notifications related to a post
// @access  Private
const deletePostNotifications = async (postId) => {
  try {
    await Notification.deleteMany({ post: postId });
  } catch (error) {
    console.error('Error deleting post notifications:', error);
  }
};

module.exports = {
  getNotifications,
  markAsRead,
  createNotification,
  deletePostNotifications
};