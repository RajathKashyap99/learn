const Post = require('../models/Post');
const User = require('../models/User');
const Bookmark = require('../models/Bookmark');

// @desc    Create a post
// @route   POST /api/posts
// @access  Private
const createPost = async (req, res) => {
  try {
    const { content, mediaUrls } = req.body;

    if (!content && (!mediaUrls || mediaUrls.length === 0)) {
      return res.status(400).json({ message: 'Post must contain text or media' });
    }

    const newPost = new Post({
      user: req.user._id,
      content,
      mediaUrls: mediaUrls || []
    });

    const post = await newPost.save();

    // Return the populated post
    const populatedPost = await Post.findById(post._id).populate('user', 
      'username fullName avatarUrl verified'
    );

    res.status(201).json(populatedPost);
  } catch (error) {
    console.error('Error in createPost:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get feed posts
// @route   GET /api/posts/feed
// @access  Private
const getFeedPosts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;

    // Get IDs of users the current user is following
    const following = req.user.following;
    following.push(req.user._id); // Include user's own posts

    // Find posts from followed users, sorted by most recent
    const posts = await Post.find({ user: { $in: following } })
      .sort({ createdAt: -1 })
      .skip(startIndex)
      .limit(limit)
      .populate('user', 'username fullName avatarUrl verified');

    // Get total count for pagination
    const totalPosts = await Post.countDocuments({ user: { $in: following } });

    // Check if posts are liked or bookmarked by the current user
    const processedPosts = await Promise.all(posts.map(async (post) => {
      const isLiked = post.likes.includes(req.user._id);
      const bookmark = await Bookmark.findOne({ user: req.user._id, post: post._id });
      
      // Convert to plain object to add properties
      const postObj = post.toObject();
      postObj.isLiked = isLiked;
      postObj.isBookmarked = !!bookmark;
      
      return postObj;
    }));

    res.json({
      posts: processedPosts,
      currentPage: page,
      totalPages: Math.ceil(totalPosts / limit),
      hasMore: startIndex + limit < totalPosts
    });
  } catch (error) {
    console.error('Error in getFeedPosts:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get trending posts
// @route   GET /api/posts/trending
// @access  Private
const getTrendingPosts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;

    // Get posts with most likes and comments, within the last 7 days
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const posts = await Post.aggregate([
      {
        $match: {
          createdAt: { $gte: oneWeekAgo }
        }
      },
      {
        $addFields: {
          likesCount: { $size: '$likes' },
          commentsCount: { $size: '$comments' },
          // Calculate engagement score
          engagementScore: {
            $add: [
              { $size: '$likes' },
              { $multiply: [{ $size: '$comments' }, 2] }, // Comments weighted more
              '$shares'
            ]
          }
        }
      },
      { $sort: { engagementScore: -1 } },
      { $skip: startIndex },
      { $limit: limit }
    ]);

    // Populate user data
    await Post.populate(posts, { path: 'user', select: 'username fullName avatarUrl verified' });

    // Check if posts are liked or bookmarked by the current user
    const processedPosts = await Promise.all(posts.map(async (post) => {
      const isLiked = post.likes.includes(req.user._id);
      const bookmark = await Bookmark.findOne({ user: req.user._id, post: post._id });
      
      // Add properties
      post.isLiked = isLiked;
      post.isBookmarked = !!bookmark;
      
      return post;
    }));

    // Get total count for pagination (aproximate)
    const totalPosts = await Post.countDocuments({ createdAt: { $gte: oneWeekAgo } });

    res.json({
      posts: processedPosts,
      currentPage: page,
      totalPages: Math.ceil(totalPosts / limit),
      hasMore: startIndex + limit < totalPosts
    });
  } catch (error) {
    console.error('Error in getTrendingPosts:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get posts by user ID
// @route   GET /api/posts/user/:userId
// @access  Private
const getUserPosts = async (req, res) => {
  try {
    const userId = req.params.userId;
    
    // Make sure user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;

    // Find posts by user ID
    const posts = await Post.find({ user: userId })
      .sort({ createdAt: -1 })
      .skip(startIndex)
      .limit(limit)
      .populate('user', 'username fullName avatarUrl verified');

    // Get total count for pagination
    const totalPosts = await Post.countDocuments({ user: userId });

    // Check if posts are liked or bookmarked by the current user
    const processedPosts = await Promise.all(posts.map(async (post) => {
      const isLiked = post.likes.includes(req.user._id);
      const bookmark = await Bookmark.findOne({ user: req.user._id, post: post._id });
      
      // Convert to plain object to add properties
      const postObj = post.toObject();
      postObj.isLiked = isLiked;
      postObj.isBookmarked = !!bookmark;
      
      return postObj;
    }));

    res.json({
      posts: processedPosts,
      currentPage: page,
      totalPages: Math.ceil(totalPosts / limit),
      hasMore: startIndex + limit < totalPosts
    });
  } catch (error) {
    console.error('Error in getUserPosts:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Like or unlike a post
// @route   POST /api/posts/:id/like
// @access  Private
const toggleLike = async (req, res) => {
  try {
    const postId = req.params.id;
    const userId = req.user._id;

    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Check if the post is already liked by user
    const isLiked = post.likes.includes(userId);
    
    if (isLiked) {
      // Remove like
      post.likes = post.likes.filter(id => id.toString() !== userId.toString());
    } else {
      // Add like
      post.likes.push(userId);
    }

    await post.save();

    res.json({ 
      success: true, 
      isLiked: !isLiked,
      likesCount: post.likes.length
    });
  } catch (error) {
    console.error('Error in toggleLike:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Bookmark or unbookmark a post
// @route   POST /api/posts/:id/bookmark
// @access  Private
const toggleBookmark = async (req, res) => {
  try {
    const postId = req.params.id;
    const userId = req.user._id;

    // Check if post exists
    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }

    // Check if bookmark exists
    const bookmark = await Bookmark.findOne({ user: userId, post: postId });
    
    if (bookmark) {
      // Remove bookmark
      await Bookmark.findByIdAndDelete(bookmark._id);
      
      res.json({ 
        success: true, 
        isBookmarked: false
      });
    } else {
      // Add bookmark
      await Bookmark.create({
        user: userId,
        post: postId
      });
      
      res.json({ 
        success: true, 
        isBookmarked: true
      });
    }
  } catch (error) {
    console.error('Error in toggleBookmark:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get a single post
// @route   GET /api/posts/:id
// @access  Private
const getPost = async (req, res) => {
  try {
    const postId = req.params.id;
    
    const post = await Post.findById(postId)
      .populate('user', 'username fullName avatarUrl verified')
      .populate('comments.user', 'username fullName avatarUrl');
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Check if post is liked or bookmarked by current user
    const isLiked = post.likes.includes(req.user._id);
    const bookmark = await Bookmark.findOne({ user: req.user._id, post: post._id });
    
    // Convert to plain object to add properties
    const postObj = post.toObject();
    postObj.isLiked = isLiked;
    postObj.isBookmarked = !!bookmark;
    
    res.json(postObj);
  } catch (error) {
    console.error('Error in getPost:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Delete a post
// @route   DELETE /api/posts/:id
// @access  Private
const deletePost = async (req, res) => {
  try {
    const postId = req.params.id;
    const userId = req.user._id;
    
    const post = await Post.findById(postId);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    // Check post belongs to user
    if (post.user.toString() !== userId.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this post' });
    }
    
    // Delete post and related bookmarks
    await Post.findByIdAndDelete(postId);
    await Bookmark.deleteMany({ post: postId });
    
    res.json({ success: true, message: 'Post deleted' });
  } catch (error) {
    console.error('Error in deletePost:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Add comment to post
// @route   POST /api/posts/:id/comment
// @access  Private
const addComment = async (req, res) => {
  try {
    const { text } = req.body;
    
    if (!text || text.trim() === '') {
      return res.status(400).json({ message: 'Comment text is required' });
    }
    
    const post = await Post.findById(req.params.id);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    const comment = {
      user: req.user._id,
      text,
      date: new Date()
    };
    
    post.comments.unshift(comment);
    await post.save();
    
    // Return populated comment
    const populatedPost = await Post.findById(post._id)
      .populate('comments.user', 'username fullName avatarUrl');
    
    res.json(populatedPost.comments[0]);
  } catch (error) {
    console.error('Error in addComment:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get bookmarked posts
// @route   GET /api/posts/bookmarks
// @access  Private
const getBookmarkedPosts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    
    // Find all bookmarks for the user
    const bookmarks = await Bookmark.find({ user: req.user._id })
      .sort({ createdAt: -1 })
      .skip(startIndex)
      .limit(limit)
      .populate({
        path: 'post',
        populate: {
          path: 'user',
          select: 'username fullName avatarUrl verified'
        }
      });
    
    // Get total count for pagination
    const totalBookmarks = await Bookmark.countDocuments({ user: req.user._id });
    
    // Extract posts and add isLiked and isBookmarked flags
    const posts = bookmarks
      .filter(bookmark => bookmark.post) // Filter out any null posts
      .map(bookmark => {
        const post = bookmark.post.toObject();
        post.isBookmarked = true;
        post.isLiked = post.likes.includes(req.user._id);
        return post;
      });
    
    res.json({
      posts,
      currentPage: page,
      totalPages: Math.ceil(totalBookmarks / limit),
      hasMore: startIndex + limit < totalBookmarks
    });
  } catch (error) {
    console.error('Error in getBookmarkedPosts:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  createPost,
  getFeedPosts,
  getTrendingPosts,
  getUserPosts,
  toggleLike,
  toggleBookmark,
  getPost,
  deletePost,
  addComment,
  getBookmarkedPosts
};