/**
 * AWS S3 configuration module
 * Initializes and exports the AWS S3 client instance
 */
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

// Configure AWS SDK with credentials from environment variables
const s3Config = {
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1'
};

// Initialize S3 client
const s3 = new AWS.S3(s3Config);

// Bucket name from environment
const bucketName = process.env.AWS_S3_BUCKET_NAME;

/**
 * Generate a unique key for storing files in S3
 * @param {string} originalName - Original file name
 * @param {string} userId - User ID for associating files with users
 * @param {string} type - Type of upload (posts, avatars, etc.)
 * @returns {string} Generated unique key (path)
 */
const generateS3Key = (originalName, userId, type = 'posts') => {
  const fileExtension = path.extname(originalName);
  const fileName = `${userId}-${uuidv4()}${fileExtension}`;
  return `uploads/${type}/${fileName}`;
};

/**
 * Upload a file directly to S3
 * @param {Buffer} fileBuffer - File data as Buffer
 * @param {string} originalName - Original file name
 * @param {string} userId - User ID
 * @param {string} type - Type of upload (posts, avatars, etc.) 
 * @param {string} contentType - MIME type of the file
 * @returns {Promise<string>} URL of the uploaded file
 */
const uploadToS3Direct = async (fileBuffer, originalName, userId, type = 'posts', contentType) => {
  try {
    if (!bucketName) {
      throw new Error('S3 bucket name not configured');
    }

    const key = generateS3Key(originalName, userId, type);

    const params = {
      Bucket: bucketName,
      Key: key,
      Body: fileBuffer,
      ContentType: contentType,
      ACL: 'public-read' // Make the file publicly accessible
    };

    const result = await s3.upload(params).promise();
    return result.Location; // Return the URL of the uploaded file
  } catch (error) {
    console.error('S3 upload error:', error);
    throw error;
  }
};

/**
 * Generate a signed URL for temporary access to a private S3 object
 * @param {string} key - S3 key (path) of the object
 * @param {number} expiresIn - Expiration time in seconds
 * @returns {Promise<string>} Signed URL
 */
const getSignedUrl = async (key, expiresIn = 3600) => {
  try {
    if (!bucketName) {
      throw new Error('S3 bucket name not configured');
    }

    const params = {
      Bucket: bucketName,
      Key: key,
      Expires: expiresIn
    };

    return await s3.getSignedUrlPromise('getObject', params);
  } catch (error) {
    console.error('S3 signed URL error:', error);
    throw error;
  }
};

/**
 * Delete an object from S3
 * @param {string} key - S3 key (path) of the object to delete
 * @returns {Promise<void>}
 */
const deleteFromS3 = async (key) => {
  try {
    if (!bucketName) {
      throw new Error('S3 bucket name not configured');
    }

    const params = {
      Bucket: bucketName,
      Key: key
    };

    await s3.deleteObject(params).promise();
  } catch (error) {
    console.error('S3 delete error:', error);
    throw error;
  }
};

module.exports = {
  s3,
  bucketName,
  uploadToS3Direct,
  getSignedUrl,
  deleteFromS3,
  generateS3Key
};