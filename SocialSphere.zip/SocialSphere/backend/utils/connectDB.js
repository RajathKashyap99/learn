/**
 * MongoDB connection utility
 * Provides a function to connect to MongoDB using Mongoose
 */
const mongoose = require('mongoose');

// Import db configuration
const connectToMongoDB = require('../config/db');

/**
 * Connect to MongoDB and handle connection events
 * This is a wrapper around the db configuration to provide
 * a cleaner API for connecting to MongoDB
 */
const connectDB = async () => {
  try {
    await connectToMongoDB();
  } catch (error) {
    console.error(`Failed to connect to MongoDB: ${error.message}`);
    // After 5 seconds, try to reconnect
    setTimeout(connectDB, 5000);
  }
};

module.exports = connectDB;