import express from "express"
import mongoose from "mongoose"
import cors from "cors"
import dotenv from "dotenv"
import helmet from "helmet"
import morgan from "morgan"
import multer from "multer"
import { S3Client } from "@aws-sdk/client-s3"
import multerS3 from "multer-s3"
import path from "path"
import { fileURLToPath } from "url"

// Routes
import authRoutes from "./routes/auth.js"
import userRoutes from "./routes/users.js"
import postRoutes from "./routes/posts.js"

// Models
import User from "./models/User.js"
import Post from "./models/Post.js"

// Middleware
import { verifyToken } from "./middleware/auth.js"

// Configuration
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
dotenv.config()
const app = express()
app.use(express.json())
app.use(helmet())
app.use(helmet.crossOriginResourcePolicy({ policy: "cross-origin" }))
app.use(morgan("common"))
app.use(cors())

// AWS S3 Configuration
const s3 = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
})

// File upload configuration
const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: process.env.AWS_S3_BUCKET_NAME,
    metadata: (req, file, cb) => {
      cb(null, { fieldName: file.fieldname })
    },
    key: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
      cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname))
    },
  }),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedFileTypes = /jpeg|jpg|png|gif/
    const extname = allowedFileTypes.test(path.extname(file.originalname).toLowerCase())
    const mimetype = allowedFileTypes.test(file.mimetype)

    if (extname && mimetype) {
      return cb(null, true)
    } else {
      cb(new Error("Only image files are allowed!"))
    }
  },
})

// Routes with files
app.post("/api/posts", verifyToken, upload.array("images", 4), async (req, res) => {
  try {
    const { userId, content, tags } = req.body
    const user = await User.findById(userId)

    if (!user) {
      return res.status(404).json({ message: "User not found" })
    }

    const imageUrls = req.files ? req.files.map((file) => file.location) : []

    const newPost = new Post({
      userId,
      content,
      images: imageUrls,
      tags: tags ? JSON.parse(tags) : [],
      likes: {},
      comments: [],
    })

    await newPost.save()

    const populatedPost = await Post.findById(newPost._id).populate({
      path: "userId",
      select: "username name avatar",
    })

    res.status(201).json(populatedPost)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.patch("/api/users/:id/avatar", verifyToken, upload.single("avatar"), async (req, res) => {
  try {
    const { id } = req.params

    if (req.user.id !== id) {
      return res.status(403).json({ message: "Unauthorized to update this user" })
    }

    const avatarUrl = req.file.location

    const updatedUser = await User.findByIdAndUpdate(id, { avatar: avatarUrl }, { new: true }).select("-password")

    res.status(200).json(updatedUser)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// Routes
app.use("/api/auth", authRoutes)
app.use("/api/users", userRoutes)
app.use("/api/posts", postRoutes)

// Mongoose setup
const PORT = process.env.PORT || 6001
mongoose
  .connect(process.env.MONGO_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    app.listen(PORT, () => console.log(`Server running on port: ${PORT}`))
  })
  .catch((error) => console.log(`${error} did not connect`))
