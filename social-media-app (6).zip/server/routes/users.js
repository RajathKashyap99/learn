import express from "express"
import bcrypt from "bcrypt"
import User from "../models/User.js"
import { verifyToken } from "../middleware/auth.js"

const router = express.Router()

// GET USER
router.get("/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password")
    if (!user) {
      return res.status(404).json({ message: "User not found" })
    }
    res.status(200).json(user)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// UPDATE USER
router.put("/:id", verifyToken, async (req, res) => {
  try {
    const { id } = req.params

    if (req.user.id !== id && !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized to update this user" })
    }

    // If password is being updated, hash it
    if (req.body.password) {
      const salt = await bcrypt.genSalt(10)
      req.body.password = await bcrypt.hash(req.body.password, salt)
    }

    const updatedUser = await User.findByIdAndUpdate(id, { $set: req.body }, { new: true }).select("-password")

    res.status(200).json(updatedUser)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// DELETE USER
router.delete("/:id", verifyToken, async (req, res) => {
  try {
    const { id } = req.params

    if (req.user.id !== id && !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized to delete this user" })
    }

    await User.findByIdAndDelete(id)

    res.status(200).json({ message: "User has been deleted" })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// FOLLOW USER
router.put("/:id/follow", verifyToken, async (req, res) => {
  try {
    const { id } = req.params
    const userId = req.user.id

    if (userId === id) {
      return res.status(400).json({ message: "You cannot follow yourself" })
    }

    const user = await User.findById(id)
    const currentUser = await User.findById(userId)

    if (!user || !currentUser) {
      return res.status(404).json({ message: "User not found" })
    }

    if (user.followers.includes(userId)) {
      return res.status(400).json({ message: "You already follow this user" })
    }

    await User.findByIdAndUpdate(id, { $push: { followers: userId } })
    await User.findByIdAndUpdate(userId, { $push: { following: id } })

    res.status(200).json({ message: "User has been followed" })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// UNFOLLOW USER
router.put("/:id/unfollow", verifyToken, async (req, res) => {
  try {
    const { id } = req.params
    const userId = req.user.id

    if (userId === id) {
      return res.status(400).json({ message: "You cannot unfollow yourself" })
    }

    const user = await User.findById(id)
    const currentUser = await User.findById(userId)

    if (!user || !currentUser) {
      return res.status(404).json({ message: "User not found" })
    }

    if (!user.followers.includes(userId)) {
      return res.status(400).json({ message: "You don't follow this user" })
    }

    await User.findByIdAndUpdate(id, { $pull: { followers: userId } })
    await User.findByIdAndUpdate(userId, { $pull: { following: id } })

    res.status(200).json({ message: "User has been unfollowed" })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET USER SUGGESTIONS
router.get("/suggestions/:id", verifyToken, async (req, res) => {
  try {
    const { id } = req.params
    const user = await User.findById(id)

    if (!user) {
      return res.status(404).json({ message: "User not found" })
    }

    // Get users that the current user is not following
    const suggestions = await User.find({
      _id: { $ne: id, $nin: user.following },
    })
      .select("username name avatar location")
      .limit(5)

    res.status(200).json(suggestions)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// SEARCH USERS
router.get("/search/:query", async (req, res) => {
  try {
    const { query } = req.params

    const users = await User.find({
      $or: [{ username: { $regex: query, $options: "i" } }, { name: { $regex: query, $options: "i" } }],
    }).select("username name avatar")

    res.status(200).json(users)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
