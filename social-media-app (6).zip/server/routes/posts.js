import express from "express"
import Post from "../models/Post.js"
import User from "../models/User.js"
import { verifyToken } from "../middleware/auth.js"

const router = express.Router()

// CREATE POST (handled in index.js with file upload)

// GET ALL POSTS (FEED)
router.get("/feed/:userId", verifyToken, async (req, res) => {
  try {
    const { userId } = req.params
    const user = await User.findById(userId)

    if (!user) {
      return res.status(404).json({ message: "User not found" })
    }

    // Get posts from user and followed users
    const followingPosts = await Post.find({
      userId: { $in: [...user.following, userId] },
    })
      .populate({
        path: "userId",
        select: "username name avatar",
      })
      .sort({ createdAt: -1 })

    res.status(200).json(followingPosts)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET EXPLORE POSTS
router.get("/explore", verifyToken, async (req, res) => {
  try {
    // Get popular posts (most likes)
    const posts = await Post.aggregate([
      {
        $addFields: {
          likesCount: { $size: { $objectToArray: "$likes" } },
        },
      },
      { $sort: { likesCount: -1, createdAt: -1 } },
      { $limit: 20 },
    ])

    // Populate user data
    const populatedPosts = await Post.populate(posts, {
      path: "userId",
      select: "username name avatar",
    })

    res.status(200).json(populatedPosts)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET USER POSTS
router.get("/user/:userId", async (req, res) => {
  try {
    const { userId } = req.params
    const posts = await Post.find({ userId })
      .populate({
        path: "userId",
        select: "username name avatar",
      })
      .sort({ createdAt: -1 })

    res.status(200).json(posts)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET POST BY ID
router.get("/:id", async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate({
      path: "userId",
      select: "username name avatar",
    })

    if (!post) {
      return res.status(404).json({ message: "Post not found" })
    }

    res.status(200).json(post)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// UPDATE POST
router.put("/:id", verifyToken, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({ message: "Post not found" })
    }

    if (post.userId.toString() !== req.user.id && !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized to update this post" })
    }

    const updatedPost = await Post.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true }).populate({
      path: "userId",
      select: "username name avatar",
    })

    res.status(200).json(updatedPost)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// DELETE POST
router.delete("/:id", verifyToken, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({ message: "Post not found" })
    }

    if (post.userId.toString() !== req.user.id && !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized to delete this post" })
    }

    await Post.findByIdAndDelete(req.params.id)

    res.status(200).json({ message: "Post has been deleted" })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// LIKE / UNLIKE POST
router.put("/:id/like", verifyToken, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({ message: "Post not found" })
    }

    const isLiked = post.likes.get(req.user.id)

    if (isLiked) {
      // Unlike
      post.likes.delete(req.user.id)
    } else {
      // Like
      post.likes.set(req.user.id, true)
    }

    const updatedPost = await Post.findByIdAndUpdate(req.params.id, { likes: post.likes }, { new: true }).populate({
      path: "userId",
      select: "username name avatar",
    })

    res.status(200).json(updatedPost)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ADD COMMENT
router.post("/:id/comment", verifyToken, async (req, res) => {
  try {
    const { text } = req.body

    if (!text) {
      return res.status(400).json({ message: "Comment text is required" })
    }

    const post = await Post.findById(req.params.id)

    if (!post) {
      return res.status(404).json({ message: "Post not found" })
    }

    const newComment = {
      userId: req.user.id,
      text,
    }

    post.comments.push(newComment)
    await post.save()

    // Populate the user data for the new comment
    const populatedPost = await Post.findById(req.params.id).populate({
      path: "comments.userId",
      select: "username name avatar",
    })

    res.status(201).json(populatedPost)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// DELETE COMMENT
router.delete("/:id/comment/:commentId", verifyToken, async (req, res) => {
  try {
    const { id, commentId } = req.params

    const post = await Post.findById(id)

    if (!post) {
      return res.status(404).json({ message: "Post not found" })
    }

    const comment = post.comments.id(commentId)

    if (!comment) {
      return res.status(404).json({ message: "Comment not found" })
    }

    if (comment.userId.toString() !== req.user.id && post.userId.toString() !== req.user.id && !req.user.isAdmin) {
      return res.status(403).json({ message: "Unauthorized to delete this comment" })
    }

    post.comments.pull(commentId)
    await post.save()

    res.status(200).json({ message: "Comment has been deleted" })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// SEARCH POSTS BY TAGS
router.get("/search/tags/:query", async (req, res) => {
  try {
    const { query } = req.params

    const posts = await Post.find({
      tags: { $in: [query] },
    })
      .populate({
        path: "userId",
        select: "username name avatar",
      })
      .sort({ createdAt: -1 })

    res.status(200).json(posts)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
