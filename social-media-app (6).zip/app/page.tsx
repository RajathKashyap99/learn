import { redirect } from "next/navigation"
import LandingPage from "@/components/landing-page"

export default function Home() {
  // In a real app, check for authentication here
  const isAuthenticated = false

  if (isAuthenticated) {
    redirect("/feed")
  }

  return <LandingPage />
}
