import FeedContent from "@/components/feed/feed-content"

export default function FeedPage() {
  return <FeedContent />
}
