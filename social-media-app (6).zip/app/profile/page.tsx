import ProfileContent from "@/components/profile/profile-content"

export default function ProfilePage() {
  return <ProfileContent />
}
