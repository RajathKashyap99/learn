"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Plus, Bell } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import CreatePostForm from "@/components/post/create-post-form"

export default function TopNavigation() {
  const [isSearchFocused, setIsSearchFocused] = useState(false)

  return (
    <div className="flex h-16 items-center justify-between border-b border-blue-900 bg-slate-900 px-4">
      <div className="relative w-full max-w-md">
        <Search
          className={`absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 transform ${isSearchFocused ? "text-blue-500" : "text-gray-400"}`}
        />
        <Input
          placeholder="Search..."
          className="pl-10 bg-slate-800 border-blue-800 text-white placeholder:text-gray-400 focus:border-blue-500"
          onFocus={() => setIsSearchFocused(true)}
          onBlur={() => setIsSearchFocused(false)}
        />
      </div>

      <div className="flex items-center space-x-2">
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="mr-2 h-4 w-4" />
              Create new post
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px] bg-slate-900 border-blue-800">
            <DialogHeader>
              <DialogTitle>Create a new post</DialogTitle>
            </DialogHeader>
            <CreatePostForm />
          </DialogContent>
        </Dialog>

        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-xs">
            2
          </span>
        </Button>
      </div>
    </div>
  )
}
