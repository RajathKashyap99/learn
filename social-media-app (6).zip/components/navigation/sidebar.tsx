"use client"

import { useRouter, usePathname } from "next/navigation"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Home, Compass, Bookmark, MessageSquare, BarChart2, Settings, LogOut } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function Sidebar() {
  const router = useRouter()
  const pathname = usePathname()
  const { toast } = useToast()

  // Mock user data - in a real app, this would come from your auth context
  const user = {
    name: "Cyndy Lillibridge",
    username: "cyndylillibridge",
    location: "Torrance, CA, United States",
    avatar: "/placeholder.svg?height=150&width=150",
    stats: {
      posts: 368,
      followers: "184.3K",
      following: "1.04M",
    },
  }

  const handleLogout = () => {
    // Clear authentication
    localStorage.removeItem("token")

    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    })

    router.push("/")
  }

  const navItems = [
    { name: "Feed", href: "/feed", icon: Home },
    { name: "Explore", href: "/explore", icon: Compass },
    { name: "My favorites", href: "/favorites", icon: Bookmark },
    { name: "Direct", href: "/messages", icon: MessageSquare },
    { name: "Stats", href: "/stats", icon: BarChart2 },
    { name: "Settings", href: "/settings", icon: Settings },
  ]

  return (
    <div className="flex h-full w-64 flex-col bg-slate-900 text-white">
      <div className="flex flex-col items-center p-6">
        <Avatar className="h-20 w-20 border-2 border-blue-500">
          <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
          <AvatarFallback>
            {user.name
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>
        <h2 className="mt-4 text-xl font-bold">{user.name}</h2>
        <p className="text-sm text-gray-400">{user.location}</p>

        <div className="mt-4 flex w-full justify-between text-center">
          <div>
            <p className="font-bold">{user.stats.posts}</p>
            <p className="text-xs text-gray-400">Posts</p>
          </div>
          <div>
            <p className="font-bold">{user.stats.followers}</p>
            <p className="text-xs text-gray-400">Followers</p>
          </div>
          <div>
            <p className="font-bold">{user.stats.following}</p>
            <p className="text-xs text-gray-400">Following</p>
          </div>
        </div>
      </div>

      <Separator className="bg-blue-900" />

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href

            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <Button
                    variant={isActive ? "secondary" : "ghost"}
                    className={`w-full justify-start ${isActive ? "bg-blue-800 text-white" : "text-gray-300 hover:text-white"}`}
                  >
                    <item.icon className="mr-2 h-5 w-5" />
                    {item.name}
                  </Button>
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      <Separator className="bg-blue-900" />

      <div className="p-4">
        <h3 className="mb-2 text-sm font-medium text-gray-400">Contacts</h3>
        <div className="space-y-2">
          {["Julie Mendez", "Marian Montgomery", "Joyce Reid"].map((contact) => (
            <div key={contact} className="flex items-center justify-between">
              <div className="flex items-center">
                <Avatar className="mr-2 h-8 w-8">
                  <AvatarFallback>
                    {contact
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm">{contact}</span>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                <MessageSquare className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button variant="link" className="mt-2 w-full text-xs text-blue-400">
            View All
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Button variant="ghost" className="w-full justify-start text-gray-300" onClick={handleLogout}>
          <LogOut className="mr-2 h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  )
}
