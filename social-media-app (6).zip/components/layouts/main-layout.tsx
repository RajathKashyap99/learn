"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Sidebar from "@/components/navigation/sidebar"
import TopNavigation from "@/components/navigation/top-navigation"
import { useToast } from "@/components/ui/use-toast"

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Check for authentication
    const token = localStorage.getItem("token")

    if (!token) {
      toast({
        variant: "destructive",
        title: "Authentication required",
        description: "Please log in to continue.",
      })
      router.push("/")
      return
    }

    // In a real app, validate the token with your backend
    setIsLoading(false)
  }, [router, toast])

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-blue-950">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-500 border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="flex h-screen bg-blue-950">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <TopNavigation />
        <main className="flex-1 overflow-auto p-4">{children}</main>
      </div>
    </div>
  )
}
