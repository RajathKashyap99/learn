import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

export default function FriendRequests() {
  // Mock friend requests data
  const requests = [
    {
      id: "1",
      name: "Lauralee Quintero",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    {
      id: "2",
      name: "Brittni Landoma",
      avatar: "/placeholder.svg?height=50&width=50",
    },
  ]

  return (
    <div className="rounded-lg bg-slate-900 p-4 border border-blue-900">
      <h3 className="mb-4 text-lg font-semibold text-white">
        Requests <span className="ml-1 rounded-full bg-blue-600 px-2 py-0.5 text-xs">2</span>
      </h3>

      <div className="space-y-4">
        {requests.map((request) => (
          <div key={request.id} className="flex items-start justify-between">
            <div className="flex items-center">
              <Avatar className="mr-3 h-10 w-10">
                <AvatarImage src={request.avatar || "/placeholder.svg"} alt={request.name} />
                <AvatarFallback>
                  {request.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium text-white">{request.name}</p>
                <p className="text-xs text-gray-400">wants to add you to friends</p>
                <div className="mt-2 flex space-x-2">
                  <Button size="sm" className="h-7 bg-blue-600 hover:bg-blue-700 text-xs">
                    Accept
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 border-blue-800 text-xs">
                    Decline
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
