"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import PostCard from "@/components/post/post-card"
import StoryCircle from "@/components/feed/story-circle"
import UserSuggestions from "@/components/feed/user-suggestions"
import FriendRequests from "@/components/feed/friend-requests"

export default function FeedContent() {
  const [posts, setPosts] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // In a real app, fetch posts from your API
    const fetchPosts = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock data
        const mockPosts = [
          {
            id: "1",
            user: {
              id: "user1",
              name: "Robert Fox",
              username: "alessandroveronezi",
              avatar: "/placeholder.svg?height=50&width=50",
            },
            content:
              "While Corfu give us the ability to shoot by the sea with amazing blue background full of light of the sky, Florina give us its gentle side. The humble atmosphere and Light of Florina which comes...",
            images: [
              "/placeholder.svg?height=400&width=600",
              "/placeholder.svg?height=300&width=400",
              "/placeholder.svg?height=300&width=400",
              "/placeholder.svg?height=300&width=400",
            ],
            likes: 1600,
            comments: 2300,
            createdAt: new Date().toISOString(),
            tags: ["landscape", "flora", "nature"],
          },
          {
            id: "2",
            user: {
              id: "user2",
              name: "Dianne Russell",
              username: "amandadasilva",
              avatar: "/placeholder.svg?height=50&width=50",
            },
            content: "Exploring the beautiful mountains this weekend! The views were absolutely breathtaking.",
            images: ["/placeholder.svg?height=400&width=600"],
            likes: 890,
            comments: 120,
            createdAt: new Date().toISOString(),
            tags: ["travel", "mountains", "weekend"],
          },
        ]

        setPosts(mockPosts)
      } catch (error) {
        console.error("Error fetching posts:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchPosts()
  }, [])

  // Mock stories data
  const stories = [
    { id: "1", username: "Add story", avatar: "", isAdd: true },
    { id: "2", username: "Robert", avatar: "/placeholder.svg?height=60&width=60" },
    { id: "3", username: "Emma", avatar: "/placeholder.svg?height=60&width=60" },
    { id: "4", username: "Sarah", avatar: "/placeholder.svg?height=60&width=60" },
    { id: "5", username: "David", avatar: "/placeholder.svg?height=60&width=60" },
    { id: "6", username: "Grace", avatar: "/placeholder.svg?height=60&width=60" },
    { id: "7", username: "Michael", avatar: "/placeholder.svg?height=60&width=60" },
  ]

  return (
    <div className="flex gap-6">
      <div className="flex-1 space-y-6">
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white">Stories</h2>
            <Button variant="link" className="text-blue-400">
              Watch all
            </Button>
          </div>

          <div className="flex space-x-4 overflow-x-auto pb-4">
            {stories.map((story) => (
              <StoryCircle key={story.id} username={story.username} avatar={story.avatar} isAdd={story.isAdd} />
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold text-white mb-4">Feeds</h2>

          <Tabs defaultValue="popular" className="mb-6">
            <TabsList className="bg-slate-800">
              <TabsTrigger value="popular" className="data-[state=active]:bg-blue-600">
                Popular
              </TabsTrigger>
              <TabsTrigger value="latest" className="data-[state=active]:bg-blue-600">
                Latest
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {isLoading ? (
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <div key={i} className="rounded-lg bg-slate-800 p-4 animate-pulse">
                  <div className="flex items-center space-x-4">
                    <div className="h-12 w-12 rounded-full bg-slate-700"></div>
                    <div className="space-y-2">
                      <div className="h-4 w-32 rounded bg-slate-700"></div>
                      <div className="h-3 w-24 rounded bg-slate-700"></div>
                    </div>
                  </div>
                  <div className="mt-4 h-64 rounded bg-slate-700"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              {posts.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="hidden w-80 space-y-6 lg:block">
        <FriendRequests />
        <UserSuggestions />
      </div>
    </div>
  )
}
