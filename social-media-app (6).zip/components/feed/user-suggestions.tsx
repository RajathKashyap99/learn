import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { UserPlus } from "lucide-react"

export default function UserSuggestions() {
  // Mock suggested users data
  const suggestions = [
    {
      id: "1",
      name: "Chantal Shelburne",
      location: "Memphis, TN, US",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    {
      id: "2",
      name: "Marci Senter",
      location: "Newark, NJ, US",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    {
      id: "3",
      name: "Janetta Rotolo",
      location: "Fort Worth, TX, US",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    {
      id: "4",
      name: "Tyra Dhillon",
      location: "Springfield, MA, US",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    {
      id: "5",
      name: "Marielle Wigington",
      location: "Honolulu, HI, US",
      avatar: "/placeholder.svg?height=50&width=50",
    },
  ]

  return (
    <div className="rounded-lg bg-slate-900 p-4 border border-blue-900">
      <h3 className="mb-4 text-lg font-semibold text-white">Suggestions for you</h3>

      <div className="space-y-4">
        {suggestions.map((user) => (
          <div key={user.id} className="flex items-center justify-between">
            <div className="flex items-center">
              <Avatar className="mr-3 h-10 w-10">
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback>
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium text-white">{user.name}</p>
                <p className="text-xs text-gray-400">{user.location}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-blue-400">
              <UserPlus className="h-5 w-5" />
            </Button>
          </div>
        ))}
      </div>

      <Button variant="link" className="mt-4 w-full text-blue-400">
        View All
      </Button>
    </div>
  )
}
