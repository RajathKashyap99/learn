import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Plus } from "lucide-react"

interface StoryCircleProps {
  username: string
  avatar: string
  isAdd?: boolean
}

export default function StoryCircle({ username, avatar, isAdd = false }: StoryCircleProps) {
  return (
    <div className="flex flex-col items-center space-y-2">
      <div
        className={`relative rounded-full p-1 ${isAdd ? "bg-blue-600" : "bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500"}`}
      >
        <Avatar className="h-16 w-16 border-2 border-slate-900 bg-slate-800">
          {isAdd ? (
            <div className="flex h-full w-full items-center justify-center bg-slate-800">
              <Plus className="h-8 w-8 text-blue-500" />
            </div>
          ) : (
            <>
              <AvatarImage src={avatar || "/placeholder.svg"} alt={username} />
              <AvatarFallback>{username[0]}</AvatarFallback>
            </>
          )}
        </Avatar>
      </div>
      <span className="text-xs text-gray-300">{username}</span>
    </div>
  )
}
