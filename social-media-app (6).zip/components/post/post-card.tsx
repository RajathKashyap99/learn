"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Heart, MessageCircle, Bookmark, Share2, MoreHorizontal } from "lucide-react"
import Image from "next/image"
import { formatDistanceToNow } from "date-fns"

interface PostCardProps {
  post: {
    id: string
    user: {
      id: string
      name: string
      username: string
      avatar: string
    }
    content: string
    images: string[]
    likes: number
    comments: number
    createdAt: string
    tags: string[]
  }
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(false)
  const [saved, setSaved] = useState(false)
  const [likesCount, setLikesCount] = useState(post.likes)

  const handleLike = () => {
    if (liked) {
      setLikesCount(likesCount - 1)
    } else {
      setLikesCount(likesCount + 1)
    }
    setLiked(!liked)
  }

  const handleSave = () => {
    setSaved(!saved)
  }

  const formatLikes = (count: number) => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}k`
    }
    return count.toString()
  }

  return (
    <Card className="overflow-hidden border-blue-900 bg-slate-900 text-white">
      <CardHeader className="flex flex-row items-center justify-between p-4">
        <div className="flex items-center space-x-3">
          <Avatar>
            <AvatarImage src={post.user.avatar || "/placeholder.svg"} alt={post.user.name} />
            <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">{post.user.name}</div>
            <div className="text-xs text-gray-400">@{post.user.username}</div>
          </div>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400">
              <MoreHorizontal className="h-5 w-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-slate-800 border-blue-900">
            <DropdownMenuItem className="text-white hover:bg-slate-700">Report post</DropdownMenuItem>
            <DropdownMenuItem className="text-white hover:bg-slate-700">Unfollow user</DropdownMenuItem>
            <DropdownMenuItem className="text-white hover:bg-slate-700">Copy link</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>

      <CardContent className="p-0">
        {post.images.length === 1 ? (
          <div className="relative h-96 w-full">
            <Image src={post.images[0] || "/placeholder.svg"} alt="Post image" fill className="object-cover" />
          </div>
        ) : (
          <div
            className={`grid gap-1 ${post.images.length === 2 ? "grid-cols-2" : post.images.length === 3 ? "grid-cols-2" : "grid-cols-2 grid-rows-2"}`}
          >
            {post.images.map((image, index) => (
              <div
                key={index}
                className={`relative ${
                  post.images.length === 3 && index === 0
                    ? "col-span-2 h-64"
                    : post.images.length === 3
                      ? "h-48"
                      : index === 0
                        ? "row-span-2 h-96"
                        : "h-48"
                }`}
              >
                <Image
                  src={image || "/placeholder.svg"}
                  alt={`Post image ${index + 1}`}
                  fill
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        )}
      </CardContent>

      <CardFooter className="flex flex-col items-start p-4">
        <div className="flex w-full items-center justify-between">
          <div className="flex space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className={`h-9 w-9 ${liked ? "text-red-500" : "text-gray-400"}`}
              onClick={handleLike}
            >
              <Heart className="h-6 w-6" fill={liked ? "currentColor" : "none"} />
            </Button>
            <Button variant="ghost" size="icon" className="h-9 w-9 text-gray-400">
              <MessageCircle className="h-6 w-6" />
            </Button>
            <Button variant="ghost" size="icon" className="h-9 w-9 text-gray-400">
              <Share2 className="h-6 w-6" />
            </Button>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className={`h-9 w-9 ${saved ? "text-blue-500" : "text-gray-400"}`}
            onClick={handleSave}
          >
            <Bookmark className="h-6 w-6" fill={saved ? "currentColor" : "none"} />
          </Button>
        </div>

        <div className="mt-2 text-sm font-medium">{formatLikes(likesCount)} likes</div>

        <div className="mt-2">
          <span className="font-medium">{post.user.name}</span> <span className="text-gray-300">{post.content}</span>
          {post.content.length > 100 && (
            <Button variant="link" className="h-auto p-0 text-blue-400">
              read more
            </Button>
          )}
        </div>

        <div className="mt-1 flex flex-wrap gap-1">
          {post.tags.map((tag) => (
            <span key={tag} className="text-blue-400">
              #{tag}
            </span>
          ))}
        </div>

        <div className="mt-2 text-xs text-gray-400">
          {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
        </div>
      </CardFooter>
    </Card>
  )
}
