"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ImageIcon, X, Upload } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function CreatePostForm() {
  const [content, setContent] = useState("")
  const [selectedImages, setSelectedImages] = useState<File[]>([])
  const [selectedImagePreviews, setSelectedImagePreviews] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files)

      if (files.length + selectedImages.length > 4) {
        toast({
          variant: "destructive",
          title: "Too many images",
          description: "You can only upload up to 4 images per post.",
        })
        return
      }

      setSelectedImages([...selectedImages, ...files])

      // Create preview URLs
      const newPreviews = files.map((file) => URL.createObjectURL(file))
      setSelectedImagePreviews([...selectedImagePreviews, ...newPreviews])
    }
  }

  const removeImage = (index: number) => {
    // Revoke the object URL to avoid memory leaks
    URL.revokeObjectURL(selectedImagePreviews[index])

    setSelectedImages(selectedImages.filter((_, i) => i !== index))
    setSelectedImagePreviews(selectedImagePreviews.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!content.trim() && selectedImages.length === 0) {
      toast({
        variant: "destructive",
        title: "Empty post",
        description: "Please add some text or images to your post.",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, you would upload the images to AWS S3 here
      // and then send the post data to your backend

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Post created",
        description: "Your post has been published successfully.",
      })

      // Reset form
      setContent("")
      setSelectedImages([])
      setSelectedImagePreviews([])
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create post. Please try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex space-x-3">
        <Avatar>
          <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Your avatar" />
          <AvatarFallback>YA</AvatarFallback>
        </Avatar>

        <Textarea
          placeholder="What's on your mind?"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="min-h-24 bg-slate-800 border-blue-800 text-white placeholder:text-gray-400 focus:border-blue-500"
        />
      </div>

      {selectedImagePreviews.length > 0 && (
        <div className={`grid gap-2 ${selectedImagePreviews.length === 1 ? "grid-cols-1" : "grid-cols-2"}`}>
          {selectedImagePreviews.map((preview, index) => (
            <div key={index} className="relative rounded-md overflow-hidden">
              <img
                src={preview || "/placeholder.svg"}
                alt={`Selected image ${index + 1}`}
                className="h-40 w-full object-cover"
              />
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="absolute right-2 top-2 h-6 w-6 rounded-full"
                onClick={() => removeImage(index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between">
        <Button type="button" variant="ghost" className="text-blue-400" onClick={() => fileInputRef.current?.click()}>
          <ImageIcon className="mr-2 h-5 w-5" />
          Add Photos
        </Button>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageSelect}
          accept="image/*"
          multiple
          className="hidden"
        />

        <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={isSubmitting}>
          {isSubmitting ? (
            <>
              <Upload className="mr-2 h-4 w-4 animate-spin" />
              Posting...
            </>
          ) : (
            "Post"
          )}
        </Button>
      </div>
    </form>
  )
}
