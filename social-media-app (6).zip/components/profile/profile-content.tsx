"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Grid3X3, Bookmark, Settings } from "lucide-react"
import PostCard from "@/components/post/post-card"

export default function ProfileContent() {
  const [activeTab, setActiveTab] = useState("posts")

  // Mock user data
  const user = {
    name: "Cyndy Lillibridge",
    username: "cyndylillibridge",
    location: "Torrance, CA, United States",
    avatar: "/placeholder.svg?height=150&width=150",
    stats: {
      posts: 368,
      followers: "184.3K",
      following: "1.04M",
    },
  }

  // Mock posts data
  const posts = [
    {
      id: "1",
      user: {
        id: "user1",
        name: user.name,
        username: user.username,
        avatar: user.avatar,
      },
      content:
        "While Corfu give us the ability to shoot by the sea with amazing blue background full of light of the sky, Florina give us its gentle side. The humble atmosphere and Light of Florina which comes...",
      images: [
        "/placeholder.svg?height=400&width=600",
        "/placeholder.svg?height=300&width=400",
        "/placeholder.svg?height=300&width=400",
        "/placeholder.svg?height=300&width=400",
      ],
      likes: 1600,
      comments: 2300,
      createdAt: new Date().toISOString(),
      tags: ["landscape", "flora", "nature"],
    },
    {
      id: "2",
      user: {
        id: "user1",
        name: user.name,
        username: user.username,
        avatar: user.avatar,
      },
      content: "Exploring the beautiful mountains this weekend! The views were absolutely breathtaking.",
      images: ["/placeholder.svg?height=400&width=600"],
      likes: 890,
      comments: 120,
      createdAt: new Date().toISOString(),
      tags: ["travel", "mountains", "weekend"],
    },
  ]

  return (
    <div className="space-y-6">
      <div className="rounded-lg bg-slate-900 p-6 border border-blue-900">
        <div className="flex flex-col items-center md:flex-row md:items-start md:space-x-6">
          <Avatar className="h-24 w-24 border-2 border-blue-500 md:h-32 md:w-32">
            <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
            <AvatarFallback>
              {user.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </AvatarFallback>
          </Avatar>

          <div className="mt-4 text-center md:mt-0 md:text-left">
            <div className="flex flex-col items-center md:flex-row md:items-center md:space-x-4">
              <h1 className="text-2xl font-bold text-white">{user.name}</h1>
              <div className="mt-2 flex space-x-2 md:mt-0">
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                  Follow
                </Button>
                <Button size="sm" variant="outline" className="border-blue-800">
                  Message
                </Button>
                <Button size="sm" variant="ghost">
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <p className="mt-1 text-gray-400">{user.location}</p>

            <div className="mt-4 flex justify-center space-x-6 md:justify-start">
              <div className="text-center">
                <p className="text-xl font-bold text-white">{user.stats.posts}</p>
                <p className="text-sm text-gray-400">Posts</p>
              </div>
              <div className="text-center">
                <p className="text-xl font-bold text-white">{user.stats.followers}</p>
                <p className="text-sm text-gray-400">Followers</p>
              </div>
              <div className="text-center">
                <p className="text-xl font-bold text-white">{user.stats.following}</p>
                <p className="text-sm text-gray-400">Following</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="posts" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-800 w-full justify-start">
          <TabsTrigger value="posts" className="flex items-center data-[state=active]:bg-blue-600">
            <Grid3X3 className="mr-2 h-4 w-4" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="saved" className="flex items-center data-[state=active]:bg-blue-600">
            <Bookmark className="mr-2 h-4 w-4" />
            Saved
          </TabsTrigger>
        </TabsList>

        <TabsContent value="posts" className="mt-6">
          <div className="space-y-6">
            {posts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="saved" className="mt-6">
          <div className="flex h-40 items-center justify-center rounded-lg bg-slate-900 border border-blue-900">
            <p className="text-gray-400">No saved posts yet</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
