const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { uploadToS3Direct, generateS3Key, getSignedUrl } = require('../config/s3');

// Configure multer memory storage for file uploads
const storage = multer.memoryStorage();

// File type validation
const fileFilter = (req, file, cb) => {
  // Allowed file types
  const fileTypes = /jpeg|jpg|png|gif|webp|mp4|webm/;
  
  // Check extension
  const extname = fileTypes.test(path.extname(file.originalname).toLowerCase());
  
  // Check mime type
  const mimetype = fileTypes.test(file.mimetype);
  
  if (mimetype && extname) {
    return cb(null, true);
  } else {
    return cb(new Error('Only images and videos are allowed'));
  }
};

// Initialize multer upload
const upload = multer({
  storage,
  fileFilter,
  limits: { 
    fileSize: 10 * 1024 * 1024, // 10MB max file size
    files: 5 // Maximum 5 files at once
  }
});

/**
 * Handle file uploads and return URLs
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
exports.uploadFiles = async (req, res) => {
  try {
    const uploadType = req.params.type || 'posts';
    
    // Use multer to process the upload (handles multiple files)
    upload.array('files', 5)(req, res, async (err) => {
      if (err) {
        if (err instanceof multer.MulterError) {
          if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({ message: 'File too large. Max size is 10MB.' });
          }
          if (err.code === 'LIMIT_FILE_COUNT') {
            return res.status(400).json({ message: 'Too many files. Max is 5 files.' });
          }
          
          return res.status(400).json({ message: `Upload error: ${err.message}` });
        }
        
        return res.status(400).json({ message: err.message });
      }
      
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ message: 'No files provided' });
      }
      
      try {
        const fileUrls = [];
        const fileKeys = []; // Store S3 keys for future reference
        
        // Process each file
        for (const file of req.files) {
          // Upload to S3
          const result = await uploadToS3Direct(
            file.buffer,
            file.originalname,
            req.user._id,
            uploadType,
            file.mimetype
          );
          
          fileUrls.push(result);
          fileKeys.push(generateS3Key(file.originalname, req.user._id, uploadType));
        }
        
        // Return the URLs and keys
        res.status(200).json({ 
          urls: fileUrls,
          keys: fileKeys,
          count: fileUrls.length
        });
      } catch (uploadError) {
        console.error('S3 upload error:', uploadError);
        res.status(500).json({ message: 'Error uploading files to S3' });
      }
    });
  } catch (error) {
    console.error('Upload controller error:', error);
    res.status(500).json({ message: 'Server error during file upload' });
  }
};

/**
 * Handle avatar file upload and return URL
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
exports.uploadAvatar = async (req, res) => {
  try {
    // Special configuration for avatar uploads
    const avatarUpload = multer({
      storage,
      fileFilter: (req, file, cb) => {
        // Only allow images for avatars
        const fileTypes = /jpeg|jpg|png|gif|webp/;
        const extname = fileTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = fileTypes.test(file.mimetype);
        
        if (mimetype && extname) {
          return cb(null, true);
        } else {
          return cb(new Error('Only images are allowed for avatars'));
        }
      },
      limits: { 
        fileSize: 5 * 1024 * 1024 // 5MB max for avatars
      }
    }).single('avatar');
    
    avatarUpload(req, res, async (err) => {
      if (err) {
        if (err instanceof multer.MulterError) {
          if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({ message: 'Avatar too large. Max size is 5MB.' });
          }
          return res.status(400).json({ message: `Avatar upload error: ${err.message}` });
        }
        return res.status(400).json({ message: err.message });
      }
      
      if (!req.file) {
        return res.status(400).json({ message: 'No avatar file provided' });
      }
      
      try {
        // Upload to S3
        const avatarUrl = await uploadToS3Direct(
          req.file.buffer,
          req.file.originalname,
          req.user._id,
          'avatars',
          req.file.mimetype
        );
        
        res.status(200).json({ 
          url: avatarUrl, 
          key: generateS3Key(req.file.originalname, req.user._id, 'avatars') 
        });
      } catch (uploadError) {
        console.error('Avatar S3 upload error:', uploadError);
        res.status(500).json({ message: 'Error uploading avatar to S3' });
      }
    });
  } catch (error) {
    console.error('Avatar upload controller error:', error);
    res.status(500).json({ message: 'Server error during avatar upload' });
  }
};

/**
 * Generate a temporary signed URL for S3 object access
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
exports.getSignedUrl = async (req, res) => {
  try {
    const { key } = req.params;
    const expiresIn = parseInt(req.query.expiresIn) || 3600; // Default 1 hour
    
    if (!key) {
      return res.status(400).json({ message: 'No key provided' });
    }
    
    const signedUrl = await getSignedUrl(key, expiresIn);
    
    res.status(200).json({ signedUrl });
  } catch (error) {
    console.error('Signed URL error:', error);
    res.status(500).json({ message: 'Error generating signed URL' });
  }
};