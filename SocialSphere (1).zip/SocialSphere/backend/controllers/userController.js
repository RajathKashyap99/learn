const User = require('../models/User');
const Post = require('../models/Post');

// @desc    Get user profile
// @route   GET /api/users/:id
// @access  Private
const getUserProfile = async (req, res) => {
  try {
    const userId = req.params.id;
    
    const user = await User.findById(userId).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Check if current user is following this user
    const isFollowing = user.followers.includes(req.user._id);
    
    // Get follower and following counts
    const followersCount = user.followers.length;
    const followingCount = user.following.length;
    
    // Create a user object with additional properties
    const userProfile = user.toObject();
    userProfile.isFollowing = isFollowing;
    userProfile.followersCount = followersCount;
    userProfile.followingCount = followingCount;
    
    res.json(userProfile);
  } catch (error) {
    console.error('Error in getUserProfile:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get user by username
// @route   GET /api/users/username/:username
// @access  Private
const getUserByUsername = async (req, res) => {
  try {
    const { username } = req.params;
    
    const user = await User.findOne({ username: username.toLowerCase() }).select('-password');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Check if current user is following this user
    const isFollowing = user.followers.includes(req.user._id);
    
    // Get follower and following counts
    const followersCount = user.followers.length;
    const followingCount = user.following.length;
    
    // Create a user object with additional properties
    const userProfile = user.toObject();
    userProfile.isFollowing = isFollowing;
    userProfile.followersCount = followersCount;
    userProfile.followingCount = followingCount;
    
    res.json(userProfile);
  } catch (error) {
    console.error('Error in getUserByUsername:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Follow or unfollow a user
// @route   POST /api/users/:id/follow
// @access  Private
const toggleFollow = async (req, res) => {
  try {
    const userToFollowId = req.params.id;
    const currentUserId = req.user._id;
    
    // Cannot follow yourself
    if (userToFollowId === currentUserId.toString()) {
      return res.status(400).json({ message: 'Cannot follow yourself' });
    }
    
    // Find the user to follow
    const userToFollow = await User.findById(userToFollowId);
    
    if (!userToFollow) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Find the current user
    const currentUser = await User.findById(currentUserId);
    
    // Check if already following
    const isFollowing = userToFollow.followers.includes(currentUserId);
    
    if (isFollowing) {
      // Unfollow - remove currentUser from followers, remove userToFollow from following
      userToFollow.followers = userToFollow.followers.filter(
        id => id.toString() !== currentUserId.toString()
      );
      currentUser.following = currentUser.following.filter(
        id => id.toString() !== userToFollowId.toString()
      );
    } else {
      // Follow - add currentUser to followers, add userToFollow to following
      userToFollow.followers.push(currentUserId);
      currentUser.following.push(userToFollowId);
    }
    
    await userToFollow.save();
    await currentUser.save();
    
    res.json({
      success: true,
      isFollowing: !isFollowing,
      followersCount: userToFollow.followers.length
    });
  } catch (error) {
    console.error('Error in toggleFollow:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
const updateProfile = async (req, res) => {
  try {
    const { fullName, bio, location, website, avatarUrl } = req.body;
    
    // Find user
    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Update fields if provided
    if (fullName) user.fullName = fullName;
    if (bio !== undefined) user.bio = bio;
    if (location !== undefined) user.location = location;
    if (website !== undefined) user.website = website;
    if (avatarUrl) user.avatarUrl = avatarUrl;
    
    // Save changes
    await user.save();
    
    res.json(user);
  } catch (error) {
    console.error('Error in updateProfile:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Update account settings
// @route   PUT /api/users/account
// @access  Private
const updateAccount = async (req, res) => {
  try {
    const { email, currentPassword, newPassword } = req.body;
    const bcrypt = require('bcryptjs');
    
    // Find user
    const user = await User.findById(req.user._id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Check current password
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    
    if (!isMatch) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }
    
    // Check if updating to new email that already exists
    if (email && email !== user.email) {
      const existingEmail = await User.findOne({ email: email.toLowerCase() });
      
      if (existingEmail) {
        return res.status(400).json({ message: 'Email already in use' });
      }
      
      user.email = email.toLowerCase();
    }
    
    // Update password if provided
    if (newPassword) {
      const salt = await bcrypt.genSalt(10);
      user.password = await bcrypt.hash(newPassword, salt);
    }
    
    // Save changes
    await user.save();
    
    // Return user without password
    const updatedUser = await User.findById(user._id).select('-password');
    
    res.json(updatedUser);
  } catch (error) {
    console.error('Error in updateAccount:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get suggested users
// @route   GET /api/users/suggested
// @access  Private
const getSuggestedUsers = async (req, res) => {
  try {
    const currentUserId = req.user._id;
    
    // Get users that current user is not following
    const following = req.user.following;
    following.push(currentUserId); // Add current user to exclusion list
    
    const suggestedUsers = await User.find({ _id: { $nin: following } })
      .select('username fullName avatarUrl verified')
      .limit(5);
    
    // Add isFollowing property (should be false for all)
    const processedUsers = suggestedUsers.map(user => {
      const userObj = user.toObject();
      userObj.isFollowing = false;
      return userObj;
    });
    
    res.json(processedUsers);
  } catch (error) {
    console.error('Error in getSuggestedUsers:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get popular users
// @route   GET /api/users/popular
// @access  Private
const getPopularUsers = async (req, res) => {
  try {
    const currentUserId = req.user._id;
    
    // Get users with most followers
    const popularUsers = await User.aggregate([
      {
        $match: {
          _id: { $ne: mongoose.Types.ObjectId(currentUserId) }
        }
      },
      {
        $addFields: {
          followersCount: { $size: '$followers' }
        }
      },
      {
        $sort: { followersCount: -1 }
      },
      {
        $limit: 10
      },
      {
        $project: {
          _id: 1,
          username: 1,
          fullName: 1,
          avatarUrl: 1,
          verified: 1,
          followersCount: 1,
          followers: 1
        }
      }
    ]);
    
    // Check if current user is following each popular user
    const processedUsers = popularUsers.map(user => {
      user.isFollowing = user.followers.some(
        id => id.toString() === currentUserId.toString()
      );
      return user;
    });
    
    res.json(processedUsers);
  } catch (error) {
    console.error('Error in getPopularUsers:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Search users
// @route   GET /api/users/search
// @access  Private
const searchUsers = async (req, res) => {
  try {
    const { q } = req.query;
    
    if (!q || q.trim() === '') {
      return res.json([]);
    }
    
    const users = await User.find({
      $or: [
        { username: { $regex: q, $options: 'i' } },
        { fullName: { $regex: q, $options: 'i' } }
      ]
    })
    .select('username fullName avatarUrl verified followers')
    .limit(10);
    
    // Add isFollowing property
    const processedUsers = users.map(user => {
      const userObj = user.toObject();
      userObj.isFollowing = user.followers.includes(req.user._id);
      userObj.followersCount = user.followers.length;
      return userObj;
    });
    
    res.json(processedUsers);
  } catch (error) {
    console.error('Error in searchUsers:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
  getUserProfile,
  getUserByUsername,
  toggleFollow,
  updateProfile,
  updateAccount,
  getSuggestedUsers,
  getPopularUsers,
  searchUsers
};