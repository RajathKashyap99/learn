const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  content: {
    type: String,
    required: [true, 'Post content cannot be empty'],
    maxlength: [500, 'Post content cannot exceed 500 characters']
  },
  mediaUrls: {
    type: [String],
    default: []
  },
  tags: {
    type: [String],
    default: []
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Create indexes for optimized queries
postSchema.index({ user: 1, createdAt: -1 });
postSchema.index({ createdAt: -1 });
postSchema.index({ tags: 1 });

// Add virtual fields for likes, comments etc.
postSchema.virtual('likes', {
  ref: 'Like',
  localField: '_id',
  foreignField: 'post',
  count: true
});

postSchema.virtual('comments', {
  ref: 'Comment',
  localField: '_id',
  foreignField: 'post',
  count: true
});

// Methods for getting engagement metrics
postSchema.methods.getLikeCount = async function() {
  return await mongoose.model('Like').countDocuments({ post: this._id });
};

postSchema.methods.getCommentCount = async function() {
  return await mongoose.model('Comment').countDocuments({ post: this._id });
};

postSchema.methods.isLikedByUser = async function(userId) {
  const like = await mongoose.model('Like').findOne({ 
    post: this._id, 
    user: userId 
  });
  return !!like;
};

postSchema.methods.isBookmarkedByUser = async function(userId) {
  const bookmark = await mongoose.model('Bookmark').findOne({ 
    post: this._id, 
    user: userId 
  });
  return !!bookmark;
};

// Static method to get trending posts
postSchema.statics.getTrending = async function(limit = 10) {
  const threeDaysAgo = new Date();
  threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
  
  // Aggregate to find trending posts based on recent engagement
  return this.aggregate([
    {
      // Only posts from the last 3 days
      $match: { createdAt: { $gte: threeDaysAgo } }
    },
    {
      // Lookup likes for each post
      $lookup: {
        from: 'likes',
        localField: '_id',
        foreignField: 'post',
        as: 'likes'
      }
    },
    {
      // Lookup comments for each post
      $lookup: {
        from: 'comments',
        localField: '_id',
        foreignField: 'post',
        as: 'comments'
      }
    },
    {
      // Add fields for likes and comments count
      $addFields: {
        likeCount: { $size: '$likes' },
        commentCount: { $size: '$comments' },
        // Engagement score formula (can be adjusted)
        engagementScore: { 
          $add: [
            { $multiply: [{ $size: '$likes' }, 1] },      // Likes weight
            { $multiply: [{ $size: '$comments' }, 1.5] }  // Comments weight (higher)
          ]
        }
      }
    },
    {
      // Sort by engagement score
      $sort: { engagementScore: -1, createdAt: -1 }
    },
    {
      // Limit to requested number
      $limit: limit
    },
    {
      // Remove the arrays we used for counting
      $project: {
        likes: 0,
        comments: 0
      }
    }
  ]);
};

const Post = mongoose.model('Post', postSchema);

module.exports = Post;