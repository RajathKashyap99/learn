/**
 * Middleware to protect routes
 * Throws appropriate HTTP errors if user is not authenticated
 */
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Wrapper function to make async error handling cleaner
const asyncHandler = (fn) => (req, res, next) => 
  Promise.resolve(fn(req, res, next)).catch(next);

// Verify and extract user from JWT token
const requireAuth = asyncHandler(async (req, res, next) => {
  // Get token from header
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ 
      error: 'Authentication required', 
      message: 'Please login to access this resource' 
    });
  }
  
  try {
    // Extract and verify token
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Check if user exists
    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(401).json({ 
        error: 'Invalid credentials', 
        message: 'The user belonging to this token no longer exists' 
      });
    }
    
    // Add user to request
    req.user = user;
    next();
  } catch (error) {
    console.error('Token verification error:', error);
    return res.status(401).json({ 
      error: 'Invalid token', 
      message: 'Your login session has expired. Please login again.' 
    });
  }
});

// Check if user has admin rights
const requireAdmin = (req, res, next) => {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({
      error: 'Access denied',
      message: 'You do not have permission to perform this action'
    });
  }
  next();
};

module.exports = {
  asyncHandler,
  requireAuth,
  requireAdmin
};