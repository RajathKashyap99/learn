const express = require('express');
const router = express.Router();
const {
  createPost,
  getFeedPosts,
  getTrendingPosts,
  getUserPosts,
  toggleLike,
  toggleBookmark,
  getPost,
  deletePost,
  addComment,
  getBookmarkedPosts
} = require('../controllers/postController');
const auth = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// @route   POST /api/posts
// @desc    Create a post
// @access  Private
router.post('/', createPost);

// @route   GET /api/posts/feed
// @desc    Get feed posts
// @access  Private
router.get('/feed', getFeedPosts);

// @route   GET /api/posts/trending
// @desc    Get trending posts
// @access  Private
router.get('/trending', getTrendingPosts);

// @route   GET /api/posts/user/:userId
// @desc    Get posts by user ID
// @access  Private
router.get('/user/:userId', getUserPosts);

// @route   GET /api/posts/bookmarks
// @desc    Get bookmarked posts
// @access  Private
router.get('/bookmarks', getBookmarkedPosts);

// @route   GET /api/posts/:id
// @desc    Get a single post
// @access  Private
router.get('/:id', getPost);

// @route   DELETE /api/posts/:id
// @desc    Delete a post
// @access  Private
router.delete('/:id', deletePost);

// @route   POST /api/posts/:id/like
// @desc    Like or unlike a post
// @access  Private
router.post('/:id/like', toggleLike);

// @route   POST /api/posts/:id/bookmark
// @desc    Bookmark or unbookmark a post
// @access  Private
router.post('/:id/bookmark', toggleBookmark);

// @route   POST /api/posts/:id/comment
// @desc    Add comment to post
// @access  Private
router.post('/:id/comment', addComment);

module.exports = router;