const express = require('express');
const router = express.Router();
const {
  getUserProfile,
  getUserByUsername,
  toggleFollow,
  updateProfile,
  updateAccount,
  getSuggestedUsers,
  getPopularUsers,
  searchUsers
} = require('../controllers/userController');
const auth = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// @route   GET /api/users/suggested
// @desc    Get suggested users
// @access  Private
router.get('/suggested', getSuggestedUsers);

// @route   GET /api/users/popular
// @desc    Get popular users
// @access  Private
router.get('/popular', getPopularUsers);

// @route   GET /api/users/search
// @desc    Search users
// @access  Private
router.get('/search', searchUsers);

// @route   PUT /api/users/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', updateProfile);

// @route   PUT /api/users/account
// @desc    Update account settings
// @access  Private
router.put('/account', updateAccount);

// @route   GET /api/users/username/:username
// @desc    Get user by username
// @access  Private
router.get('/username/:username', getUserByUsername);

// @route   GET /api/users/:id
// @desc    Get user profile
// @access  Private
router.get('/:id', getUserProfile);

// @route   POST /api/users/:id/follow
// @desc    Follow or unfollow a user
// @access  Private
router.post('/:id/follow', toggleFollow);

module.exports = router;