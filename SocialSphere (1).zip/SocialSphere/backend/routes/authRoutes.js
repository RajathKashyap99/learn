const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const authController = require('../controllers/authController');

// @route   POST /api/auth/register
// @desc    Register a new user
// @access  Public
router.post('/register', authController.registerUser);

// @route   POST /api/auth/login
// @desc    Authenticate user & get token
// @access  Public
router.post('/login', authController.loginUser);

// @route   POST /api/auth/logout
// @desc    Logout user / clear cookie
// @access  Public
router.post('/logout', authController.logoutUser);

// @route   GET /api/auth/user
// @desc    Get current user profile
// @access  Private
router.get('/user', auth, authController.getCurrentUser);

// @route   PUT /api/auth/password
// @desc    Update user password
// @access  Private
router.put('/password', auth, authController.updatePassword);

module.exports = router;