const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const uploadController = require('../controllers/uploadController');

// @route   POST /api/upload/files/:type
// @desc    Upload multiple files (posts, etc)
// @access  Private
router.post('/files/:type?', auth, uploadController.uploadFiles);

// @route   POST /api/upload/avatar
// @desc    Upload user avatar
// @access  Private
router.post('/avatar', auth, uploadController.uploadAvatar);

// @route   GET /api/upload/signed-url/:key
// @desc    Generate a signed URL for an S3 object
// @access  Private
router.get('/signed-url/:key', auth, uploadController.getSignedUrl);

module.exports = router;