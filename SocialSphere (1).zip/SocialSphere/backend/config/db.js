/**
 * MongoDB connection configuration
 * Sets up the MongoDB connection using Mongoose
 */
const mongoose = require('mongoose');

// Set options for Mongoose connection
const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  autoIndex: true, // Build indexes to improve query performance
  maxPoolSize: 10, // Maximum number of sockets to keep open
  serverSelectionTimeoutMS: 5000, // Timeout after 5s instead of 30s
  socketTimeoutMS: 45000, // Close sockets after 45s of inactivity
  family: 4 // Use IPv4, skip IPv6
};

/**
 * Connect to MongoDB database
 * @returns {Promise<typeof mongoose>} MongoDB connection
 */
const connectDB = async () => {
  try {
    // Get MongoDB URI from environment or use local fallback for development
    const mongoURI = process.env.MONGO_URI || 'mongodb://localhost:27017/connecto';
    
    // Connect to MongoDB
    const conn = await mongoose.connect(mongoURI, options);
    
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    
    // Log any connection errors
    mongoose.connection.on('error', err => {
      console.error(`MongoDB connection error: ${err.message}`);
    });
    
    // Log when connection is disconnected
    mongoose.connection.on('disconnected', () => {
      console.log('MongoDB disconnected');
    });
    
    // Gracefully close MongoDB connection when Node process ends
    process.on('SIGINT', async () => {
      await mongoose.connection.close();
      console.log('MongoDB connection closed due to app termination');
      process.exit(0);
    });
    
    return conn;
  } catch (error) {
    console.error(`MongoDB connection error: ${error.message}`);
    
    // Exit with failure
    process.exit(1);
  }
};

module.exports = connectDB;