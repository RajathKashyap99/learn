import { User } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link } from "wouter";
import FollowButton from "./follow-button";
import { CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface UserCardProps {
  user: User;
  showFollowButton?: boolean;
}

export default function UserCard({ user, showFollowButton = false }: UserCardProps) {
  return (
    <div className="flex items-center justify-between">
      <Link href={`/profile/${user.username}`} className="flex items-center">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatarUrl || ""} alt={user.username} />
          <AvatarFallback>{user.username.charAt(0).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="ml-3">
          <div className="flex items-center">
            <h4 className="text-sm font-medium text-foreground">{user.fullName || user.username}</h4>
            {user.verified && (
              <Badge variant="outline" className="ml-1 p-0 h-4 w-4 rounded-full flex items-center justify-center">
                <CheckCircle className="h-3 w-3 text-primary" />
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">@{user.username}</p>
        </div>
      </Link>
      
      {showFollowButton && (
        <FollowButton userId={user.id} isFollowing={user.isFollowing} />
      )}
    </div>
  );
}
