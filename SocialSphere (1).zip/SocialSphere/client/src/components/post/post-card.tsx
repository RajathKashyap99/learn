import { Post, User } from "@shared/schema";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";
import PostImageGrid from "./post-image-grid";
import PostActions from "./post-actions";
import { Badge } from "@/components/ui/badge";
import { MoreHorizontal, CheckCircle } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface PostCardProps {
  post: Post;
  author: User;
}

export default function PostCard({ post, author }: PostCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDeleting, setIsDeleting] = useState(false);
  
  const deletePostMutation = useMutation({
    mutationFn: async () => {
      setIsDeleting(true);
      await apiRequest("DELETE", `/api/posts/${post.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", author.id, "posts"] });
      toast({
        title: "Post deleted",
        description: "Your post has been successfully deleted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete post: ${error.message}`,
        variant: "destructive",
      });
      setIsDeleting(false);
    },
  });

  const isAuthor = user?.id === author.id;
  const timeAgo = formatDistanceToNow(new Date(post.createdAt), { addSuffix: true });

  return (
    <article className="bg-card rounded-lg shadow-sm overflow-hidden">
      {/* Post Header */}
      <div className="p-4 flex items-center">
        <Link href={`/profile/${author.username}`}>
          <Avatar className="h-10 w-10">
            <AvatarImage src={author.avatarUrl || ""} alt={author.username} />
            <AvatarFallback>{author.username.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>
        </Link>
        <div className="ml-3">
          <div className="flex items-center">
            <Link href={`/profile/${author.username}`}>
              <h3 className="text-sm font-medium text-foreground">{author.fullName || author.username}</h3>
            </Link>
            {author.verified && (
              <Badge variant="outline" className="ml-1 p-0 h-4 w-4 rounded-full flex items-center justify-center">
                <CheckCircle className="h-3 w-3 text-primary" />
              </Badge>
            )}
            <span className="text-muted-foreground text-xs ml-2">@{author.username}</span>
          </div>
          <p className="text-xs text-muted-foreground">{timeAgo}</p>
        </div>
        
        {isAuthor && (
          <div className="ml-auto">
            <DropdownMenu>
              <DropdownMenuTrigger asChild disabled={isDeleting}>
                <button className="text-muted-foreground hover:text-foreground p-1">
                  <MoreHorizontal className="h-5 w-5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive" 
                  onClick={() => deletePostMutation.mutate()}
                  disabled={isDeleting}
                >
                  Delete Post
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </div>
      
      {/* Post Content */}
      <div className="px-4 pb-3">
        <p className="text-foreground mb-3">{post.content}</p>
        
        {post.mediaUrls && post.mediaUrls.length > 0 && (
          <div className="mb-3">
            <PostImageGrid images={post.mediaUrls} />
          </div>
        )}
        
        {/* Post Actions */}
        <PostActions post={post} />
      </div>
    </article>
  );
}
