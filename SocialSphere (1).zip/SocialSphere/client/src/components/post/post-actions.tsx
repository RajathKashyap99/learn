import { Post } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share, Bookmark } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import { cn } from "@/lib/utils";

interface PostActionsProps {
  post: Post;
}

export default function PostActions({ post }: PostActionsProps) {
  const [optimisticLikes, setOptimisticLikes] = useState(post.likes);
  const [optimisticLiked, setOptimisticLiked] = useState(post.liked);
  const [optimisticBookmarked, setOptimisticBookmarked] = useState(post.bookmarked);
  
  const likePostMutation = useMutation({
    mutationFn: async () => {
      // Optimistically update
      const newLiked = !optimisticLiked;
      setOptimisticLiked(newLiked);
      setOptimisticLikes(prev => newLiked ? prev + 1 : prev - 1);
      
      await apiRequest("POST", `/api/posts/${post.id}/like`, { liked: newLiked });
    },
    onError: () => {
      // Revert on error
      setOptimisticLiked(!optimisticLiked);
      setOptimisticLikes(prev => optimisticLiked ? prev - 1 : prev + 1);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts", post.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
    },
  });

  const bookmarkPostMutation = useMutation({
    mutationFn: async () => {
      // Optimistically update
      setOptimisticBookmarked(!optimisticBookmarked);
      
      await apiRequest("POST", `/api/posts/${post.id}/bookmark`, { bookmarked: !optimisticBookmarked });
    },
    onError: () => {
      // Revert on error
      setOptimisticBookmarked(!optimisticBookmarked);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts", post.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
    },
  });

  return (
    <div className="flex justify-between items-center pt-3 border-t border-border">
      <Button
        variant="ghost"
        size="sm"
        className={cn(
          "flex items-center p-1 h-auto",
          optimisticLiked ? "text-primary" : "text-muted-foreground hover:text-primary"
        )}
        onClick={() => likePostMutation.mutate()}
        disabled={likePostMutation.isPending}
      >
        <Heart className={cn(
          "mr-1 h-5 w-5",
          optimisticLiked ? "fill-current" : ""
        )} />
        <span className="text-xs">{optimisticLikes}</span>
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        className="flex items-center text-muted-foreground hover:text-primary p-1 h-auto"
      >
        <MessageCircle className="mr-1 h-5 w-5" />
        <span className="text-xs">{post.comments}</span>
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        className="flex items-center text-muted-foreground hover:text-primary p-1 h-auto"
      >
        <Share className="mr-1 h-5 w-5" />
        <span className="text-xs">{post.shares}</span>
      </Button>
      
      <Button
        variant="ghost"
        size="sm"
        className={cn(
          "flex items-center p-1 h-auto",
          optimisticBookmarked ? "text-primary" : "text-muted-foreground hover:text-primary"
        )}
        onClick={() => bookmarkPostMutation.mutate()}
        disabled={bookmarkPostMutation.isPending}
      >
        <Bookmark className={cn(
          "h-5 w-5",
          optimisticBookmarked ? "fill-current" : ""
        )} />
      </Button>
    </div>
  );
}
