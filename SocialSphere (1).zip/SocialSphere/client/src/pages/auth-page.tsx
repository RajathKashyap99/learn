import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import AuthForm from "@/components/auth/auth-form";
import { LoadingSpinner } from "@/components/ui/loading-spinner";

export default function AuthPage() {
  const { user, isLoading } = useAuth();
  
  // Redirect to home if already logged in
  if (user && !isLoading) {
    return <Redirect to="/" />;
  }
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background">
      {/* Auth form side */}
      <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:flex-none lg:w-1/2">
        <div className="w-full max-w-md">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-primary mb-2">connecto</h1>
            <p className="text-muted-foreground">Connect with friends and the world around you.</p>
          </div>
          
          <AuthForm />
        </div>
      </div>
      
      {/* Hero image side (only on larger screens) */}
      <div className="hidden lg:flex flex-1 relative">
        <div className="absolute inset-0 bg-gradient-to-bl from-primary/20 to-background z-0"></div>
        
        <div className="relative z-10 flex flex-col justify-center items-center px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Join the community</h2>
          <div className="space-y-6 max-w-lg">
            <div className="flex items-center space-x-4">
              <div className="bg-primary/20 p-4 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                </svg>
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-lg">Connect with friends</h3>
                <p className="text-muted-foreground">Share moments and stay in touch with your network</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="bg-primary/20 p-4 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-lg">Share photos and videos</h3>
                <p className="text-muted-foreground">Upload multiple images to capture your best moments</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="bg-primary/20 p-4 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                </svg>
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-lg">Discover trends</h3>
                <p className="text-muted-foreground">Stay up to date with the latest trends and topics</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
