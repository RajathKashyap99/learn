import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User, Post } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search } from "lucide-react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import UserCard from "@/components/user/user-card";
import PostCard from "@/components/post/post-card";
import { useLocation } from "wouter";

interface PostWithAuthor {
  post: Post;
  author: User;
}

export default function SearchPage() {
  const [location] = useLocation();
  const initialQuery = new URLSearchParams(location.split("?")[1]).get("q") || "";
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState("people");
  
  // User search results
  const {
    data: userResults,
    isLoading: isLoadingUsers,
  } = useQuery<User[]>({
    queryKey: ["/api/search/users", searchQuery],
    enabled: searchQuery.length > 0,
  });
  
  // Post search results
  const {
    data: postResults,
    isLoading: isLoadingPosts,
  } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/search/posts", searchQuery],
    enabled: searchQuery.length > 0,
  });
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Update URL with search query
    window.history.pushState(
      {},
      "",
      searchQuery ? `/search?q=${encodeURIComponent(searchQuery)}` : "/search"
    );
  };

  return (
    <div className="container mx-auto p-4 max-w-3xl">
      <h1 className="text-2xl font-bold mb-6">Search</h1>
      
      <form onSubmit={handleSearch} className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
          <Input
            type="text"
            placeholder="Search for people, posts, or topics..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </form>
      
      {searchQuery ? (
        <Tabs defaultValue="people" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="people">People</TabsTrigger>
            <TabsTrigger value="posts">Posts</TabsTrigger>
          </TabsList>
          
          <TabsContent value="people" className="space-y-4">
            {isLoadingUsers ? (
              <div className="flex justify-center py-10">
                <LoadingSpinner size="lg" />
              </div>
            ) : userResults && userResults.length > 0 ? (
              <div className="bg-card rounded-lg p-4">
                <div className="grid gap-4">
                  {userResults.map((user) => (
                    <UserCard key={user.id} user={user} showFollowButton />
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center p-10 bg-card rounded-lg">
                <h3 className="text-lg font-medium mb-2">No users found</h3>
                <p className="text-muted-foreground">
                  Try a different search term
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="posts" className="space-y-4">
            {isLoadingPosts ? (
              <div className="flex justify-center py-10">
                <LoadingSpinner size="lg" />
              </div>
            ) : postResults && postResults.length > 0 ? (
              <>
                {postResults.map((item) => (
                  <PostCard key={item.post.id} post={item.post} author={item.author} />
                ))}
              </>
            ) : (
              <div className="text-center p-10 bg-card rounded-lg">
                <h3 className="text-lg font-medium mb-2">No posts found</h3>
                <p className="text-muted-foreground">
                  Try a different search term
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      ) : (
        <div className="text-center p-10 bg-card rounded-lg">
          <h3 className="text-lg font-medium mb-2">Search for something</h3>
          <p className="text-muted-foreground">
            Enter a search term to find people or posts
          </p>
        </div>
      )}
    </div>
  );
}
