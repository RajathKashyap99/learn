import { useQuery } from "@tanstack/react-query";
import { User, Post } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import UserCard from "@/components/user/user-card";
import PostCard from "@/components/post/post-card";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Button } from "@/components/ui/button";
import { useState } from "react";

interface PostWithAuthor {
  post: Post;
  author: User;
}

export default function ExplorePage() {
  const [activeTab, setActiveTab] = useState("trending");
  
  // Trending posts
  const {
    data: trendingPosts,
    isLoading: isLoadingTrending,
    fetchNextPage: fetchNextTrendingPage,
    hasNextPage: hasTrendingNextPage,
    isFetchingNextPage: isFetchingTrendingNextPage,
  } = useQuery<{
    posts: PostWithAuthor[];
    cursor: string;
    hasMore: boolean;
  }>({
    queryKey: ["/api/posts/trending"],
  });
  
  // Popular users
  const {
    data: popularUsers,
    isLoading: isLoadingUsers,
  } = useQuery<User[]>({
    queryKey: ["/api/users/popular"],
  });
  
  const handleLoadMore = () => {
    if (activeTab === "trending" && hasTrendingNextPage && !isFetchingTrendingNextPage) {
      fetchNextTrendingPage();
    }
  };

  return (
    <div className="container mx-auto p-4 max-w-3xl">
      <h1 className="text-2xl font-bold mb-6">Explore</h1>
      
      <Tabs defaultValue="trending" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="people">People to Follow</TabsTrigger>
        </TabsList>
        
        <TabsContent value="trending" className="space-y-4">
          {isLoadingTrending ? (
            <div className="flex justify-center py-10">
              <LoadingSpinner size="lg" />
            </div>
          ) : trendingPosts?.posts && trendingPosts.posts.length > 0 ? (
            <>
              {trendingPosts.posts.map((item) => (
                <PostCard key={item.post.id} post={item.post} author={item.author} />
              ))}
              
              {trendingPosts.hasMore && (
                <div className="flex justify-center my-4">
                  <Button
                    variant="outline"
                    onClick={handleLoadMore}
                    disabled={isFetchingTrendingNextPage}
                  >
                    {isFetchingTrendingNextPage ? (
                      <>
                        <LoadingSpinner size="sm" className="mr-2" />
                        Loading...
                      </>
                    ) : (
                      "Load More"
                    )}
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className="text-center p-10 bg-card rounded-lg">
              <h3 className="text-lg font-medium mb-2">No trending posts</h3>
              <p className="text-muted-foreground">
                Check back later for trending content!
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="people" className="space-y-4">
          {isLoadingUsers ? (
            <div className="flex justify-center py-10">
              <LoadingSpinner size="lg" />
            </div>
          ) : popularUsers && popularUsers.length > 0 ? (
            <div className="bg-card rounded-lg p-4">
              <div className="grid gap-4">
                {popularUsers.map((user) => (
                  <UserCard key={user.id} user={user} showFollowButton />
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center p-10 bg-card rounded-lg">
              <h3 className="text-lg font-medium mb-2">No suggestions available</h3>
              <p className="text-muted-foreground">
                We couldn't find any users to suggest right now.
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
