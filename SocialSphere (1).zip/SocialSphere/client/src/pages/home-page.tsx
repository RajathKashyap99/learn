import { useQuery } from "@tanstack/react-query";
import { Post, User } from "@shared/schema";
import PostCard from "@/components/post/post-card";
import CreatePostForm from "@/components/post/create-post-form";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface PostWithAuthor {
  post: Post;
  author: User;
}

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("forYou");
  
  const {
    data: feedPosts,
    isLoading: isLoadingFeed,
    error: feedError,
  } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts/feed"],
  });
  
  const {
    data: followingPosts,
    isLoading: isLoadingFollowing,
    error: followingError,
  } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts/following"],
  });
  
  const isLoading = activeTab === "forYou" ? isLoadingFeed : isLoadingFollowing;
  const error = activeTab === "forYou" ? feedError : followingError;
  const posts = activeTab === "forYou" ? feedPosts : followingPosts;

  return (
    <div className="space-y-4 mx-4 mt-4">
      <CreatePostForm />
      
      <Tabs 
        defaultValue="forYou" 
        value={activeTab} 
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="forYou">For You</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>
        
        <TabsContent value="forYou" className="space-y-4">
          {renderContent(isLoadingFeed, feedError, feedPosts)}
        </TabsContent>
        
        <TabsContent value="following" className="space-y-4">
          {renderContent(isLoadingFollowing, followingError, followingPosts)}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function renderContent(isLoading: boolean, error: Error | null, posts: PostWithAuthor[] | undefined) {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-10">
        <LoadingSpinner size="lg" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="text-center p-10 bg-card rounded-lg">
        <p className="text-destructive mb-2">Error loading posts</p>
        <p className="text-muted-foreground">{error.message}</p>
      </div>
    );
  }
  
  if (!posts || posts.length === 0) {
    return (
      <div className="text-center p-10 bg-card rounded-lg">
        <h3 className="text-xl font-medium mb-2">No posts yet</h3>
        <p className="text-muted-foreground">
          Start following people to see their posts here, or create your first post!
        </p>
      </div>
    );
  }
  
  return posts.map((item) => (
    <PostCard key={item.post.id} post={item.post} author={item.author} />
  ));
}
