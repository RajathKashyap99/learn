import { InsertUser, User, InsertPost, Post, insertFollowSchema } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

interface ProfileUpdateData {
  fullName?: string;
  bio?: string;
  location?: string;
  website?: string;
  avatarUrl?: string;
}

interface TrendingTopic {
  category: string;
  topic: string;
  count: number;
}

interface PostWithAuthor {
  post: Post;
  author: User;
}

export interface IStorage {
  // Session store
  sessionStore: session.Store;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProfile(userId: number, data: ProfileUpdateData): Promise<User>;
  updateUserAccount(userId: number, email: string, hashedPassword?: string): Promise<User>;
  
  // Follow operations
  followUser(followerId: number, followingId: number): Promise<void>;
  unfollowUser(followerId: number, followingId: number): Promise<void>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
  getFollowersCount(userId: number): Promise<number>;
  getFollowingCount(userId: number): Promise<number>;
  getSuggestedUsers(userId: number): Promise<User[]>;
  getPopularUsers(userId: number): Promise<User[]>;
  
  // Post operations
  getPost(id: number): Promise<Post | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  deletePost(id: number): Promise<void>;
  getFeedPosts(userId: number): Promise<PostWithAuthor[]>;
  getFollowingPosts(userId: number): Promise<PostWithAuthor[]>;
  getUserPosts(userId: number, currentUserId: number): Promise<PostWithAuthor[]>;
  getUserLikedPosts(userId: number, currentUserId: number): Promise<PostWithAuthor[]>;
  getTrendingPosts(limit?: number, cursor?: string): Promise<{posts: PostWithAuthor[], cursor: string, hasMore: boolean}>;
  
  // Interactions
  likePost(userId: number, postId: number): Promise<void>;
  unlikePost(userId: number, postId: number): Promise<void>;
  bookmarkPost(userId: number, postId: number): Promise<void>;
  unbookmarkPost(userId: number, postId: number): Promise<void>;
  getUserBookmarks(userId: number): Promise<PostWithAuthor[]>;
  
  // Search
  searchUsers(query: string, currentUserId: number): Promise<User[]>;
  searchPosts(query: string, currentUserId: number): Promise<PostWithAuthor[]>;
  
  // Trending
  getTrendingTopics(): Promise<TrendingTopic[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private follows: Map<number, {followerId: number, followingId: number}>;
  private likes: Map<number, {userId: number, postId: number}>;
  private bookmarks: Map<number, {userId: number, postId: number}>;
  
  sessionStore: session.Store;
  private userIdCounter: number;
  private postIdCounter: number;
  private followIdCounter: number;
  private likeIdCounter: number;
  private bookmarkIdCounter: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.follows = new Map();
    this.likes = new Map();
    this.bookmarks = new Map();
    
    this.userIdCounter = 1;
    this.postIdCounter = 1;
    this.followIdCounter = 1;
    this.likeIdCounter = 1;
    this.bookmarkIdCounter = 1;
    
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24h
    });
    
    // Initialize with sample data
    this.initializeSampleData();
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now,
      updatedAt: now,
      verified: false
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserProfile(userId: number, data: ProfileUpdateData): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = {
      ...user,
      ...data,
      updatedAt: new Date()
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserAccount(userId: number, email: string, hashedPassword?: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = {
      ...user,
      email,
      ...(hashedPassword ? { password: hashedPassword } : {}),
      updatedAt: new Date()
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  // Follow operations
  async followUser(followerId: number, followingId: number): Promise<void> {
    // Check if already following
    const isAlreadyFollowing = await this.isFollowing(followerId, followingId);
    if (isAlreadyFollowing) return;
    
    const id = this.followIdCounter++;
    this.follows.set(id, { followerId, followingId });
  }
  
  async unfollowUser(followerId: number, followingId: number): Promise<void> {
    for (const [id, follow] of this.follows.entries()) {
      if (follow.followerId === followerId && follow.followingId === followingId) {
        this.follows.delete(id);
        return;
      }
    }
  }
  
  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    return Array.from(this.follows.values()).some(
      (follow) => follow.followerId === followerId && follow.followingId === followingId
    );
  }
  
  async getFollowersCount(userId: number): Promise<number> {
    return Array.from(this.follows.values()).filter(
      (follow) => follow.followingId === userId
    ).length;
  }
  
  async getFollowingCount(userId: number): Promise<number> {
    return Array.from(this.follows.values()).filter(
      (follow) => follow.followerId === userId
    ).length;
  }
  
  async getSuggestedUsers(userId: number): Promise<User[]> {
    // Get users that the current user is not following
    const following = Array.from(this.follows.values())
      .filter(follow => follow.followerId === userId)
      .map(follow => follow.followingId);
    
    return Array.from(this.users.values())
      .filter(user => user.id !== userId && !following.includes(user.id))
      .map(user => ({
        ...user,
        isFollowing: false
      }))
      .slice(0, 5);
  }
  
  async getPopularUsers(userId: number): Promise<User[]> {
    // In a real implementation, this would get users with the most followers
    // For now, return a few random users
    const following = Array.from(this.follows.values())
      .filter(follow => follow.followerId === userId)
      .map(follow => follow.followingId);
    
    return Array.from(this.users.values())
      .filter(user => user.id !== userId)
      .slice(0, 10)
      .map(user => ({
        ...user,
        isFollowing: following.includes(user.id),
        followersCount: Array.from(this.follows.values()).filter(
          follow => follow.followingId === user.id
        ).length,
        followingCount: Array.from(this.follows.values()).filter(
          follow => follow.followerId === user.id
        ).length
      }));
  }
  
  // Post operations
  async getPost(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }
  
  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.postIdCounter++;
    const now = new Date();
    const post: Post = {
      ...insertPost,
      id,
      likes: 0,
      comments: 0,
      shares: 0,
      createdAt: now,
      updatedAt: now
    };
    
    this.posts.set(id, post);
    return post;
  }
  
  async deletePost(id: number): Promise<void> {
    this.posts.delete(id);
    
    // Delete related likes
    for (const [likeId, like] of this.likes.entries()) {
      if (like.postId === id) {
        this.likes.delete(likeId);
      }
    }
    
    // Delete related bookmarks
    for (const [bookmarkId, bookmark] of this.bookmarks.entries()) {
      if (bookmark.postId === id) {
        this.bookmarks.delete(bookmarkId);
      }
    }
  }
  
  async getFeedPosts(userId: number): Promise<PostWithAuthor[]> {
    // For feed, include popular posts and posts from followed users
    // In a real implementation, this would have more complex logic
    const posts = Array.from(this.posts.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    return await Promise.all(posts.map(async post => {
      const author = await this.getUser(post.userId);
      if (!author) throw new Error("Author not found");
      
      const isLiked = await this.isPostLikedByUser(userId, post.id);
      const isBookmarked = await this.isPostBookmarkedByUser(userId, post.id);
      
      return {
        post: {
          ...post,
          liked: isLiked,
          bookmarked: isBookmarked
        },
        author: await this.getAuthorWithFollowStatus(author, userId)
      };
    }));
  }
  
  async getFollowingPosts(userId: number): Promise<PostWithAuthor[]> {
    // Get posts only from users the current user follows
    const following = Array.from(this.follows.values())
      .filter(follow => follow.followerId === userId)
      .map(follow => follow.followingId);
    
    const posts = Array.from(this.posts.values())
      .filter(post => following.includes(post.userId))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return await Promise.all(posts.map(async post => {
      const author = await this.getUser(post.userId);
      if (!author) throw new Error("Author not found");
      
      const isLiked = await this.isPostLikedByUser(userId, post.id);
      const isBookmarked = await this.isPostBookmarkedByUser(userId, post.id);
      
      return {
        post: {
          ...post,
          liked: isLiked,
          bookmarked: isBookmarked
        },
        author: await this.getAuthorWithFollowStatus(author, userId)
      };
    }));
  }
  
  async getUserPosts(userId: number, currentUserId: number): Promise<PostWithAuthor[]> {
    const posts = Array.from(this.posts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    const author = await this.getUser(userId);
    if (!author) throw new Error("Author not found");
    
    const authorWithStatus = await this.getAuthorWithFollowStatus(author, currentUserId);
    
    return await Promise.all(posts.map(async post => {
      const isLiked = await this.isPostLikedByUser(currentUserId, post.id);
      const isBookmarked = await this.isPostBookmarkedByUser(currentUserId, post.id);
      
      return {
        post: {
          ...post,
          liked: isLiked,
          bookmarked: isBookmarked
        },
        author: authorWithStatus
      };
    }));
  }
  
  async getUserLikedPosts(userId: number, currentUserId: number): Promise<PostWithAuthor[]> {
    // Get posts liked by the user
    const likedPostIds = Array.from(this.likes.values())
      .filter(like => like.userId === userId)
      .map(like => like.postId);
    
    const posts = Array.from(this.posts.values())
      .filter(post => likedPostIds.includes(post.id))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return await Promise.all(posts.map(async post => {
      const author = await this.getUser(post.userId);
      if (!author) throw new Error("Author not found");
      
      const isLiked = await this.isPostLikedByUser(currentUserId, post.id);
      const isBookmarked = await this.isPostBookmarkedByUser(currentUserId, post.id);
      
      return {
        post: {
          ...post,
          liked: isLiked,
          bookmarked: isBookmarked
        },
        author: await this.getAuthorWithFollowStatus(author, currentUserId)
      };
    }));
  }
  
  async getTrendingPosts(limit: number = 10, cursor?: string): Promise<{posts: PostWithAuthor[], cursor: string, hasMore: boolean}> {
    // In a real implementation, this would get posts with the most engagement
    const posts = Array.from(this.posts.values())
      .sort((a, b) => (b.likes + b.comments + b.shares) - (a.likes + a.comments + a.shares));
    
    let startIndex = 0;
    if (cursor) {
      // Parse cursor as JSON containing the last post ID and sort value
      const parsedCursor = JSON.parse(cursor);
      const lastPostId = parsedCursor.id;
      
      // Find the index of the last post
      const lastPostIndex = posts.findIndex(post => post.id === lastPostId);
      if (lastPostIndex !== -1) {
        startIndex = lastPostIndex + 1;
      }
    }
    
    const paginatedPosts = posts.slice(startIndex, startIndex + limit);
    const hasMore = startIndex + limit < posts.length;
    
    // Create cursor for next page
    let nextCursor = "";
    if (paginatedPosts.length > 0 && hasMore) {
      const lastPost = paginatedPosts[paginatedPosts.length - 1];
      nextCursor = JSON.stringify({
        id: lastPost.id,
        value: lastPost.likes + lastPost.comments + lastPost.shares
      });
    }
    
    const postsWithAuthor = await Promise.all(paginatedPosts.map(async post => {
      const author = await this.getUser(post.userId);
      if (!author) throw new Error("Author not found");
      
      return {
        post,
        author: await this.getAuthorWithFollowStatus(author, -1) // -1 means no current user (for public trending)
      };
    }));
    
    return {
      posts: postsWithAuthor,
      cursor: nextCursor,
      hasMore
    };
  }
  
  // Interactions
  async likePost(userId: number, postId: number): Promise<void> {
    // Check if already liked
    const isAlreadyLiked = await this.isPostLikedByUser(userId, postId);
    if (isAlreadyLiked) return;
    
    // Add like
    const id = this.likeIdCounter++;
    this.likes.set(id, { userId, postId });
    
    // Update post like count
    const post = await this.getPost(postId);
    if (post) {
      post.likes++;
      this.posts.set(postId, post);
    }
  }
  
  async unlikePost(userId: number, postId: number): Promise<void> {
    let likeId: number | null = null;
    
    for (const [id, like] of this.likes.entries()) {
      if (like.userId === userId && like.postId === postId) {
        likeId = id;
        break;
      }
    }
    
    if (likeId !== null) {
      this.likes.delete(likeId);
      
      // Update post like count
      const post = await this.getPost(postId);
      if (post && post.likes > 0) {
        post.likes--;
        this.posts.set(postId, post);
      }
    }
  }
  
  async bookmarkPost(userId: number, postId: number): Promise<void> {
    // Check if already bookmarked
    const isAlreadyBookmarked = await this.isPostBookmarkedByUser(userId, postId);
    if (isAlreadyBookmarked) return;
    
    // Add bookmark
    const id = this.bookmarkIdCounter++;
    this.bookmarks.set(id, { userId, postId });
  }
  
  async unbookmarkPost(userId: number, postId: number): Promise<void> {
    let bookmarkId: number | null = null;
    
    for (const [id, bookmark] of this.bookmarks.entries()) {
      if (bookmark.userId === userId && bookmark.postId === postId) {
        bookmarkId = id;
        break;
      }
    }
    
    if (bookmarkId !== null) {
      this.bookmarks.delete(bookmarkId);
    }
  }
  
  async getUserBookmarks(userId: number): Promise<PostWithAuthor[]> {
    // Get posts bookmarked by the user
    const bookmarkedPostIds = Array.from(this.bookmarks.values())
      .filter(bookmark => bookmark.userId === userId)
      .map(bookmark => bookmark.postId);
    
    const posts = Array.from(this.posts.values())
      .filter(post => bookmarkedPostIds.includes(post.id))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return await Promise.all(posts.map(async post => {
      const author = await this.getUser(post.userId);
      if (!author) throw new Error("Author not found");
      
      const isLiked = await this.isPostLikedByUser(userId, post.id);
      
      return {
        post: {
          ...post,
          liked: isLiked,
          bookmarked: true // Already know it's bookmarked
        },
        author: await this.getAuthorWithFollowStatus(author, userId)
      };
    }));
  }
  
  // Search
  async searchUsers(query: string, currentUserId: number): Promise<User[]> {
    const normalizedQuery = query.toLowerCase();
    
    const users = Array.from(this.users.values())
      .filter(user => 
        user.username.toLowerCase().includes(normalizedQuery) || 
        (user.fullName && user.fullName.toLowerCase().includes(normalizedQuery))
      );
    
    return await Promise.all(users.map(async user => 
      this.getAuthorWithFollowStatus(user, currentUserId)
    ));
  }
  
  async searchPosts(query: string, currentUserId: number): Promise<PostWithAuthor[]> {
    const normalizedQuery = query.toLowerCase();
    
    const posts = Array.from(this.posts.values())
      .filter(post => post.content.toLowerCase().includes(normalizedQuery))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return await Promise.all(posts.map(async post => {
      const author = await this.getUser(post.userId);
      if (!author) throw new Error("Author not found");
      
      const isLiked = await this.isPostLikedByUser(currentUserId, post.id);
      const isBookmarked = await this.isPostBookmarkedByUser(currentUserId, post.id);
      
      return {
        post: {
          ...post,
          liked: isLiked,
          bookmarked: isBookmarked
        },
        author: await this.getAuthorWithFollowStatus(author, currentUserId)
      };
    }));
  }
  
  // Trending
  async getTrendingTopics(): Promise<TrendingTopic[]> {
    // In a real implementation, this would analyze post content
    // For now, return a predefined list
    return [
      { category: "Technology", topic: "ReactJS", count: 4218 },
      { category: "Design", topic: "UIDesign", count: 2943 },
      { category: "News", topic: "TechConference2023", count: 1837 },
      { category: "Career", topic: "RemoteWork", count: 1426 },
      { category: "Development", topic: "WebDev", count: 1247 },
      { category: "AI", topic: "MachineLearning", count: 986 }
    ];
  }
  
  // Helper methods
  private async isPostLikedByUser(userId: number, postId: number): Promise<boolean> {
    return Array.from(this.likes.values()).some(
      (like) => like.userId === userId && like.postId === postId
    );
  }
  
  private async isPostBookmarkedByUser(userId: number, postId: number): Promise<boolean> {
    return Array.from(this.bookmarks.values()).some(
      (bookmark) => bookmark.userId === userId && bookmark.postId === postId
    );
  }
  
  private async getAuthorWithFollowStatus(author: User, currentUserId: number): Promise<User> {
    if (currentUserId === -1 || author.id === currentUserId) {
      return {
        ...author,
        isFollowing: false,
        followersCount: await this.getFollowersCount(author.id),
        followingCount: await this.getFollowingCount(author.id)
      };
    }
    
    const isFollowing = await this.isFollowing(currentUserId, author.id);
    return {
      ...author,
      isFollowing,
      followersCount: await this.getFollowersCount(author.id),
      followingCount: await this.getFollowingCount(author.id)
    };
  }
  
  // Initialize with sample data for testing
  private async initializeSampleData() {
    // This will be empty in production - to be filled by user registrations
  }
}

export const storage = new MemStorage();
