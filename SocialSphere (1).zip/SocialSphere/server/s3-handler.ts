import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { createHash } from "crypto";

// Initialize S3 client
const s3Client = new S3Client({
  region: process.env.AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
  },
});

const BUCKET_NAME = process.env.AWS_S3_BUCKET || "connecto-media";

// Generate a unique filename for the uploaded file
function generateUniqueFilename(originalName: string): string {
  const timestamp = Date.now();
  const randomString = createHash('md5')
    .update(`${timestamp}-${originalName}-${Math.random()}`)
    .digest('hex')
    .substring(0, 12);
  
  // Extract file extension from original name
  const fileExtension = originalName.split('.').pop() || '';
  
  return `${timestamp}-${randomString}.${fileExtension}`;
}

// Upload a file to S3
export async function uploadToS3(
  file: Express.Multer.File,
  folder: string = "uploads"
): Promise<string> {
  try {
    const filename = generateUniqueFilename(file.originalname);
    const key = `${folder}/${filename}`;
    
    const params = {
      Bucket: BUCKET_NAME,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
    };
    
    await s3Client.send(new PutObjectCommand(params));
    
    // Return the URL of the uploaded file
    return `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`;
  } catch (error) {
    console.error("Error uploading to S3:", error);
    throw new Error("Failed to upload file to S3");
  }
}

// Generate a pre-signed URL for downloading a file
export async function generateSignedUrl(key: string, expiresIn: number = 3600): Promise<string> {
  try {
    const command = new GetObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
    });
    
    return await getSignedUrl(s3Client, command, { expiresIn });
  } catch (error) {
    console.error("Error generating signed URL:", error);
    throw new Error("Failed to generate signed URL");
  }
}

// Helper function to handle S3 when no credentials are provided (for development)
export function handleS3WithoutCredentials() {
  if (!process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) {
    console.warn("AWS credentials not found. S3 uploads will return mock URLs.");
    return true;
  }
  return false;
}
