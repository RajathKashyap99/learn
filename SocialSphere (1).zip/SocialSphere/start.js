/**
 * Starter script for Connecto social media application
 * This script helps start both backend and frontend in development mode
 */

const { spawn } = require('child_process');
const path = require('path');

// Load environment variables
require('dotenv').config();

// Start the backend server
const backend = spawn('node', ['backend/server.js'], {
  stdio: 'inherit',
  env: process.env
});

// Start the frontend development server
const frontend = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  env: process.env
});

// Handle cleanup on exit
const cleanup = () => {
  console.log('\nShutting down services...');
  backend.kill();
  frontend.kill();
  process.exit();
};

// Listen for termination signals
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

// Handle backend process exit
backend.on('close', (code) => {
  if (code !== 0 && code !== null) {
    console.error(`Backend server exited with code ${code}`);
    frontend.kill();
    process.exit(code);
  }
});

// Handle frontend process exit
frontend.on('close', (code) => {
  if (code !== 0 && code !== null) {
    console.error(`Frontend server exited with code ${code}`);
    backend.kill();
    process.exit(code);
  }
});

console.log('Connecto application started!');
console.log('Backend running at: http://localhost:5000');
console.log('Frontend running at: http://localhost:3000');
console.log('Press Ctrl+C to stop all services.');