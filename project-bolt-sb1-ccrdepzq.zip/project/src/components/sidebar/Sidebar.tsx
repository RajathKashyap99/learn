import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, UserPlus, Users, X, TrendingUp } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion, AnimatePresence } from 'framer-motion';

// Import placeholders for demo
import avatar1 from '@/assets/avatars/avatar1.jpg';
import avatar2 from '@/assets/avatars/avatar2.jpg';
import avatar3 from '@/assets/avatars/avatar3.jpg';
import avatar4 from '@/assets/avatars/avatar4.jpg';
import avatar5 from '@/assets/avatars/avatar5.jpg';

interface Friend {
  id: number;
  name: string;
  avatar: string;
  status: 'online' | 'offline';
  lastActive?: string;
}

interface Suggestion {
  id: number;
  name: string;
  avatar: string;
  mutualFriends: number;
  followed: boolean;
}

interface Trend {
  id: number;
  tag: string;
  posts: string;
}

const friends: Friend[] = [
  {
    id: 1,
    name: 'Alex Johnson',
    avatar: avatar1,
    status: 'online',
  },
  {
    id: 2,
    name: 'Sarah Parker',
    avatar: avatar2,
    status: 'online',
  },
  {
    id: 3,
    name: 'Michael Chen',
    avatar: avatar3,
    status: 'offline',
    lastActive: '30m ago',
  },
  {
    id: 4,
    name: 'Emily Rodriguez',
    avatar: avatar4,
    status: 'online',
  },
  {
    id: 5,
    name: 'David Kim',
    avatar: avatar5,
    status: 'offline',
    lastActive: '2h ago',
  },
];

const suggestions: Suggestion[] = [
  {
    id: 1,
    name: 'Jennifer Liu',
    avatar: avatar5,
    mutualFriends: 5,
    followed: false,
  },
  {
    id: 2,
    name: 'Robert Taylor',
    avatar: avatar4,
    mutualFriends: 3,
    followed: false,
  },
  {
    id: 3,
    name: 'Sophia Wang',
    avatar: avatar3,
    mutualFriends: 7,
    followed: false,
  },
];

const trends: Trend[] = [
  {
    id: 1,
    tag: '#ArtificialIntelligence',
    posts: '125K',
  },
  {
    id: 2,
    tag: '#WorldCup2026',
    posts: '98K',
  },
  {
    id: 3,
    tag: '#ClimateAction',
    posts: '87K',
  },
  {
    id: 4,
    tag: '#TechNews',
    posts: '76K',
  },
];

export function Sidebar() {
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestionsState, setSuggestionsState] = useState(suggestions);

  const handleFollow = (id: number) => {
    setSuggestionsState(
      suggestionsState.map((suggestion) =>
        suggestion.id === id
          ? { ...suggestion, followed: !suggestion.followed }
          : suggestion
      )
    );
  };

  const handleDismissSuggestion = (id: number) => {
    setSuggestionsState(suggestionsState.filter((suggestion) => suggestion.id !== id));
  };

  const filteredFriends = searchQuery
    ? friends.filter((friend) =>
        friend.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : friends;

  return (
    <div className="space-y-4">
      <Card className="bg-card shadow-md">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold flex items-center">
              <Users className="mr-2 h-5 w-5 text-primary" />
              Friends
            </CardTitle>
            <div className="relative w-full max-w-[180px]">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search friends..."
                className="pl-8 h-9 bg-muted/50 border-none text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-2 py-2">
          <ScrollArea className="h-[200px] px-2">
            <AnimatePresence>
              {filteredFriends.length > 0 ? (
                <div className="space-y-2">
                  {filteredFriends.map((friend) => (
                    <motion.div
                      key={friend.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                      className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <div className="relative">
                          <Avatar className="h-9 w-9">
                            <AvatarImage src={friend.avatar} alt={friend.name} />
                            <AvatarFallback>{friend.name[0]}</AvatarFallback>
                          </Avatar>
                          <span 
                            className={`absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card ${
                              friend.status === 'online' ? 'bg-green-500' : 'bg-gray-500'
                            }`}
                          ></span>
                        </div>
                        <div>
                          <p className="text-sm font-medium">{friend.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {friend.status === 'online'
                              ? 'Online'
                              : `Last active ${friend.lastActive}`}
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MessageCircle className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                  No friends found
                </div>
              )}
            </AnimatePresence>
          </ScrollArea>
        </CardContent>
      </Card>

      <Card className="bg-card shadow-md">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold flex items-center">
            <UserPlus className="mr-2 h-5 w-5 text-primary" />
            Suggested for you
          </CardTitle>
        </CardHeader>
        <CardContent className="px-2 py-2">
          <AnimatePresence>
            {suggestionsState.length > 0 ? (
              <div className="space-y-2">
                {suggestionsState.map((suggestion) => (
                  <motion.div
                    key={suggestion.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={suggestion.avatar} alt={suggestion.name} />
                        <AvatarFallback>{suggestion.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{suggestion.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {suggestion.mutualFriends} mutual friends
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant={suggestion.followed ? "outline" : "default"}
                        size="sm"
                        className="h-8 text-xs"
                        onClick={() => handleFollow(suggestion.id)}
                      >
                        {suggestion.followed ? "Following" : "Follow"}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleDismissSuggestion(suggestion.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground text-sm">
                No suggestions available
              </div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>

      <Card className="bg-card shadow-md">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold flex items-center">
            <TrendingUp className="mr-2 h-5 w-5 text-primary" />
            Trending
          </CardTitle>
        </CardHeader>
        <CardContent className="px-2 py-2">
          <div className="space-y-2">
            {trends.map((trend) => (
              <div
                key={trend.id}
                className="p-2 rounded-md hover:bg-muted/50 transition-colors cursor-pointer"
              >
                <p className="text-sm font-medium text-primary">{trend.tag}</p>
                <p className="text-xs text-muted-foreground">
                  {trend.posts} posts
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

const MessageCircle = ({ className }: { className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
  </svg>
);