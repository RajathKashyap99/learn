import React, { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, X } from 'lucide-react';

interface Comment {
  id: string;
  user: {
    name: string;
    avatar: string;
  };
  text: string;
  timestamp: string;
  likes: number;
  liked: boolean;
}

interface CommentSectionProps {
  postId: string;
  onClose: () => void;
}

// Demo data
const demoAvatars = [
  'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
  'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg',
  'https://images.pexels.com/photos/1771383/pexels-photo-1771383.jpeg',
  'https://images.pexels.com/photos/1559486/pexels-photo-1559486.jpeg',
  'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg'
];

const demoNames = ['Sarah Wilson', 'Mike Chen', 'Emma Davis', 'Alex Kim', 'Jordan Taylor'];

const randomCommentCount = Math.floor(Math.random() * 3) + 2; // 2-4 comments

const demoComments: Comment[] = Array.from({ length: randomCommentCount }).map((_, i) => {
  const randomAvatarIndex = Math.floor(Math.random() * demoAvatars.length);
  return {
    id: `comment-${i}-${Date.now()}`,
    user: {
      name: demoNames[randomAvatarIndex],
      avatar: demoAvatars[randomAvatarIndex],
    },
    text: [
      'Great post! Thanks for sharing.',
      'I completely agree with you!',
      'This is really interesting, never thought about it that way.',
      'Love this! Can\'t wait to see more content like this.',
      'Thanks for the insight!',
    ][Math.floor(Math.random() * 5)],
    timestamp: ['5m ago', '10m ago', '15m ago', '30m ago', '1h ago'][
      Math.floor(Math.random() * 5)
    ],
    likes: Math.floor(Math.random() * 10),
    liked: false,
  };
});

const CommentSection: React.FC<CommentSectionProps> = ({ postId, onClose }) => {
  const [comments, setComments] = useState<Comment[]>(demoComments);
  const [newComment, setNewComment] = useState('');

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: `comment-${Date.now()}`,
      user: {
        name: 'Current User',
        avatar: demoAvatars[0],
      },
      text: newComment,
      timestamp: 'just now',
      likes: 0,
      liked: false,
    };

    setComments([comment, ...comments]);
    setNewComment('');
  };

  const handleLikeComment = (commentId: string) => {
    setComments(comments.map(comment => {
      if (comment.id === commentId) {
        return {
          ...comment,
          likes: comment.liked ? comment.likes - 1 : comment.likes + 1,
          liked: !comment.liked,
        };
      }
      return comment;
    }));
  };

  return (
    <div className="bg-card rounded-lg shadow-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-card-foreground">Comments</h3>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="text-muted-foreground hover:text-card-foreground"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <form onSubmit={handleSubmitComment} className="flex gap-2 mb-4">
        <Avatar className="h-8 w-8">
          <AvatarImage src={demoAvatars[0]} />
          <AvatarFallback>CU</AvatarFallback>
        </Avatar>
        <div className="flex-1 flex gap-2">
          <Input
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Write a comment..."
            className="flex-1 bg-muted text-card-foreground"
          />
          <Button type="submit" size="sm" className="text-primary-foreground">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>

      <div className="space-y-4">
        {comments.map((comment) => (
          <div key={comment.id} className="flex gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={comment.user.avatar} />
              <AvatarFallback>{comment.user.name[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="bg-muted p-2 rounded-lg">
                <div className="font-semibold text-sm text-card-foreground">
                  {comment.user.name}
                </div>
                <p className="text-sm text-card-foreground">{comment.text}</p>
              </div>
              <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                <button
                  onClick={() => handleLikeComment(comment.id)}
                  className={`hover:text-primary ${comment.liked ? 'text-primary' : ''}`}
                >
                  {comment.likes} likes
                </button>
                <span>{comment.timestamp}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommentSection;