import { useState, useRef } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Image, MapPin, X, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

interface CreatePostProps {
  profileData: any[];
  onCreatePost: (desc: string, location: string, image: File | null) => Promise<void>;
}

export function CreatePost({ profileData, onCreatePost }: CreatePostProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [postText, setPostText] = useState('');
  const [location, setLocation] = useState('');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] || null;
    if (file) {
      setSelectedImage(file);
      const objectUrl = URL.createObjectURL(file);
      setPreviewUrl(objectUrl);
    }
  };

  const handleRemoveImage = () => {
    setSelectedImage(null);
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async () => {
    if (!postText.trim()) {
      toast.error('Please enter some content for your post');
      return;
    }

    setIsSubmitting(true);
    try {
      await onCreatePost(postText, location, selectedImage);
      setPostText('');
      setLocation('');
      setSelectedImage(null);
      setPreviewUrl(null);
      setIsDialogOpen(false);
      toast.success('Post created successfully!');
    } catch (error) {
      toast.error('Failed to create post. Please try again.');
      console.error('Error creating post:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Card className="bg-card shadow-md hover:shadow-lg transition-all duration-300">
        <CardContent className="p-4">
          <div className="flex items-center gap-2">
            <Avatar className="ring-2 ring-primary/20">
              {profileData.length > 0 && profileData[0].profileImg ? (
                <AvatarImage 
                  src={`http://localhost:8000/Images/${profileData[0].profileImg}`} 
                  alt={profileData[0].username} 
                />
              ) : (
                <AvatarFallback className="bg-blue-600/20 text-primary-foreground">
                  {profileData.length > 0 
                    ? profileData[0].username?.[0]?.toUpperCase() 
                    : 'U'}
                </AvatarFallback>
              )}
            </Avatar>
            <div 
              className="flex-1 bg-muted rounded-full px-4 py-2 text-muted-foreground cursor-pointer hover:bg-muted/70 transition-colors"
              onClick={() => setIsDialogOpen(true)}
            >
              What's on your mind?
            </div>
          </div>
        </CardContent>
        <CardFooter className="p-0 px-4 pb-3">
          <div className="flex justify-between items-center w-full">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="gap-2 text-blue-500"
                    onClick={() => setIsDialogOpen(true)}
                  >
                    <Image className="h-4 w-4" />
                    <span className="hidden sm:inline">Photo</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Add a photo to your post</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="gap-2 text-red-500"
                    onClick={() => setIsDialogOpen(true)}
                  >
                    <MapPin className="h-4 w-4" />
                    <span className="hidden sm:inline">Location</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Add your location</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <Button 
              size="sm"
              className="gap-2 bg-primary text-primary-foreground"
              onClick={() => setIsDialogOpen(true)}
            >
              Create Post
            </Button>
          </div>
        </CardFooter>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md md:max-w-lg bg-card">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-center">Create Post</DialogTitle>
            <DialogDescription className="text-center text-muted-foreground">
              Share what's on your mind with your friends
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Avatar className="ring-2 ring-primary/20">
                {profileData.length > 0 && profileData[0].profileImg ? (
                  <AvatarImage 
                    src={`http://localhost:8000/Images/${profileData[0].profileImg}`} 
                    alt={profileData[0].username} 
                  />
                ) : (
                  <AvatarFallback className="bg-blue-600/20 text-primary-foreground">
                    {profileData.length > 0 
                      ? profileData[0].username?.[0]?.toUpperCase() 
                      : 'U'}
                  </AvatarFallback>
                )}
              </Avatar>
              <div>
                <p className="font-semibold">
                  {profileData.length > 0 
                    ? profileData[0].fullname || profileData[0].username 
                    : 'User'}
                </p>
                <div className="flex items-center gap-1 text-muted-foreground text-xs">
                  <MapPin className="h-3 w-3" />
                  <Input 
                    placeholder="Add your location"
                    className="h-6 p-0 pl-1 border-none bg-transparent focus-visible:ring-0 text-xs text-muted-foreground" 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
              </div>
            </div>

            <Textarea 
              placeholder="What's on your mind?"
              className="min-h-[120px] border-none focus-visible:ring-0 resize-none text-card-foreground bg-transparent text-lg"
              value={postText}
              onChange={(e) => setPostText(e.target.value)}
            />

            {previewUrl && (
              <div className="relative rounded-md overflow-hidden border border-border">
                <img 
                  src={previewUrl} 
                  alt="Post preview" 
                  className="w-full max-h-[300px] object-cover"
                />
                <Button 
                  variant="destructive" 
                  size="icon" 
                  className="absolute top-2 right-2 h-8 w-8 rounded-full opacity-80 hover:opacity-100"
                  onClick={handleRemoveImage}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}

            <div className="flex items-center gap-2 border border-border rounded-md p-3">
              <p className="text-sm font-medium flex-grow">Add to your post</p>
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="text-blue-500 hover:bg-blue-500/10 p-2 rounded-full transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <Image className="h-5 w-5" />
              </motion.button>
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept="image/*"
                onChange={handleImageChange}
              />
            </div>
          </div>

          <DialogFooter className="sm:justify-between gap-2">
            <DialogClose asChild>
              <Button variant="outline" className="w-full sm:w-auto">
                Cancel
              </Button>
            </DialogClose>
            <Button 
              className="w-full sm:w-auto bg-primary text-primary-foreground"
              disabled={isSubmitting || !postText.trim()}
              onClick={handleSubmit}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Posting...
                </>
              ) : (
                'Post'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}