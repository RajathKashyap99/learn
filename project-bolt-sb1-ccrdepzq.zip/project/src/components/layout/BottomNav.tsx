import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Home, Compass, Bell, MessageSquare, User } from 'lucide-react';

export function BottomNav() {
  const location = useLocation();

  const items = [
    {
      title: 'Home',
      href: '/home',
      icon: Home,
    },
    {
      title: 'Explore',
      href: '/explore',
      icon: Compass,
    },
    {
      title: 'Notifications',
      href: '/notifications',
      icon: Bell,
      indicator: true,
    },
    {
      title: 'Messages',
      href: '/messages',
      icon: MessageSquare,
    },
    {
      title: 'Profile',
      href: '/profile',
      icon: User,
    },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-background border-t border-border">
      <div className="grid grid-cols-5">
        {items.map((item) => (
          <Link
            key={item.href}
            to={item.href}
            className={cn(
              'flex flex-col items-center justify-center py-2 transition-colors',
              location.pathname === item.href ? 'text-primary' : 'text-muted-foreground'
            )}
          >
            <div className="relative">
              <item.icon className="h-6 w-6" />
              {item.indicator && (
                <span className="absolute -top-1 -right-1 h-2 w-2 bg-primary rounded-full" />
              )}
            </div>
            <span className="text-xs mt-1">{item.title}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}