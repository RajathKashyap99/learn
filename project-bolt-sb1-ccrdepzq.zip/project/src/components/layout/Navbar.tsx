import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { useTheme } from '@/components/theme-provider';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';
import {
  Home,
  Compass,
  Bell,
  MessageSquare,
  User,
  Settings,
  LogOut,
  Moon,
  Sun,
  Menu,
} from 'lucide-react';
import { useSelector } from 'react-redux';
import { RootState } from '@/redux/store';
import { useState } from 'react';
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

const mainNavItems = [
  {
    title: 'Home',
    href: '/home',
    icon: Home,
  },
  {
    title: 'Explore',
    href: '/explore',
    icon: Compass,
  },
  {
    title: 'Notifications',
    href: '/notifications',
    icon: Bell,
  },
  {
    title: 'Messages',
    href: '/messages',
    icon: MessageSquare,
  },
  {
    title: 'Profile',
    href: '/profile',
    icon: User,
  },
];

export function Navbar() {
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const profileData = useSelector((state: RootState) => state.profiles.data);
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    window.location.href = '/login';
  };

  return (
    <>
      {/* Mobile menu button (always visible) */}
      <div className="fixed top-4 left-4 z-50 md:hidden">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="bg-background border-border">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="bg-card p-0 border-r border-border">
            <SheetHeader className="h-16 px-6 flex items-center justify-center">
              <SheetTitle className="text-2xl font-bold text-primary">E</SheetTitle>
            </SheetHeader>
            <nav className="space-y-1 p-2">
              {mainNavItems.map((item) => (
                <SheetClose asChild key={item.href}>
                  <Link
                    to={item.href}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2 rounded-md text-foreground transition-colors hover:bg-muted',
                      location.pathname === item.href && 'bg-primary/10 text-primary'
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.title}</span>
                    {item.title === 'Notifications' && (
                      <span className="ml-auto bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded-full">
                        3
                      </span>
                    )}
                  </Link>
                </SheetClose>
              ))}

              <Separator className="my-2" />

              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              >
                {theme === 'dark' ? (
                  <Sun className="h-5 w-5 mr-2" />
                ) : (
                  <Moon className="h-5 w-5 mr-2" />
                )}
                {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
              </Button>

              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
                onClick={handleLogout}
              >
                <LogOut className="h-5 w-5 mr-2" />
                Logout
              </Button>
            </nav>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop sidebar (fixed) */}
      <aside className="hidden md:flex fixed inset-y-0 left-0 flex-col w-16 lg:w-64 border-r border-border bg-background z-40">
        <div className="h-16 flex items-center px-6">
          <Link to="/home" className="flex items-center gap-2">
            <span className="flex items-center justify-center h-8 w-8 rounded-md bg-primary text-primary-foreground text-lg font-bold">
              E
            </span>
            <span className="hidden lg:inline text-xl font-bold">Echolite</span>
          </Link>
        </div>

        <nav className="flex-1 space-y-1 p-2">
          {mainNavItems.map((item) => (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-md text-foreground transition-colors hover:bg-muted',
                location.pathname === item.href && 'bg-primary/10 text-primary'
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="hidden lg:inline">{item.title}</span>
              {item.title === 'Notifications' && (
                <span className="ml-auto bg-primary text-primary-foreground text-xs px-1.5 py-0.5 rounded-full">
                  3
                </span>
              )}
            </Link>
          ))}
        </nav>

        <div className="p-4 mt-auto">
          <Separator className="mb-4" />
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              {profileData.length > 0 && profileData[0].profileImg ? (
                <AvatarImage
                  src={`http://localhost:8000/Images/${profileData[0].profileImg}`}
                  alt="Profile"
                />
              ) : (
                <AvatarFallback className="bg-primary/20">
                  {profileData.length > 0 
                    ? profileData[0].username.charAt(0).toUpperCase() 
                    : 'U'}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="hidden lg:block overflow-hidden">
              <p className="text-sm font-medium truncate">
                {profileData.length > 0 ? profileData[0].fullname : 'User'}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                @{profileData.length > 0 ? profileData[0].username : 'username'}
              </p>
            </div>
            <div className="ml-auto flex gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="h-8 w-8"
              >
                {theme === 'dark' ? (
                  <Sun className="h-4 w-4" />
                ) : (
                  <Moon className="h-4 w-4" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
              >
                <LogOut className="h-4 w-4" />
                <span className="sr-only">Logout</span>
              </Button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}