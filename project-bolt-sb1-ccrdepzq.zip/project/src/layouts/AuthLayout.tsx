import { Outlet } from 'react-router-dom';
import { useEffect } from 'react';

export default function AuthLayout() {
  useEffect(() => {
    document.body.classList.add('auth-layout');
    return () => {
      document.body.classList.remove('auth-layout');
    };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Outlet />
    </div>
  );
}