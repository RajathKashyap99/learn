import { Outlet } from 'react-router-dom';
import { Navbar } from '@/components/layout/Navbar';
import { BottomNav } from '@/components/layout/BottomNav';
import { motion } from 'framer-motion';

export default function MainLayout() {
  return (
    <div className="flex min-h-screen bg-background">
      <Navbar />
      <main className="flex-1 pb-16 md:pb-0 md:ml-16 lg:ml-64">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="container max-w-5xl mx-auto px-4 py-6"
        >
          <Outlet />
        </motion.div>
      </main>
      <BottomNav />
    </div>
  );
}