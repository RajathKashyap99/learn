import { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useDispatch } from 'react-redux';
import { fetchPosts } from '@/redux/postSlice';
import { Feed } from '@/components/feed/Feed';
import { Sidebar } from '@/components/sidebar/Sidebar';
import { AppDispatch } from '@/redux/store';

export default function Home() {
  const dispatch = useDispatch<AppDispatch>();

  useEffect(() => {
    dispatch(fetchPosts());
  }, [dispatch]);

  return (
    <>
      <Helmet title="Home | Echolite" />
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-6">
        <Feed />
        <div className="hidden lg:block">
          <Sidebar />
        </div>
      </div>
    </>
  );
}