import Profile from '@/components/profile/Profile';
import { Helmet } from 'react-helmet';

export default function ProfilePage() {
  return (
    <>
      <Helmet title="Profile | Echolite" />
      <Profile />
    </>
  );
}