import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Search, Compass, TrendingUp, Zap, Sparkles } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';

// Import placeholders for demo
import avatar1 from '@/assets/avatars/avatar1.jpg';
import avatar2 from '@/assets/avatars/avatar2.jpg';
import avatar3 from '@/assets/avatars/avatar3.jpg';
import avatar4 from '@/assets/avatars/avatar4.jpg';
import avatar5 from '@/assets/avatars/avatar5.jpg';
import image1 from '@/assets/posts/travel.avif';
import image2 from '@/assets/posts/food.webp';
import image3 from '@/assets/posts/tech.jpg';
import image4 from '@/assets/posts/movies.jpg';
import image5 from '@/assets/posts/sports.jpg';
import image6 from '@/assets/posts/music.jpg';

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: {
      duration: 0.3
    }
  }
};

export default function Explore() {
  const trendingTopics = [
    { id: 1, name: '#WorldCup2026', posts: '125K' },
    { id: 2, name: '#ArtificialIntelligence', posts: '98K' },
    { id: 3, name: '#ClimateAction', posts: '87K' },
    { id: 4, name: '#Olympics', posts: '76K' },
    { id: 5, name: '#SpaceExploration', posts: '54K' },
  ];

  const suggestedUsers = [
    { id: 1, name: 'Alex Johnson', username: 'alexj', avatar: avatar1, followers: '1.2K' },
    { id: 2, name: 'Sarah Parker', username: 'sparker', avatar: avatar2, followers: '3.4K' },
    { id: 3, name: 'Michael Chen', username: 'mchen', avatar: avatar3, followers: '5.6K' },
    { id: 4, name: 'Emily Rodriguez', username: 'emrodz', avatar: avatar4, followers: '7.8K' },
    { id: 5, name: 'David Kim', username: 'dkim', avatar: avatar5, followers: '9.1K' },
  ];

  const exploreImages = [
    { id: 1, image: image1, likes: 854, comments: 42 },
    { id: 2, image: image2, likes: 1254, comments: 89 },
    { id: 3, image: image3, likes: 734, comments: 56 },
    { id: 4, image: image4, likes: 1823, comments: 110 },
    { id: 5, image: image5, likes: 642, comments: 38 },
    { id: 6, image: image6, likes: 1568, comments: 94 },
  ];

  return (
    <>
      <Helmet title="Explore | Echolite" />
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center mb-8">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder="Search for people, posts, topics..." 
              className="pl-10 pr-4 py-2 rounded-full bg-muted/50 border-none focus-visible:ring-primary" 
            />
          </div>
        </div>

        <Tabs defaultValue="discover" className="mb-8">
          <TabsList className="bg-card mb-6">
            <TabsTrigger value="discover" className="data-[state=active]:bg-primary/20">
              <Compass className="h-4 w-4 mr-2" />
              Discover
            </TabsTrigger>
            <TabsTrigger value="trending" className="data-[state=active]:bg-primary/20">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="popular" className="data-[state=active]:bg-primary/20">
              <Zap className="h-4 w-4 mr-2" />
              Popular
            </TabsTrigger>
            <TabsTrigger value="new" className="data-[state=active]:bg-primary/20">
              <Sparkles className="h-4 w-4 mr-2" />
              New
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="discover" className="mt-0">
            <motion.div 
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
            >
              {exploreImages.map((item) => (
                <motion.div 
                  key={item.id} 
                  variants={itemVariants}
                  className="relative overflow-hidden rounded-xl group"
                >
                  <img 
                    src={item.image} 
                    alt="" 
                    className="w-full h-72 object-cover transition-transform duration-500 group-hover:scale-105" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                    <div className="p-4 w-full">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3 text-white">
                          <span>❤️ {item.likes}</span>
                          <span>💬 {item.comments}</span>
                        </div>
                        <Button variant="secondary" size="sm" className="text-xs">View</Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="trending">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <TrendingUp className="mr-2 h-5 w-5 text-primary" />
                  Trending Topics
                </h3>
                <div className="space-y-4">
                  {trendingTopics.map((topic) => (
                    <div 
                      key={topic.id}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                    >
                      <div>
                        <h4 className="font-medium text-foreground">{topic.name}</h4>
                        <p className="text-sm text-muted-foreground">{topic.posts} posts</p>
                      </div>
                      <Button variant="ghost" size="sm">View</Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="popular">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center">
                  <Zap className="mr-2 h-5 w-5 text-primary" />
                  Popular Users
                </h3>
                <div className="space-y-4">
                  {suggestedUsers.map((user) => (
                    <div 
                      key={user.id}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium text-foreground">{user.name}</h4>
                          <p className="text-sm text-muted-foreground">@{user.username} • {user.followers} followers</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">Follow</Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="new">
            <div className="text-center py-8">
              <Sparkles className="h-12 w-12 mx-auto text-primary mb-4" />
              <h3 className="text-xl font-semibold mb-2">Coming Soon!</h3>
              <p className="text-muted-foreground">We're working on bringing you the freshest content.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}