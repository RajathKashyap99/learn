import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Search, Send, Paperclip, MoreVertical, Phone, Video, Info, Image, Smile, Mic } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

// Import placeholders for demo
import avatar1 from '@/assets/avatars/avatar1.jpg';
import avatar2 from '@/assets/avatars/avatar2.jpg';
import avatar3 from '@/assets/avatars/avatar3.jpg';
import avatar4 from '@/assets/avatars/avatar4.jpg';
import avatar5 from '@/assets/avatars/avatar5.jpg';

interface Message {
  id: number;
  content: string;
  timestamp: string;
  sender: 'self' | 'other';
}

interface Conversation {
  id: number;
  user: {
    name: string;
    avatar: string;
    status: 'online' | 'offline' | 'away';
    lastActive?: string;
  };
  lastMessage: string;
  lastMessageTime: string;
  unread: number;
  messages: Message[];
}

const conversations: Conversation[] = [
  {
    id: 1,
    user: {
      name: 'Alex Johnson',
      avatar: avatar1,
      status: 'online',
    },
    lastMessage: 'Hey, are you free tomorrow?',
    lastMessageTime: '5m ago',
    unread: 2,
    messages: [
      {
        id: 1,
        content: 'Hey, how are you doing?',
        timestamp: '11:30 AM',
        sender: 'other',
      },
      {
        id: 2,
        content: 'I\'m good, thanks! Just working on some new projects.',
        timestamp: '11:32 AM',
        sender: 'self',
      },
      {
        id: 3,
        content: 'That sounds exciting! What kind of projects?',
        timestamp: '11:35 AM',
        sender: 'other',
      },
      {
        id: 4,
        content: 'Mostly web development stuff. Working with React and trying out some new UI libraries.',
        timestamp: '11:38 AM',
        sender: 'self',
      },
      {
        id: 5,
        content: 'Nice! I\'ve been getting into React myself recently.',
        timestamp: '11:40 AM',
        sender: 'other',
      },
      {
        id: 6,
        content: 'Hey, are you free tomorrow? Maybe we could grab coffee and chat about code?',
        timestamp: '11:45 AM',
        sender: 'other',
      },
    ],
  },
  {
    id: 2,
    user: {
      name: 'Sarah Parker',
      avatar: avatar2,
      status: 'online',
    },
    lastMessage: 'Did you see that new design?',
    lastMessageTime: '15m ago',
    unread: 0,
    messages: [
      {
        id: 1,
        content: 'Did you see that new design?',
        timestamp: '10:15 AM',
        sender: 'other',
      },
    ],
  },
  {
    id: 3,
    user: {
      name: 'Michael Chen',
      avatar: avatar3,
      status: 'away',
      lastActive: '30m ago',
    },
    lastMessage: 'Thanks for your help yesterday!',
    lastMessageTime: '1h ago',
    unread: 0,
    messages: [
      {
        id: 1,
        content: 'Thanks for your help yesterday!',
        timestamp: '9:30 AM',
        sender: 'other',
      },
    ],
  },
  {
    id: 4,
    user: {
      name: 'Emily Rodriguez',
      avatar: avatar4,
      status: 'offline',
      lastActive: '2h ago',
    },
    lastMessage: 'Let me know when you\'ve reviewed the document',
    lastMessageTime: '3h ago',
    unread: 0,
    messages: [
      {
        id: 1,
        content: 'Let me know when you\'ve reviewed the document',
        timestamp: '8:45 AM',
        sender: 'other',
      },
    ],
  },
  {
    id: 5,
    user: {
      name: 'David Kim',
      avatar: avatar5,
      status: 'online',
    },
    lastMessage: 'Are we still on for the meeting at 3?',
    lastMessageTime: '5h ago',
    unread: 0,
    messages: [
      {
        id: 1,
        content: 'Are we still on for the meeting at 3?',
        timestamp: '7:20 AM',
        sender: 'other',
      },
    ],
  },
];

export default function Messages() {
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(conversations[0]);
  const [messageInput, setMessageInput] = useState('');
  const [conversationsList, setConversationsList] = useState(conversations);

  const handleSendMessage = () => {
    if (!messageInput.trim() || !activeConversation) return;

    const newMessage: Message = {
      id: Date.now(),
      content: messageInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      sender: 'self',
    };

    const updatedConversations = conversationsList.map((conv) => {
      if (conv.id === activeConversation.id) {
        return {
          ...conv,
          messages: [...conv.messages, newMessage],
          lastMessage: messageInput,
          lastMessageTime: 'Just now',
        };
      }
      return conv;
    });

    setConversationsList(updatedConversations);
    setActiveConversation({
      ...activeConversation,
      messages: [...activeConversation.messages, newMessage],
      lastMessage: messageInput,
      lastMessageTime: 'Just now',
    });
    setMessageInput('');
  };

  const selectConversation = (conversation: Conversation) => {
    // Mark as read when selecting
    const updatedConversations = conversationsList.map((conv) => {
      if (conv.id === conversation.id) {
        return {
          ...conv,
          unread: 0,
        };
      }
      return conv;
    });
    
    setConversationsList(updatedConversations);
    setActiveConversation(conversation);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      case 'offline':
        return 'bg-gray-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <>
      <Helmet title="Messages | Echolite" />
      <div className="container mx-auto py-6 h-[calc(100vh-8rem)]">
        <div className="grid grid-cols-1 md:grid-cols-[350px_1fr] gap-4 h-full bg-card rounded-lg overflow-hidden border border-border shadow-xl">
          {/* Sidebar */}
          <div className="border-r border-border flex flex-col h-full">
            <div className="p-4 border-b border-border">
              <h2 className="text-lg font-semibold mb-4">Messages</h2>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Search conversations..." 
                  className="pl-9 bg-muted/50 border-none" 
                />
              </div>
            </div>
            
            <ScrollArea className="flex-grow">
              <div className="space-y-1 p-2">
                {conversationsList.map((conversation) => (
                  <div
                    key={conversation.id}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors",
                      activeConversation?.id === conversation.id
                        ? "bg-muted"
                        : "hover:bg-muted/50"
                    )}
                    onClick={() => selectConversation(conversation)}
                  >
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src={conversation.user.avatar} alt={conversation.user.name} />
                        <AvatarFallback>{conversation.user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span 
                        className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-card ${getStatusColor(conversation.user.status)}`}
                      ></span>
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex justify-between items-center">
                        <h3 className="font-medium truncate">{conversation.user.name}</h3>
                        <span className="text-xs text-muted-foreground">{conversation.lastMessageTime}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <p className="text-sm text-muted-foreground truncate">{conversation.lastMessage}</p>
                        {conversation.unread > 0 && (
                          <span className="flex-shrink-0 h-5 w-5 bg-primary rounded-full flex items-center justify-center text-xs text-primary-foreground">
                            {conversation.unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Chat area */}
          {activeConversation ? (
            <div className="flex flex-col h-full">
              {/* Chat header */}
              <div className="p-4 border-b border-border flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar>
                      <AvatarImage src={activeConversation.user.avatar} alt={activeConversation.user.name} />
                      <AvatarFallback>{activeConversation.user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span 
                      className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-card ${getStatusColor(activeConversation.user.status)}`}
                    ></span>
                  </div>
                  <div>
                    <h3 className="font-medium">{activeConversation.user.name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {activeConversation.user.status === 'online' 
                        ? 'Online' 
                        : activeConversation.user.status === 'away'
                          ? 'Away'
                          : `Last active ${activeConversation.user.lastActive}`}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon">
                    <Phone className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Info className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {/* Messages */}
              <ScrollArea className="flex-grow p-4">
                <div className="space-y-4">
                  {activeConversation.messages.map((message) => (
                    <div
                      key={message.id}
                      className={cn(
                        "flex",
                        message.sender === 'self' ? "justify-end" : "justify-start"
                      )}
                    >
                      <div
                        className={cn(
                          "max-w-[70%] rounded-lg px-4 py-2",
                          message.sender === 'self'
                            ? "bg-primary text-primary-foreground rounded-br-none"
                            : "bg-muted text-foreground rounded-bl-none"
                        )}
                      >
                        <p>{message.content}</p>
                        <span className="text-xs opacity-70 block text-right mt-1">
                          {message.timestamp}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              
              {/* Input area */}
              <div className="p-4 border-t border-border">
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Image className="h-4 w-4" />
                  </Button>
                  <Input
                    placeholder="Type a message..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleSendMessage();
                      }
                    }}
                    className="flex-grow bg-muted/50 border-none"
                  />
                  <Button variant="ghost" size="icon">
                    <Smile className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Mic className="h-4 w-4" />
                  </Button>
                  <Button size="icon" onClick={handleSendMessage} disabled={!messageInput.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="inline-block p-6 bg-muted rounded-full mb-4">
                  <MessageSquare className="h-12 w-12 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Your Messages</h3>
                <p className="text-muted-foreground mb-4">
                  Select a conversation or start a new one
                </p>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Message
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

const MessageSquare = ({ className }: { className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
  </svg>
);