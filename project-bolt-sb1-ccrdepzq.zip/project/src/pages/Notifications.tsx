import { Helmet } from 'react-helmet';
import { useState } from 'react';
import { Bell, Heart, MessageCircle, UserPlus, Star, Settings } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion } from 'framer-motion';

// Import placeholders for demo
import avatar1 from '@/assets/avatars/avatar1.jpg';
import avatar2 from '@/assets/avatars/avatar2.jpg';
import avatar3 from '@/assets/avatars/avatar3.jpg';
import avatar4 from '@/assets/avatars/avatar4.jpg';
import avatar5 from '@/assets/avatars/avatar5.jpg';

type NotificationType = 'like' | 'comment' | 'follow' | 'mention';

interface Notification {
  id: number;
  type: NotificationType;
  user: {
    name: string;
    username: string;
    avatar: string;
  };
  content: string;
  time: string;
  read: boolean;
}

const notifications: Notification[] = [
  {
    id: 1,
    type: 'like',
    user: {
      name: 'Alex Johnson',
      username: 'alexj',
      avatar: avatar1,
    },
    content: 'liked your post about blockchain technology',
    time: '5m ago',
    read: false,
  },
  {
    id: 2,
    type: 'comment',
    user: {
      name: 'Sarah Parker',
      username: 'sparker',
      avatar: avatar2,
    },
    content: 'commented on your travel photo: "This looks amazing!"',
    time: '15m ago',
    read: false,
  },
  {
    id: 3,
    type: 'follow',
    user: {
      name: 'Michael Chen',
      username: 'mchen',
      avatar: avatar3,
    },
    content: 'started following you',
    time: '1h ago',
    read: true,
  },
  {
    id: 4,
    type: 'mention',
    user: {
      name: 'Emily Rodriguez',
      username: 'emrodz',
      avatar: avatar4,
    },
    content: 'mentioned you in a comment: "I agree with @you on this!"',
    time: '3h ago',
    read: true,
  },
  {
    id: 5,
    type: 'like',
    user: {
      name: 'David Kim',
      username: 'dkim',
      avatar: avatar5,
    },
    content: 'liked your comment on climate change',
    time: '5h ago',
    read: true,
  },
];

export default function Notifications() {
  const [notificationsList, setNotificationsList] = useState<Notification[]>(notifications);

  const markAllAsRead = () => {
    setNotificationsList(
      notificationsList.map((notification) => ({
        ...notification,
        read: true,
      }))
    );
  };

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'like':
        return <Heart className="h-4 w-4 text-red-500" />;
      case 'comment':
        return <MessageCircle className="h-4 w-4 text-blue-500" />;
      case 'follow':
        return <UserPlus className="h-4 w-4 text-green-500" />;
      case 'mention':
        return <Star className="h-4 w-4 text-yellow-500" />;
    }
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  };

  const unreadCount = notificationsList.filter((n) => !n.read).length;

  return (
    <>
      <Helmet title="Notifications | Echolite" />
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold flex items-center">
            <Bell className="mr-2 h-5 w-5" />
            Notifications
            {unreadCount > 0 && (
              <span className="ml-2 bg-primary text-primary-foreground text-xs font-semibold px-2 py-1 rounded-full">
                {unreadCount} new
              </span>
            )}
          </h1>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={markAllAsRead}>
              Mark all as read
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="mb-8">
          <TabsList className="bg-card mb-6">
            <TabsTrigger value="all" className="data-[state=active]:bg-primary/20">
              All
            </TabsTrigger>
            <TabsTrigger value="mentions" className="data-[state=active]:bg-primary/20">
              Mentions
            </TabsTrigger>
            <TabsTrigger value="follows" className="data-[state=active]:bg-primary/20">
              Follows
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all">
            <Card>
              <CardContent className="p-6">
                <motion.div 
                  className="space-y-4"
                  variants={container}
                  initial="hidden"
                  animate="show"
                >
                  {notificationsList.map((notification) => (
                    <motion.div
                      key={notification.id}
                      variants={item}
                      className={`flex items-start p-3 rounded-lg ${
                        !notification.read ? 'bg-primary/10' : 'hover:bg-muted/50'
                      } transition-colors`}
                    >
                      <div className="flex-shrink-0 mr-4">
                        <Avatar>
                          <AvatarImage src={notification.user.avatar} alt={notification.user.name} />
                          <AvatarFallback>{notification.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                      </div>
                      <div className="flex-grow">
                        <div className="flex items-center mb-1">
                          <span className="font-semibold mr-1">{notification.user.name}</span>
                          <div className="bg-muted/70 rounded-full p-1 mr-1">
                            {getNotificationIcon(notification.type)}
                          </div>
                          <span className="text-muted-foreground text-sm">
                            {notification.time}
                          </span>
                        </div>
                        <p className="text-foreground">{notification.content}</p>
                      </div>
                      {!notification.read && (
                        <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-2"></div>
                      )}
                    </motion.div>
                  ))}
                </motion.div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mentions">
            <Card>
              <CardContent className="p-6">
                <motion.div 
                  className="space-y-4"
                  variants={container}
                  initial="hidden"
                  animate="show"
                >
                  {notificationsList
                    .filter((n) => n.type === 'mention')
                    .map((notification) => (
                      <motion.div
                        key={notification.id}
                        variants={item}
                        className={`flex items-start p-3 rounded-lg ${
                          !notification.read ? 'bg-primary/10' : 'hover:bg-muted/50'
                        } transition-colors`}
                      >
                        <div className="flex-shrink-0 mr-4">
                          <Avatar>
                            <AvatarImage src={notification.user.avatar} alt={notification.user.name} />
                            <AvatarFallback>{notification.user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center mb-1">
                            <span className="font-semibold mr-1">{notification.user.name}</span>
                            <div className="bg-muted/70 rounded-full p-1 mr-1">
                              {getNotificationIcon(notification.type)}
                            </div>
                            <span className="text-muted-foreground text-sm">
                              {notification.time}
                            </span>
                          </div>
                          <p className="text-foreground">{notification.content}</p>
                        </div>
                        {!notification.read && (
                          <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-2"></div>
                        )}
                      </motion.div>
                    ))}
                </motion.div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="follows">
            <Card>
              <CardContent className="p-6">
                <motion.div 
                  className="space-y-4"
                  variants={container}
                  initial="hidden"
                  animate="show"
                >
                  {notificationsList
                    .filter((n) => n.type === 'follow')
                    .map((notification) => (
                      <motion.div
                        key={notification.id}
                        variants={item}
                        className={`flex items-start p-3 rounded-lg ${
                          !notification.read ? 'bg-primary/10' : 'hover:bg-muted/50'
                        } transition-colors`}
                      >
                        <div className="flex-shrink-0 mr-4">
                          <Avatar>
                            <AvatarImage src={notification.user.avatar} alt={notification.user.name} />
                            <AvatarFallback>{notification.user.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center mb-1">
                            <span className="font-semibold mr-1">{notification.user.name}</span>
                            <div className="bg-muted/70 rounded-full p-1 mr-1">
                              {getNotificationIcon(notification.type)}
                            </div>
                            <span className="text-muted-foreground text-sm">
                              {notification.time}
                            </span>
                          </div>
                          <p className="text-foreground">{notification.content}</p>
                          <Button variant="outline" size="sm" className="mt-2">
                            Follow back
                          </Button>
                        </div>
                        {!notification.read && (
                          <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-2"></div>
                        )}
                      </motion.div>
                    ))}
                </motion.div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}