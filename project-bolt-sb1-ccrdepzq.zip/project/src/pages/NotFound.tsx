import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';

export default function NotFound() {
  return (
    <>
      <Helmet title="Page Not Found | Echolite" />
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center p-8 max-w-md">
          <div className="mx-auto w-24 h-24 mb-6 rounded-full bg-primary/20 flex items-center justify-center">
            <AlertCircle className="h-12 w-12 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-2">404</h1>
          <h2 className="text-2xl font-semibold mb-4">Page Not Found</h2>
          <p className="text-muted-foreground mb-8">
            The page you are looking for doesn't exist or has been moved.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild>
              <Link to="/home">Go to Home</Link>
            </Button>
            <Button variant="outline">
              <Link to="/login">Go to Login</Link>
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}