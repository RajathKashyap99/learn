import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

export const fetchProfiles = createAsyncThunk(
  'profiles/fetchProfiles',
  async (_, { rejectWithValue }) => {
    try {
      // Simulate network delay for demo
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // For demo purposes, return a mock profile
      return [
        {
          _id: 'profile-123',
          fullname: 'John Doe',
          username: 'johndoe',
          mobilenumber: '1234567890',
          bio: 'Software developer and tech enthusiast. Love to create and share awesome content!',
          gender: 'male',
          dateofbirth: '1990-01-01',
          location: 'San Francisco, CA',
          profileImg: ''
        }
      ];
    } catch (error) {
      return rejectWithValue('Failed to fetch profiles');
    }
  }
);

interface ProfileState {
  data: any[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: ProfileState = {
  data: [],
  status: 'idle',
  error: null,
};

const profileSlice = createSlice({
  name: 'profiles',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchProfiles.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchProfiles.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.data = action.payload;
      })
      .addCase(fetchProfiles.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload as string;
      });
  },
});

export default profileSlice.reducer;