import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Import placeholders for demo
import avatar1 from '@/assets/avatars/avatar1.jpg';
import avatar2 from '@/assets/avatars/avatar2.jpg';
import avatar3 from '@/assets/avatars/avatar3.jpg';
import movieImg from '@/assets/posts/movies.jpg';
import travelImg from '@/assets/posts/travel.avif';
import foodImg from '@/assets/posts/food.webp';

export const fetchPosts = createAsyncThunk(
  'posts/fetchPosts',
  async (_, { rejectWithValue }) => {
    try {
      // In a real app, this would be a fetch call to your API
      // But for this demo, we'll return mock data
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay
      
      return [
        {
          id: 1,
          user: {
            name: 'Alex Johnson',
            username: 'alexj',
            avatar: avatar1,
          },
          content: `Just watched the new sci-fi blockbuster and I'm blown away! Who else has seen it? Let's discuss!`,
          image: movieImg,
          likes: 78,
          comments: 12,
          shares: 5,
          timeAgo: '1h',
          liked: false,
        },
        {
          id: 2,
          user: {
            name: 'Sarah Parker',
            username: 'sparker',
            avatar: avatar2,
          },
          content: 'Exploring the serene beauty of Bali! #Wanderlust',
          image: travelImg,
          likes: 134,
          comments: 25,
          shares: 18,
          timeAgo: '3h',
          liked: true,
        },
        {
          id: 3,
          user: {
            name: 'Michael Chen',
            username: 'mchen',
            avatar: avatar3,
          },
          content:
            'Tried this new ramen place downtown… absolutely delicious! Highly recommend it!',
          image: foodImg,
          likes: 95,
          comments: 16,
          shares: 9,
          timeAgo: '5h',
          liked: false,
        },
      ];
    } catch (error) {
      return rejectWithValue('Failed to fetch posts');
    }
  }
);

interface PostState {
  posts: any[];
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: PostState = {
  posts: [],
  status: 'idle',
  error: null,
};

const postSlice = createSlice({
  name: 'posts',
  initialState,
  reducers: {
    likePost: (state, action) => {
      const postId = action.payload;
      const post = state.posts.find(post => post.id === postId);
      if (post) {
        post.liked = !post.liked;
        post.likes = post.liked ? post.likes + 1 : post.likes - 1;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchPosts.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchPosts.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.posts = action.payload;
      })
      .addCase(fetchPosts.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload as string;
      });
  },
});

export const { likePost } = postSlice.actions;
export default postSlice.reducer;