export interface User {
  uid: string;
  _id?: string;
  email: string;
  displayName: string;
  photoURL: string;
  address?: string;
  accessToken: string;
  friends?: User[];
  requests?: User[];
  posts?: Post[];
  cover?: string;
  dob?: string;
  phoneNumber?: string;
  socket_id?: string;
}

export interface UserSuggestion {
  _id: string;
  displayName: string;
  address?: string;
  photoURL: string;
}

export interface Post {
  _id: string;
  content: string;
  likes: string[];
  comments: Comment[];
  type: 'text' | 'image' | 'video';
  text?: string;
  edited: boolean;
  owner: User;
  timestamp: string;
}

export interface Comment {
  user: User;
  text: string;
  timestamp: string;
}

export interface Message {
  _id: string;
  message: string;
  sender: string;
  receiver: string;
  type: 'text' | 'image' | 'file';
  media?: string;
  timestamp: string;
}