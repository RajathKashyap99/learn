import { useEffect, useState } from 'react';
import { ThemeProvider } from './components/theme-provider';
import { Toaster } from './components/ui/toaster';
import MainLayout from './layouts/MainLayout';
import { AuthProvider } from './contexts/AuthContext';
import { SocketProvider } from './contexts/SocketContext';
import LoginPage from './pages/LoginPage';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      setIsAuthenticated(true);
    }
  }, []);

  return (
    <ThemeProvider defaultTheme="dark" storageKey="echo-mate-theme">
       <AuthProvider>
        <SocketProvider>
          {isAuthenticated ? <MainLayout /> : <LoginPage onLogin={() => setIsAuthenticated(true)} />}
          <Toaster />
        </SocketProvider>
      </AuthProvider>
    </ThemeProvider>
     
  );
}

export default App;