import { useEffect, useState } from 'react';
import Sidebar from '../components/Sidebar';
import FeedContent from '../components/feed/FeedContent';
import RightSidebar from '../components/RightSidebar';
import { useSocket } from '../contexts/SocketContext';
import { useAuth } from '../contexts/AuthContext';
import { User } from '../types';

const MainLayout = () => {
  const { socket } = useSocket();
  const { user } = useAuth();
  const [userProfile, setUserProfile] = useState<User | null>(null);

  useEffect(() => {
    if (socket && user) {
      // Update user's socket ID on connection
      socket.emit('update-user', {
        email: user.email,
        socket_id: socket.id,
      });
      
      // Get user profile
      socket.emit('get-profile-request', user.uid);
      
      // Listen for profile updates
      socket.on('get-profile-response', (data) => {
        setUserProfile(data);
      });
    }

    return () => {
      if (socket) {
        socket.off('get-profile-response');
      }
    };
  }, [socket, user]);

  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar user={userProfile} />
      <FeedContent user={userProfile} />
      <RightSidebar user={userProfile} />
    </div>
  );
};

export default MainLayout;