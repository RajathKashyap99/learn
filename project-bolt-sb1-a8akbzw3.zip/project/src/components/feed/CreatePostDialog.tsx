import { useState, useRef } from 'react';
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter 
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Image, X } from 'lucide-react';
import { useSocket } from '@/contexts/SocketContext';
import { useAuth } from '@/contexts/AuthContext';
import { User } from '@/types';

interface CreatePostDialogProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
}

const CreatePostDialog = ({ isOpen, onClose, user }: CreatePostDialogProps) => {
  const [content, setContent] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { socket } = useSocket();
  const { user: authUser } = useAuth();
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const clearImage = () => {
    setImageFile(null);
    setImagePreview('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const handleSubmit = async () => {
    if (!content && !imageFile) return;
    if (!socket || !authUser) return;
    
    setIsUploading(true);
    
    try {
      let mediaUrl = '';
      
      // If there's an image, upload it first
      if (imageFile) {
        const formData = new FormData();
        formData.append('file', imageFile);
        
        const response = await fetch('http://localhost:8000/upload', {
          method: 'POST',
          body: formData,
        });
        
        if (!response.ok) {
          throw new Error('Failed to upload image');
        }
        
        const data = await response.json();
        mediaUrl = data.fileUrl;
      }
      
      // Create post with or without image
      socket.emit('create-post', {
        content,
        type: imageFile ? 'image' : 'text',
        text: mediaUrl,
        owner: authUser.uid,
      });
      
      setContent('');
      clearImage();
      onClose();
    } catch (error) {
      console.error('Error creating post:', error);
    } finally {
      setIsUploading(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create new post</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 mt-4">
          <div className="flex items-start gap-3">
            <Avatar>
              <AvatarImage src={user?.photoURL} alt={user?.displayName} />
              <AvatarFallback>{user?.displayName?.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            
            <Textarea 
              placeholder="What's on your mind?" 
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="flex-1 resize-none"
              rows={3}
            />
          </div>
          
          {imagePreview && (
            <div className="relative mt-2">
              <img 
                src={imagePreview} 
                alt="Preview" 
                className="max-h-60 rounded-md object-contain w-full"
              />
              <button 
                className="absolute top-2 right-2 bg-black/50 rounded-full p-1"
                onClick={clearImage}
              >
                <X className="h-4 w-4 text-white" />
              </button>
            </div>
          )}
          
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            ref={fileInputRef}
            onChange={handleFileChange}
          />
        </div>
        
        <DialogFooter className="flex items-center justify-between sm:justify-between">
          <Button 
            type="button" 
            variant="outline" 
            size="sm"
            onClick={() => fileInputRef.current?.click()}
          >
            <Image className="h-4 w-4 mr-2" />
            Add Photo
          </Button>
          
          <Button 
            type="submit" 
            disabled={(!content && !imageFile) || isUploading}
            onClick={handleSubmit}
          >
            {isUploading ? 'Publishing...' : 'Publish'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CreatePostDialog;