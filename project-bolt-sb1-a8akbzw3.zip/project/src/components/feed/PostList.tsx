import { useState } from 'react';
import { 
  Card, CardContent, CardFooter, CardHeader 
} from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { 
  MoreHorizontal, Heart, MessageSquare, Bookmark, Share2
} from 'lucide-react';
import { Post, User } from '@/types';
import { formatDistance } from 'date-fns';
import { useSocket } from '@/contexts/SocketContext';

interface PostListProps {
  posts: Post[];
  currentUser: User | null;
}

const PostList = ({ posts, currentUser }: PostListProps) => {
  const { socket } = useSocket();
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});

  const handleLike = (postId: string) => {
    if (!socket || !currentUser) return;
    
    const post = posts.find(p => p._id === postId);
    if (!post) return;
    
    const isLiked = post.likes.includes(currentUser.uid);
    
    if (isLiked) {
      socket.emit('unlike-post', {
        post_id: postId,
        user_id: currentUser.uid,
      });
    } else {
      socket.emit('like-post', {
        post_id: postId,
        user_id: currentUser.uid,
      });
    }
  };

  const handleComment = (postId: string) => {
    if (!socket || !currentUser || !commentInputs[postId]?.trim()) return;
    
    socket.emit('comment-post', {
      post_id: postId,
      user_id: currentUser.uid,
      text: commentInputs[postId],
    });
    
    setCommentInputs(prev => ({ ...prev, [postId]: '' }));
  };

  const toggleComments = (postId: string) => {
    setExpandedComments(prev => ({ 
      ...prev, 
      [postId]: !prev[postId]
    }));
  };

  return (
    <div className="space-y-6">
      {posts.length > 0 ? (
        [...posts].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .map((post) => (
            <Card key={post._id} className="overflow-hidden">
              <CardHeader className="p-4 pb-0">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={post.owner.photoURL} alt={post.owner.displayName} />
                      <AvatarFallback>{post.owner.displayName?.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{post.owner.displayName}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDistance(new Date(post.timestamp), new Date(), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-5 w-5" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-4">
                <p className="mb-3">{post.content}</p>
                
                {post.type === 'image' && post.text && (
                  <div className="mt-3 rounded-lg overflow-hidden">
                    <img 
                      src={post.text} 
                      alt="Post content" 
                      className="w-full h-auto max-h-[500px] object-cover"
                    />
                  </div>
                )}
                
                {post.content.includes('#') && (
                  <div className="mt-2 space-x-2">
                    {post.content.split(' ')
                      .filter(word => word.startsWith('#'))
                      .map((tag, idx) => (
                        <span key={idx} className="text-blue-500 text-sm cursor-pointer hover:underline">
                          {tag}
                        </span>
                      ))
                    }
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="p-4 pt-0 flex flex-col">
                <div className="flex justify-between items-center w-full pb-3">
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="px-2"
                      onClick={() => handleLike(post._id)}
                    >
                      <Heart 
                        className={`h-5 w-5 mr-1 ${
                          currentUser && post.likes.includes(currentUser.uid) 
                            ? 'fill-red-500 text-red-500' 
                            : 'text-muted-foreground'
                        }`} 
                      />
                      <span>{post.likes.length}</span>
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="px-2"
                      onClick={() => toggleComments(post._id)}
                    >
                      <MessageSquare className="h-5 w-5 mr-1 text-muted-foreground" />
                      <span>{post.comments.length}</span>
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon">
                      <Bookmark className="h-5 w-5 text-muted-foreground" />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Share2 className="h-5 w-5 text-muted-foreground" />
                    </Button>
                  </div>
                </div>
                
                {/* Comments section */}
                {(expandedComments[post._id] || post.comments.length < 3) && post.comments.length > 0 && (
                  <div className="w-full border-t pt-3 space-y-3">
                    {post.comments.map((comment, idx) => (
                      <div key={idx} className="flex gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={comment.user.photoURL} alt={comment.user.displayName} />
                          <AvatarFallback>{comment.user.displayName?.substring(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="bg-secondary p-2 rounded-md flex-1">
                          <p className="text-sm font-medium">{comment.user.displayName}</p>
                          <p className="text-sm">{comment.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Add comment input */}
                <div className="w-full mt-3 flex gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={currentUser?.photoURL} alt={currentUser?.displayName} />
                    <AvatarFallback>{currentUser?.displayName?.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 flex">
                    <Textarea 
                      placeholder="Add a comment..."
                      className="min-h-0 h-8 resize-none py-1.5"
                      value={commentInputs[post._id] || ''}
                      onChange={(e) => setCommentInputs(prev => ({ 
                        ...prev, 
                        [post._id]: e.target.value 
                      }))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleComment(post._id);
                        }
                      }}
                    />
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="ml-2"
                      onClick={() => handleComment(post._id)}
                      disabled={!commentInputs[post._id]?.trim()}
                    >
                      Post
                    </Button>
                  </div>
                </div>
              </CardFooter>
            </Card>
          ))
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No posts yet. Create one to get started!</p>
        </div>
      )}
    </div>
  );
};

export default PostList;