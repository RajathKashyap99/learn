import { useState, useEffect } from 'react';
import { useSocket } from '@/contexts/SocketContext';
import { useAuth } from '@/contexts/AuthContext';
import { Input } from '../ui/input';
import { Search, Mic } from 'lucide-react';
import StoriesSection from './StoriesSection';
import { Button } from '../ui/button';
import CreatePostDialog from './CreatePostDialog';
import PostList from './PostList';
import { Post, User } from '@/types';

interface FeedContentProps {
  user: User | null;
}

const FeedContent = ({ user }: FeedContentProps) => {
  const { socket } = useSocket();
  const { user: currentUser } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);

  useEffect(() => {
    if (socket) {
      // Get all posts
      socket.emit('get-posts-request');
      
      // Listen for posts
      socket.on('get-posts-response', (data) => {
        setPosts(data);
      });
      
      // Listen for new posts
      socket.on('create-post-response', (data) => {
        setPosts(data);
      });
    }
    
    return () => {
      if (socket) {
        socket.off('get-posts-response');
        socket.off('create-post-response');
      }
    };
  }, [socket]);

  return (
    <div className="flex-1 p-4 overflow-y-auto max-w-3xl mx-auto">
      <div className="mb-6 flex items-center justify-between">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            type="search" 
            placeholder="Search..." 
            className="pl-9 pr-10 bg-secondary/50 border-0 focus-visible:ring-1" 
          />
          <Mic className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground cursor-pointer" />
        </div>
        
        <Button 
          className="ml-4 bg-blue-500 hover:bg-blue-600 text-white"
          onClick={() => setIsCreatePostOpen(true)}
        >
          Create new post
        </Button>
      </div>

      <StoriesSection />
      
      <div className="mt-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Feeds</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="rounded-full bg-primary text-primary-foreground">Popular</Button>
            <Button variant="outline" size="sm" className="rounded-full">Latest</Button>
          </div>
        </div>
        
        <PostList posts={posts} currentUser={currentUser} />
      </div>

      <CreatePostDialog 
        isOpen={isCreatePostOpen} 
        onClose={() => setIsCreatePostOpen(false)} 
        user={user}
      />
    </div>
  );
};

export default FeedContent;