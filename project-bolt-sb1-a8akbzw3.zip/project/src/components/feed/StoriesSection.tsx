import { Avatar, AvatarImage, AvatarFallback } from '../ui/avatar';
import { PlusCircle } from 'lucide-react';

const StoriesSection = () => {
  // Mock data for stories
  const stories = [
    {
      id: 1,
      name: 'Emma',
      image: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      id: 2,
      name: 'Grace',
      image: 'https://images.pexels.com/photos/1520760/pexels-photo-1520760.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      id: 3,
      name: 'Olivia',
      image: 'https://images.pexels.com/photos/871495/pexels-photo-871495.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      id: 4,
      name: 'Brandon',
      image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      id: 5,
      name: 'Sophie',
      image: 'https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      id: 6,
      name: 'Mia',
      image: 'https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Stories</h2>
        <a href="#" className="text-sm text-blue-500 hover:underline">Watch all</a>
      </div>
      
      <div className="flex space-x-4 overflow-x-auto pb-2 no-scrollbar">
        <div className="flex flex-col items-center min-w-[76px]">
          <div className="w-16 h-16 rounded-full flex items-center justify-center bg-secondary/40 border-2 border-dashed border-blue-500 cursor-pointer">
            <PlusCircle className="w-6 h-6 text-blue-500" />
          </div>
          <span className="mt-2 text-xs text-center">Add story</span>
        </div>
        
        {stories.map((story) => (
          <div key={story.id} className="flex flex-col items-center min-w-[76px]">
            <div className="w-16 h-16 rounded-full ring-2 ring-blue-500 p-1 cursor-pointer">
              <Avatar className="w-full h-full border-0">
                <AvatarImage src={story.image} alt={story.name} />
                <AvatarFallback>{story.name.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
            </div>
            <span className="mt-2 text-xs text-center">{story.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StoriesSection;