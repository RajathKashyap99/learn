import { useState } from 'react';
import { cn } from '@/lib/utils';
import { 
  Home, Compass, Bookmark, MessageSquare, BarChart2, Settings, 
  User, LogOut
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { User as UserType } from '@/types';

interface SidebarProps {
  user: UserType | null;
}

const Sidebar = ({ user }: SidebarProps) => {
  const [activeTab, setActiveTab] = useState('feed');
  const { logout } = useAuth();

  const links = [
    { id: 'feed', label: 'Feed', icon: <Home className="h-5 w-5" /> },
    { id: 'explore', label: 'Explore', icon: <Compass className="h-5 w-5" /> },
    { id: 'favorites', label: 'My favorites', icon: <Bookmark className="h-5 w-5" /> },
    { id: 'direct', label: 'Direct', icon: <MessageSquare className="h-5 w-5" /> },
    { id: 'stats', label: 'Stats', icon: <BarChart2 className="h-5 w-5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="h-5 w-5" /> },
  ];

  return (
    <div className="w-72 border-r border-border bg-card flex flex-col h-screen sticky top-0 p-4">
      {user && (
        <div className="mb-6 text-center">
          <div className="relative group mb-2">
            <Avatar className="h-24 w-24 mx-auto relative">
              <AvatarImage src={user.photoURL} alt={user.displayName} />
              <AvatarFallback className="bg-primary-foreground text-primary text-xl">
                {user.displayName?.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="absolute inset-0 flex items-center justify-center opacity-0 
                           group-hover:opacity-100 transition-opacity rounded-full 
                           bg-black/50 cursor-pointer">
              <User className="h-6 w-6 text-white" />
            </div>
          </div>
          <h2 className="text-xl font-semibold">{user.displayName}</h2>
          <p className="text-sm text-muted-foreground">{user.address}</p>
          
          <div className="flex justify-between mt-4 px-5">
            <div className="text-center">
              <p className="font-semibold">{user.posts?.length || 0}</p>
              <p className="text-xs text-muted-foreground">Posts</p>
            </div>
            <div className="text-center">
              <p className="font-semibold">{user.friends?.length || 0}</p>
              <p className="text-xs text-muted-foreground">Friends</p>
            </div>
            <div className="text-center">
              <p className="font-semibold">0</p>
              <p className="text-xs text-muted-foreground">Following</p>
            </div>
          </div>
        </div>
      )}

      <nav className="space-y-1 flex-1">
        {links.map((link) => (
          <button
            key={link.id}
            className={cn(
              "flex items-center w-full space-x-3 px-4 py-3 rounded-lg transition-colors",
              activeTab === link.id 
                ? "bg-primary text-primary-foreground" 
                : "hover:bg-accent text-foreground"
            )}
            onClick={() => setActiveTab(link.id)}
          >
            {link.icon}
            <span>{link.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-4 border-t border-border pt-4">
        <h3 className="font-semibold mb-2 px-4">Contacts</h3>
        {user && user.friends && user.friends.slice(0, 5).map((friend: any) => (
          <div key={friend._id} className="flex items-center gap-3 px-4 py-2 hover:bg-accent rounded-lg cursor-pointer">
            <Avatar className="h-8 w-8">
              <AvatarImage src={friend.photoURL} alt={friend.displayName} />
              <AvatarFallback>{friend.displayName?.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1 overflow-hidden">
              <p className="truncate">{friend.displayName}</p>
              <p className="text-xs text-muted-foreground truncate">{friend.address}</p>
            </div>
          </div>
        ))}
        <button
          className="w-full text-center text-sm text-blue-400 hover:underline py-2"
          onClick={() => {}} 
        >
          View All
        </button>
      </div>

      <button 
        className="flex items-center space-x-2 text-destructive hover:bg-destructive/10 px-4 py-2 rounded-lg mt-4"
        onClick={logout}
      >
        <LogOut className="h-5 w-5" />
        <span>Logout</span>
      </button>
    </div>
  );
};

export default Sidebar;