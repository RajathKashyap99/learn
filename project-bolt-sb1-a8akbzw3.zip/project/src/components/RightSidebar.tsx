import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useSocket } from '@/contexts/SocketContext';
import { useAuth } from '@/contexts/AuthContext';
import { User, UserSuggestion } from '@/types';
import { UserPlus } from 'lucide-react';

interface RightSidebarProps {
  user: User | null;
}

const RightSidebar = ({ user }: RightSidebarProps) => {
  const { socket } = useSocket();
  const { user: currentUser } = useAuth();

  const handleAcceptRequest = (sender: string) => {
    if (socket && currentUser) {
      socket.emit('accept-friend-request', {
        sender,
        receiver: currentUser.uid,
      });
    }
  };

  const handleDeclineRequest = (sender: string) => {
    if (socket && currentUser) {
      socket.emit('reject-friend-request', {
        sender,
        receiver: currentUser.uid,
      });
    }
  };

  const handleAddFriend = (userId: string) => {
    if (socket && currentUser) {
      socket.emit('send-friend-request', {
        sender: currentUser.uid,
        receiver: userId,
      });
    }
  };

  // Mock suggested users (in a real app, you'd get these from the backend)
  const suggestedUsers: UserSuggestion[] = [
    {
      _id: '1',
      displayName: 'Chantal Shelburne',
      address: 'Memphis, TN, US',
      photoURL: 'https://images.pexels.com/photos/762080/pexels-photo-762080.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      _id: '2',
      displayName: 'Marci Senter',
      address: 'Newark, NJ, US',
      photoURL: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      _id: '3',
      displayName: 'Janetta Rotolo',
      address: 'Fort Worth, TX, US',
      photoURL: 'https://images.pexels.com/photos/1036622/pexels-photo-1036622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      _id: '4',
      displayName: 'Tyra Dhillon',
      address: 'Springfield, MA, US',
      photoURL: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      _id: '5',
      displayName: 'Marielle Wigington',
      address: 'Honolulu, HI, US',
      photoURL: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    }
  ];

  return (
    <div className="w-80 border-l border-border bg-card h-screen sticky top-0 overflow-y-auto p-4">
      {/* Friend Requests Section */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Requests <span className="inline-flex items-center justify-center w-5 h-5 text-xs bg-primary text-white rounded-full">{user?.requests?.length || 0}</span></h2>
        </div>
        
        {user?.requests && user.requests.length > 0 ? (
          <div className="space-y-4">
            {user.requests.map((req: any) => (
              <div key={req._id} className="flex flex-col space-y-2">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={req.photoURL} alt={req.displayName} />
                    <AvatarFallback>{req.displayName?.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{req.displayName}</p>
                    <p className="text-xs text-muted-foreground">wants to add you to friends</p>
                  </div>
                </div>
                <div className="flex gap-2 ml-10">
                  <Button size="sm" onClick={() => handleAcceptRequest(req._id)}>Accept</Button>
                  <Button size="sm" variant="outline" onClick={() => handleDeclineRequest(req._id)}>Decline</Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No pending friend requests</p>
        )}
      </div>

      {/* Suggestions Section */}
      <div>
        <h2 className="text-lg font-semibold mb-4">Suggestions for you</h2>
        <div className="space-y-4">
          {suggestedUsers.map((suggestion) => (
            <div key={suggestion._id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={suggestion.photoURL} alt={suggestion.displayName} />
                  <AvatarFallback>{suggestion.displayName?.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{suggestion.displayName}</p>
                  <p className="text-xs text-muted-foreground">{suggestion.address}</p>
                </div>
              </div>
              <Button size="icon" variant="ghost" onClick={() => handleAddFriend(suggestion._id)}>
                <UserPlus className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
        <Button className="w-full mt-4" variant="ghost">View All</Button>
      </div>

      {/* Followers Count */}
      <div className="mt-8 pt-6 border-t border-border">
        <div className="flex items-center gap-2 justify-center mb-1">
          <div className="flex -space-x-2">
            {[...Array(7)].map((_, index) => (
              <Avatar key={index} className="border-2 border-background w-8 h-8">
                <AvatarImage src={`https://i.pravatar.cc/150?img=${index + 10}`} />
                <AvatarFallback>U{index}</AvatarFallback>
              </Avatar>
            ))}
          </div>
        </div>
        <div className="text-center">
          <h3 className="text-xl font-bold">184.3K</h3>
          <p className="text-sm text-muted-foreground">Active now on your profile</p>
        </div>
      </div>

      {/* Footer Links */}
      <div className="mt-8 text-xs text-muted-foreground">
        <div className="flex flex-wrap gap-x-4 gap-y-2">
          <a href="#" className="hover:underline">About</a>
          <a href="#" className="hover:underline">Accessibility</a>
          <a href="#" className="hover:underline">Help Center</a>
          <a href="#" className="hover:underline">Privacy and Terms</a>
          <a href="#" className="hover:underline">Advertising</a>
          <a href="#" className="hover:underline">Business Services</a>
        </div>
      </div>
    </div>
  );
};

export default RightSidebar;